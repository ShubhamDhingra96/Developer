package com.snap.ib.personelLoan.common;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.ibm.json.java.JSONObject;


public class IOUtils {
	
	private final static Logger logger = LoggerFactory.getLogger(IOUtils.class ); 
	
	public static String getPrintStackTrace(Throwable e) {
        final StringWriter sw = new StringWriter();
        final PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}
	
	public String readFile(final String file)  {
		InputStream stream = null;
		final StringBuilder builder = new StringBuilder();
		String filePath="";
		try {
			if (ApplicationConstant.isFileStubbedEnabled) {
				filePath=ApplicationConstant.STUBBED_FILE_DIR + "/" + file+ ".json";
				stream = new FileInputStream(
						ApplicationConstant.STUBBED_FILE_DIR + "/" + file
								+ ".json");
			}else {
				stream = this.getClass().getClassLoader().getResourceAsStream("json/" + file + ".json");
			}
			
			logger.info("filePath:"+filePath);
			final Reader reader = new BufferedReader(new InputStreamReader(stream));
			final char[] buffer = new char[8192];
			int read;
			while ((read = reader.read(buffer, 0, buffer.length)) > 0) {
				builder.append(buffer, 0, read);
			}
			reader.close();
			
		} catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);

		} finally {
			try {
				if (null!=stream )
					stream.close();
			} catch (IOException e) {
				logger.error(ApplicationConstant.ERROR, e);
			}
		}
		return builder.toString();
	}

	public static <T> T getObject(final String fileName, final Class<T> classObj) {
		final Gson gson = new Gson();
		try {
			final String jsonString = new IOUtils().readFile(fileName);
			final JSONObject jsonObject = JSONObject.parse(jsonString);
			if (jsonObject.containsKey("delayTime")) {
				final int timeout = Integer.parseInt(jsonObject.get("delayTime").toString());
				Thread.sleep(timeout);
			}
			return (T) gson.fromJson(jsonObject.toString(), classObj);
		}catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);
			JSONObject object = new JSONObject();
			object.put("responseCode", "IBL005");
			object.put(
					"responseMessage",
					"Seems some issue to parsing stub json due to"
							+ e.getMessage() + "("
							+ ApplicationConstant.STUBBED_FILE_DIR + "/"
							+ fileName + ".json)");
			return (T) gson.fromJson(object.toString(), classObj);
		}catch (InterruptedException e) {
			logger.error(ApplicationConstant.ERROR, e);
			final JSONObject object = new JSONObject();
			object.put("responseCode", "IBL007");
			object.put("responseMessage", e.getMessage());
			return (T) gson.fromJson(object.toString(), classObj);
		}
	}
}
