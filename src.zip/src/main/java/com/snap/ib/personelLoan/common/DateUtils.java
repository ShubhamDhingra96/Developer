package com.snap.ib.personelLoan.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

final public class DateUtils {
	
	/*private final static Logger logger = LoggerFactory.getLogger(DateUtils.class );*/ 
	
	private DateUtils() {
		super();
	}
	
	public static String getTimeTitle(){
		final Calendar c = Calendar.getInstance();
        final int timeOfDay = c.get(Calendar.HOUR_OF_DAY);
	
		if(timeOfDay >= 0 && timeOfDay < 12){
		   return "Good Morning";     
		}else if(timeOfDay >= 12 && timeOfDay < 16){
			 return "Good Afternoon";  
		}else if(timeOfDay >= 16 && timeOfDay < 21){
			 return "Good Evening";  
		}else if(timeOfDay >= 21 && timeOfDay < 24){
			 return " Good Evening".trim();  
		}
		return "Good Morning";
 	}
	
	public static String getTime(final long dateTime){
		final SimpleDateFormat dateFormat=new SimpleDateFormat("hh:mm a");
		return dateFormat.format(new Date(dateTime));
 	}
	
	public static String getDate(final long dateTime){
		final SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MMM-yyyy");
		return dateFormat.format(new Date(dateTime));
 	}
	
}
