package com.snap.ib.personelLoan.common.i18n;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.snap.ib.personelLoan.common.IOUtils;

/**
 * 
 * @author Harsh
 *
 */
public class PropertiesFileReader {
	private PropertiesFileReader reader;
	private Properties props;
	static final Logger logger = LoggerFactory.getLogger(PropertiesFileReader.class.getName());
	/**
	 * Function used to load property file
	 * @param fileName
	 */
	private void load(final String fileName) {
		/*props = new Properties();
		try {
			InputStream in = new FileInputStream(fileName);
			props.load(in);
			in.close();
		} catch (IOException e) {
			logger.error(IOUtils.getPrintStackTrace(e));
		}*/
		props = new Properties();
		try {
			final InputStream in = new FileInputStream("");
			props.load(this.getClass().getClassLoader().getResourceAsStream(fileName));
			in.close();
		} catch (IOException e) {
			logger.error(IOUtils.getPrintStackTrace(e));
		}
		
	}
	/**
	 * Function used to get instance of property file
	 * @param fileName
	 */
	public synchronized PropertiesFileReader getInstance(final String fileName) {
		if (reader == null) {
			reader = new PropertiesFileReader();
			load(fileName);
		}
		return reader;
	}
	/**
	 * Function used to read property from property file
	 * @param fileName
	 */
	public String getProperty(final String fileName, final String propertyName) {
		load(fileName);
		return props.getProperty(propertyName);
	}
}
