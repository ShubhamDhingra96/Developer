package com.snap.ib.personelLoan.common.iib.domain;

public class IIBResponseType {
	private RequestContext context;
	
	
	public RequestContext getContext() {
		return context;
	}

	public void setContext(final RequestContext context) {
		this.context = context;
	}

	

}
