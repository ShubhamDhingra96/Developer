package com.snap.ib.personelLoan.common;

public interface MessageConstant {
	
	/*String SUCCESS_REPONSE_CODE = "0000";
	String FAILURE_REPONSE_CODE = "0001";
	String AUTHENTICATION_FAIL_CODE = "0008";
	String SUCCESS_REPONSE_MESSAGE = "success";
	String FAILURE_REPONSE_MESSAGE = "failed";
	String EXCEPTION_MESSAGE = "We are unable to proccess your request,please try later";
	String EXCEPTION_CODE = "";
	String OMP_AUTH_SERVICE_FAIL_MESSAGE = "Authentication Servie of OMP fails";
	String OMP_SAVE_TO_ANALYTICS_FAILS = "Save to Anatytics Faills";
	String OMP_EMI_MESSAGE = "";
	String AUTHENTICATION_FAIL_MESSAGE = "Please login to access feature";
	String ENC_FAILURE_REPONSE_CODE = null;	*/
}
