package com.snap.ib.personelLoan.common;

import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class ASD {

	public static String getDecToken(String input, String key) {

		byte[] arr;
		String token = null;
		System.out.println("input::: " + input + " Key::: " + key);
		try {
			if (null != input && null != key) {

				arr = key.getBytes("UTF-8");
				MessageDigest md = MessageDigest.getInstance("SHA-256");
				arr = md.digest(arr);
				byte[] arr1 = new byte[16];
				arr1 = Arrays.copyOf(arr, 16);
				SecretKeySpec skey = new SecretKeySpec(arr1, "AES");
				IvParameterSpec iv = new IvParameterSpec(arr1);
				Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
				cipher.init(Cipher.DECRYPT_MODE, skey, iv);
				token = new String(cipher.doFinal(Base64.decodeBase64(input)));
				System.out.println("decrypted string ::: " + token);

			}

		} catch (Exception exception) {
		}
		return token;
	}

	public static String decrypt(String input, String key) {

		byte[] output = null;
		byte[] arr;
		input = input.replaceAll("%2F", "/");
		input = input.replaceAll("%2B", "+");
		input = input.replaceAll("%3D", "=");
		try {
			/*
			 * arr = key.getBytes("UTF-8"); MessageDigest md =
			 * MessageDigest.getInstance("SHA-256"); arr = md.digest(arr);
			 * byte[] arr1 = new byte[16]; arr1=Arrays.copyOf(arr,16);
			 * SecretKeySpec skey = new SecretKeySpec(arr1, "AES");
			 */
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skey);
			output = cipher.doFinal(Base64.decodeBase64(input));
		} catch (Exception e) {
			e.printStackTrace();

		}
		return new String(output);
	}

	public static void main(String[] args) {

		String encdata = "uFeo48UBp5WnpfOlkcg/PXTBC3ILC6NXMhXBY9TO2jDfDg+ulg24d6eKT1ej1sB8bpfdqWXEnxy2mPLocXftsAnltfomoqK4hxb6viAf+yzsP573ae7o0CUrvR/t4wZKM8BnTUOyhTlJywGvJjxxhcahMWue+5erkuQA0gF9PKilmS4wNs22clhFBcJC8wgQ7Hkzl7h2Af3u3HEXAoLTIEWNiQbCQ8ujKYMJjoBH9z2TMOqcg2veTVfA1Ey4rgtOS2F93vo/O3vQEDNM+LQV3CWRtj/juYacDznupnPnZ0WJySttDkrr5ibFUcmNGbsMcZHqCLZuyFXPI7CLuw08Am/MnfvXDp5EbVuMkdX77d0DP6mGlk33wcikEuOrkV7boIOwml17IoNcfG1at3pjppQiLEUBTTGVbUiV23E/9D9VjnfheV47IVdpEPSofv8k3l13qGbJTI7JKd/AMs/07EdjZmBDJDMuU/0gLTDNGSDo4P9uG6BIgPsu9zG90qVYpdo05TI3nzZoyMm9KkEeBWvHvzsktbnhktTM1FyRWGFbBM0ItLSNbX+pe3FqGcstoLK2OnVI4x53/WlBSlapo4itY7FLGTCvdZ+72GbFPzUQRw5R10GNvohANaTRlvA/VRwlgdc6z9ZWlbmosgocc3cF4uBDzqjC4zC1iSL8Lkg=";
		System.out.println("YesBankResponse::: " + ASD.getDecToken(encdata, "Indiabulls2018"));
		// AES_Encrption.decrypt(encdata, "Indiabulls2018");
	}
}
