package com.snap.ib.personelLoan.common.iib.domain;

public class UserDetail {

	private String lotusId;
	private String username;
	private String userRole;

	/**
	 * Added segment Id, so as to use in OMP By Harsh
	 */
	private String segmentId;
	private String sim;
	private String cif;
	private String mobileNumber;
	private String lastLoggedIn;
	private String status;
	private String creationDate;
	private String MPinStatus;
	private String UserRegistrationStatus;
	private String loginCount;
	private boolean profilePasswordSetFlag;
	private String countryCode;
	private String deviceId;
	private String inbUsername;

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(final String countryCode) {
		this.countryCode = countryCode;
	}

	public String getLoginCount() {
		return loginCount;
	}

	public void setLoginCount(final String loginCount) {
		this.loginCount = loginCount;
	}

	public boolean getProfilePasswordSetFlag() {
		return profilePasswordSetFlag;
	}

	public void setProfilePasswordSetFlag(final boolean profilePasswordSetFlag) {
		this.profilePasswordSetFlag = profilePasswordSetFlag;
	}

	public String getCif() {
		return cif;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(final String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getLastLoggedIn() {
		return lastLoggedIn;
	}

	public void setLastLoggedIn(final String lastLoggedIn) {
		this.lastLoggedIn = lastLoggedIn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(final String creationDate) {
		this.creationDate = creationDate;
	}

	public String getMPinStatus() {
		return MPinStatus;
	}

	public void setMPinStatus(final String mPinStatus) {
		MPinStatus = mPinStatus;
	}

	public String getUserRegistrationStatus() {
		return UserRegistrationStatus;
	}

	public void setUserRegistrationStatus(final String userRegistrationStatus) {
		UserRegistrationStatus = userRegistrationStatus;
	}

	public void setCif(final String cif) {
		this.cif = cif;
	}

	public String getLotusId() {
		return lotusId;
	}

	public void setLotusId(final String lotusId) {
		this.lotusId = lotusId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(final String username) {
		this.username = username;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(final String userRole) {
		this.userRole = userRole;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(final String sim) {
		this.sim = sim;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(final String deviceId) {
		this.deviceId = deviceId;
	}

	public String getInbUsername() {
		return inbUsername;
	}

	public void setInbUsername(final String inbUsername) {
		this.inbUsername = inbUsername;
	}

	/**
	 * Added segment Id, so as to use in OMP By Harsh
	 */
	public String getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(final String segmentId) {
		this.segmentId = segmentId;
	}
}
