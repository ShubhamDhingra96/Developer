package com.snap.ib.personelLoan.common;

import javax.ws.rs.core.HttpHeaders;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class DeviceInformation {
	String deviceId;
	String clientId;
	/**
	 * Information available under "x-mfp-analytics-metadata" header 
	 * 1. deviceId
	 * 2. clientId 
	 * 3. osVersion 
	 * 4. os 
	 * 5. brand 
	 * 6. model 
	 * 7. mfpAppName 
	 * 8. mfpAppVersion 
	 * 9. appVersionDisplay 
	 * 10. appVersionCode 
	 * 11. appStoreID 
	 * 12. appStoreLabel
	 */
	private static final String HEADER_NAME = "x-mfp-analytics-metadata";

	private String getInformation(final HttpHeaders headers,final String informationType) {
		final Gson gson = new Gson();
		if (null==headers.getRequestHeader(HEADER_NAME)) {
			return null;
		}
		final String deviceInformmationStr = headers.getRequestHeader(HEADER_NAME).get(0);
		final JsonObject deviceInformation = gson.fromJson(deviceInformmationStr, JsonObject.class);
		return deviceInformation.get(informationType).getAsString();
	}

	/**
	 * Function to get device id from header
	 * @param headers
	 * @return
	 */
	public String getDeviceId(final HttpHeaders headers) {
		return getInformation(headers, "deviceID");
	}

	/**
	 * Function to get OS from header
	 * 
	 * @param headers
	 * @return
	 */
	public String getOs(final HttpHeaders headers) {
		return getInformation(headers, "os");
	}
	/**
	 * Function to get OS version from header
	 * 
	 * @param headers
	 * @return
	 */
	public String getOsVersion(final HttpHeaders headers) {
		return getInformation(headers, "osVersion");
	}
	/**
	 * Function to get Brand from header
	 * 
	 * @param headers
	 * @return
	 */
	public String getBrand(final HttpHeaders headers) {
		return getInformation(headers, "brand");
	}
	/**
	 * Function to get Model from header
	 * 
	 * @param headers
	 * @return
	 */
	public String getModel(final HttpHeaders headers) {
		return getInformation(headers, "model");
	}
	/**
	 * Function to get client id from header
	 * 
	 * @param headers
	 * @return
	 */
	public String getClientId(final HttpHeaders headers) {
		return getInformation(headers, "clientID");
	}
}
