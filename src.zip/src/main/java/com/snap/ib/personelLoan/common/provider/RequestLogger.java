package com.snap.ib.personelLoan.common.provider;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.Map;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.snap.ib.personelLoan.common.ApplicationConstant;

@Provider
public class RequestLogger implements ContainerRequestFilter {
	private final static Logger logger = LoggerFactory.getLogger(RequestLogger.class ); 

    @SuppressWarnings({ "rawtypes", "unused" })
	public void filter(final ContainerRequestContext context) throws IOException{
          	
    	final MultivaluedMap< String, String> map=context.getHeaders();
    	final Iterator it = map.entrySet().iterator();
        while (it.hasNext()) {
            final Map.Entry pair = (Map.Entry)it.next();
          
            
        }
       	final String result=getStringFromInputStream(context.getEntityStream());
       	final InputStream stream = new ByteArrayInputStream(result.getBytes(StandardCharsets.UTF_8));
    	context.setEntityStream(stream);
        
    }
    
    private static String getStringFromInputStream(final InputStream is) {

		BufferedReader br = null;
		final StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		}catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);
		}catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
		}finally {
			if (br != null) {
				try {
					br.close();
				}catch (IOException e) {
					logger.error(ApplicationConstant.ERROR, e);
				}
			}
		}

		return sb.toString();

	}
}