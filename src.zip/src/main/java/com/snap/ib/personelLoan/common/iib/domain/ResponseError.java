package com.snap.ib.personelLoan.common.iib.domain;

import java.util.List;

public class ResponseError {
	
	private List<ExceptionDetail> exceptions;

	public List<ExceptionDetail> getExceptions() {
		return exceptions;
	}

	public void setExceptions(final List<ExceptionDetail> exceptions) {
		this.exceptions = exceptions;
	}
	
	

}
