package com.snap.ib.personelLoan.common.iib.domain;

public class ExceptionDetail {
	private String errorCode;
	
	private String errorDescription;
	
	private String errorType;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(final String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(final String errorType) {
		this.errorType = errorType;
	}
}
