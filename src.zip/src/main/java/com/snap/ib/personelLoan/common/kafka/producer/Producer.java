package com.snap.ib.personelLoan.common.kafka.producer;

import java.io.InputStream;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.io.Resources;
import com.snap.ib.personelLoan.common.ApplicationConstant;

public abstract class Producer
{
  private KafkaProducer<String, String> producer;
  private static Properties properties;
  private static final  Logger logger = LoggerFactory.getLogger(Producer.class ); 
  
  public abstract String getTopic();
  
  public final void send(final Object message)
  {
    new Thread(new Runnable()
    {
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public void run()
    {
        try
        {
          if (null==Producer.this.producer) {
            Producer.this.producer = Producer.this.getProducer();
          }
          Producer.this.producer.send(new ProducerRecord(Producer.this.getTopic(), message.toString()));
          Producer.this.producer.flush();
        }
        catch (NullPointerException e){
        	logger.error(ApplicationConstant.ERROR, e);
        }catch (RuntimeException e){
        	logger.error(ApplicationConstant.ERROR, e);
        }catch (Exception e){
        	logger.error(ApplicationConstant.ERROR, e);
        }
      }
    })
     .start();
  }
  
@SuppressWarnings({ "unchecked", "rawtypes" })
private KafkaProducer<String, String> getProducer()
  {
    try
    {
      if (properties == null)
      {
        final InputStream inputStream = Resources.getResource("kafka.props").openStream();
        properties = new Properties();
        properties.load(inputStream);
        inputStream.close();
      }
      this.producer = new KafkaProducer(properties);
    }
    catch (Exception e)
    {
    	logger.error(ApplicationConstant.ERROR, e);
    }
    return this.producer;
  }
}
