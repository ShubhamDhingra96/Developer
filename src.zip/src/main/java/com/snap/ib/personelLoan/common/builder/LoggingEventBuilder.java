package com.snap.ib.personelLoan.common.builder;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.snap.ib.personelLoan.common.IOUtils;
import com.snap.ib.personelLoan.common.iib.domain.UserDetail;
import com.snap.ib.personelLoan.common.iib.domain.logging.LoggingDetails;

public class LoggingEventBuilder {
	
	private transient String eventType;
	private transient String pageId;
	private transient Throwable ex;
	private UserDetail userDetail;
	
	public LoggingEventBuilder setEventType(final UserDetail userDetail){
		this.userDetail=userDetail;
		return this;
	}
	
	public LoggingEventBuilder setEventType(final String eventType){
		this.eventType=eventType;
		return this;
	}
	
	public LoggingEventBuilder setPageId(final String pageId){
		this.pageId=pageId;
		return this;
	}
	public LoggingEventBuilder setPageId(final Throwable ex){
		this.ex=ex;
		return this;
	}
	
	public String build(){
		
		final Gson gson=new GsonBuilder().setPrettyPrinting().create();
		final LoggingDetails details=new LoggingDetails();
		details.setEvenyType(eventType);
		details.setSubComponentName(pageId);
		details.setChanelName("Mobile");
		if(null!=userDetail){
			details.setCif(userDetail.getCif());
			details.setUserName(userDetail.getUsername());
		}
		if(null!=ex){
			details.setDescription(IOUtils.getPrintStackTrace(ex));
		}
		
		return gson.toJson(details);
		

	}
}
