package com.snap.ib.personelLoan.common.provider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.snap.ib.personelLoan.common.ApplicationConstant;

@Provider
public class ResponseLogger implements ContainerResponseFilter {
	private static final Logger logger = LoggerFactory.getLogger(RequestLogger.class ); 

 public ResponseLogger() {
	 logger.info("ServerResponseFilter initialization");
  
 }

  
 @SuppressWarnings("unused")
public void filter(ContainerRequestContext requestContext,
   ContainerResponseContext responseContext) {
   logger.info("----Response---for "+requestContext.getUriInfo().getAbsolutePath()+"  "+responseContext.getStatusInfo().getStatusCode());
   final Gson gson=new GsonBuilder().setPrettyPrinting().create();

 }
 
 @SuppressWarnings("unused")
private static String getStringFromInputStream(final InputStream is) {

		BufferedReader br = null;
		final StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					logger.error(ApplicationConstant.ERROR, e);
				}
			}
		}

		return sb.toString();

	}

}