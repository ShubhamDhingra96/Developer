package com.snap.ib.personelLoan.common.iib.domain;

public class RequestContext {
	
	private ClientDetail client;
	
	private UserDetail user;

	public ClientDetail getClient() {
		return client;
	}

	public void setClient(ClientDetail client) {
		if(client==null){
			client=new ClientDetail();
		}
		this.client = client;
	}

	public UserDetail getUser() {
		if(user==null){
			user=new UserDetail();
		}
		return user;
	}

	public void setUser(final UserDetail user) {
		this.user = user;
	}
	
	

}
