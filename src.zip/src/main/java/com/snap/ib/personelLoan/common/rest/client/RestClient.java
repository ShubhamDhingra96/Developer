package com.snap.ib.personelLoan.common.rest.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.snap.ib.personelLoan.common.ApplicationConstant;

public class RestClient {

	private final static Logger logger = LoggerFactory.getLogger(RestClient.class);
	private List<NameValuePair> params;
	private List<NameValuePair> headers;
	private String postData;
	private int connectionTimeOut = 35000;
	private int soTimeOut = 35000;
	private String url;
	private int responseCode;
	private String message;
	private String response;

	public int getConnectionTimeOut() {
		return connectionTimeOut;
	}

	public void setConnectionTimeOut(final int connectionTimeOut) {
		this.connectionTimeOut = connectionTimeOut;
	}

	public int getSoTimeOut() {
		return soTimeOut;
	}

	public void setSoTimeOut(final int soTimeOut) {
		this.soTimeOut = soTimeOut;
	}

	public String getResponse() {
		return response;
	}

	public String getErrorMessage() {
		return message;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public RestClient(final String url) {
		this.url = url;
		params = new ArrayList<NameValuePair>();
		headers = new ArrayList<NameValuePair>();
	}

	public void AddParam(final String name, final String value) {
		params.add(new BasicNameValuePair(name, value));
	}

	public void AddHeader(final String name, final String value) {
		headers.add(new BasicNameValuePair(name, value));
	}

	public void execute(final RequestMethod method) throws Exception {
		switch (method) {
		case GET: {
			final StringBuilder combinedParams = new StringBuilder("");

			if (!params.isEmpty()) {
				combinedParams.append("?");
				for (final NameValuePair p : params) {
					final String paramString = p.getName() + "=" + URLEncoder.encode(p.getValue(), "UTF-8");
					if (combinedParams.length() > 1) {
						combinedParams.append("&").append(paramString);
					} else {
						combinedParams.append(paramString);
					}
				}
			}

			HttpGet request = new HttpGet(url + combinedParams);

			// add headers
			for (final NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			executeRequest(request, url);
			break;
		}
		case POST: {
			final HttpPost request = new HttpPost(url);

			// add headers
			for (final NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			if (!params.isEmpty()) {
				request.setEntity(new UrlEncodedFormEntity(params));
			}
			if (postData != null) {
				final StringEntity str = new StringEntity(postData);
				request.setEntity(str);

			}
			executeRequest(request, url);
			break;
		}
		case PUT: {
			final HttpPut request = new HttpPut(url);

			// add headers
			for (final NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			if (!params.isEmpty()) {
				request.setEntity(new UrlEncodedFormEntity(params));
			}
			if (postData != null) {
				final StringEntity str = new StringEntity(postData);
				request.setEntity(str);
			}
			executeRequest(request, url);
			break;
		}
		case DELETE: {
			final HttpDelete request = new HttpDelete(url);

			// add headers
			for (final NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			executeRequest(request, url);
			break;
		}
		}
	}

	private void executeRequest(final HttpUriRequest request, final String url) throws Exception {

		final RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(connectionTimeOut)
				.setConnectionRequestTimeout(soTimeOut).setSocketTimeout(soTimeOut).build();
		final CloseableHttpClient client = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
		final HttpContext localContext = new BasicHttpContext();
		CloseableHttpResponse httpResponse = null;

		try {
			httpResponse = client.execute(request, localContext);
			responseCode = httpResponse.getStatusLine().getStatusCode();

			message = httpResponse.getStatusLine().getReasonPhrase();
			final HttpEntity entity = httpResponse.getEntity();
			if (entity != null) {
				final InputStream instream = entity.getContent();
				response = convertStreamToString(instream);
				instream.close();
			}
		} catch (ClientProtocolException e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();
		} catch (SocketException e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();

		} catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();
		} finally {
			if (null != httpResponse)
				httpResponse.close();
			if (client != null) {
				client.close();
			}
		}
	}

	private static String convertStreamToString(final InputStream is) {

		final BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		final StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
		} catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);

		} finally {
			try {
				is.close();
			} catch (IOException e) {
				logger.error(ApplicationConstant.ERROR, e);
			}
		}
		return sb.toString();
	}

	public String getPostData() {
		return postData;
	}

	public void setPostData(final String postData) {
		this.postData = postData;
	}

	@SuppressWarnings("unused")
	private static String getStringFromInputStream(final InputStream is) {

		BufferedReader br = null;
		final StringBuilder sb = new StringBuilder();

		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		} catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					logger.error(ApplicationConstant.ERROR, e);
				}
			}
		}
		return sb.toString();

	}

	public HttpResponse executeReq() throws Exception {
		HttpResponse httpResponse;
		{

			final HttpPost request = new HttpPost(url);

			// add headers
			for (final NameValuePair h : headers) {
				request.addHeader(h.getName(), h.getValue());
			}

			if (!params.isEmpty()) {
				request.setEntity(new UrlEncodedFormEntity(params));
			}
			if (postData != null) {
				final StringEntity str = new StringEntity(postData);
				request.setEntity(str);

			}
			logger.info("request in executeReq: " + request);
			logger.info("url: " + url);
			httpResponse = executeREQ(request, url);

		}
		return httpResponse;

	}

	private CloseableHttpResponse executeREQ(final HttpUriRequest request, final String url) throws Exception {

		final RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(connectionTimeOut)
				.setConnectionRequestTimeout(soTimeOut).setSocketTimeout(soTimeOut).build();
		final CloseableHttpClient client = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();
		final HttpContext localContext = new BasicHttpContext();
		CloseableHttpResponse httpResponse = null;

		try {
			httpResponse = client.execute(request, localContext);
			// httpResponse.getAllHeaders();
			// responseCode = httpResponse.getStatusLine().getStatusCode();

			message = httpResponse.getStatusLine().getReasonPhrase();
			final HttpEntity entity = httpResponse.getEntity();
			if (entity != null) {
				final InputStream instream = entity.getContent();
				response = convertStreamToString(instream);
				instream.close();
			}
		} catch (ClientProtocolException e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();
		} catch (SocketException e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();

		} catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
			// e.printStackTrace();
			throw new RuntimeException();
		} finally {
			if (null != httpResponse)
				httpResponse.close();
			if (client != null) {
				client.close();
			}
		}
		return httpResponse;
	}

}