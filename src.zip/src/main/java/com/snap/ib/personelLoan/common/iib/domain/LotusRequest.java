package com.snap.ib.personelLoan.common.iib.domain;

public class LotusRequest {
	private IIBRequest lotusRequest;

	public IIBRequest getLotusRequest() {
		return lotusRequest;
	}

	public void setLotusRequest(final IIBRequest lotusRequest) {
		this.lotusRequest = lotusRequest;
	}
	
	
}
