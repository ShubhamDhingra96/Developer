package com.snap.ib.personelLoan.common.iib.domain;

import java.io.IOException;
import java.util.UUID;
import java.util.logging.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ibm.json.java.JSONObject;
import com.snap.ib.personelLoan.common.ApplicationConstant;

public class RequestBuilder {
	
	final static Logger logger = Logger.getLogger(RequestBuilder.class.getName());
	private IIBRequest lotusRequest;
	private Object requestPayload;
	private String actionName;
	private String moduleName;
	private String subAction;
	private  UserDetail user;
	
	public String getSubAction() {
		return subAction;
	}

	public void setSubAction(final String subAction) {
		this.subAction = subAction;
	}

	public RequestBuilder setUser(final UserDetail user) {
		this.user = user;
		return this;

	}

	public RequestBuilder setActionName(final String actionName) {
		this.actionName = actionName;
		return this;

	}

	public RequestBuilder setModuleName(final String moduleName) {
		this.moduleName = moduleName;
		return this;

	}

	public RequestBuilder setPayload(final Object payload){
		this.requestPayload=payload;
		return this;
	}
	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public String build() throws IOException{
		final Gson gson=new GsonBuilder().setPrettyPrinting().create();
		final String uniqueID = UUID.randomUUID().toString();
		final IIBRequest request=new IIBRequest();
		request.setRequestId(uniqueID);
		final RequestContext context=new RequestContext();
		final ClientDetail client=new ClientDetail();
		client.setAction(this.actionName);
		client.setChannel(ApplicationConstant.MOBILE);
		client.setModule(this.moduleName);
		context.setClient(client);
		context.setUser(this.user);
		request.setContext(context);
		JSONObject jsonObject =new JSONObject();
		if(null!=this.requestPayload){
			jsonObject =JSONObject.parse(gson.toJson(this.requestPayload));
		}
		
		if(null!=this.user && null!=user.getCif()){
				jsonObject.put("cif", user.getCif());
		}
		
		request.setPayload(jsonObject);
		this.lotusRequest=request;
		final LotusRequest lotusRequest=new LotusRequest();
		lotusRequest.setLotusRequest(this.lotusRequest);
		final String payloadStr=gson.toJson(lotusRequest);
		logger.info(payloadStr);
		return payloadStr;
	}
	
	/**
	 * @deprecated 
	 */
	@Deprecated
	public RequestBuilder build(final String action,UserDetail user,final Object payload){
		final String uniqueID = UUID.randomUUID().toString();
		final IIBRequest request=new IIBRequest();
		request.setRequestId(uniqueID);
		final RequestContext context=new RequestContext();
		final ClientDetail client=new ClientDetail();
		client.setAction(action);
		client.setChannel(ApplicationConstant.MOBILE);
		client.setModule("FundsTransfer.BasicJourney");
		if(null==user){
			 user=new UserDetail();
			 user.setDeviceId("");
			 user.setInbUsername("");
			 user.setLotusId("");
			 user.setSim("");
			 user.setUsername("");
			 user.setUserRole("");
		}
		
		context.setClient(client);
		context.setUser(user);
		request.setContext(context);
		request.setPayload(payload);
		this.lotusRequest=request;
		return this;
	}
	
	/**
	 * 
	 * @param action
	 * @param module
	 * @param user
	 * @param payload
	 * @return
	 */
	public RequestBuilder build(final String action,final String subAction, final String module,UserDetail user,final Object payload) throws Exception{
		
		final Gson gson=new GsonBuilder().setPrettyPrinting().create();
		
		JSONObject finalPayload = new JSONObject();
		final String uniqueID = UUID.randomUUID().toString();
		final IIBRequest request=new IIBRequest();
		request.setRequestId(uniqueID);
		final RequestContext context=new RequestContext();
		final ClientDetail client=new ClientDetail();
		client.setAction(action);
		client.setSubAction(subAction);
		client.setChannel(ApplicationConstant.MOBILE);
		client.setModule(module);
		if(null==user){
			 user=new UserDetail();
			 user.setDeviceId("");
			 user.setInbUsername("");
			 user.setLotusId("");
			 user.setSim("");
			 user.setUsername("");
			 user.setUserRole("");
		}
		
		context.setClient(client);
		context.setUser(user);
		request.setContext(context);
		if(null!=payload){
			finalPayload=JSONObject.parse(gson.toJson(payload));
		}
		if(null!=user.getCif()){
			finalPayload.put("cif", user.getCif());

		}
		request.setPayload(finalPayload);
		this.lotusRequest=request;
		logger.info(gson.toJson(this.lotusRequest));
		return this;
	}
	
	public RequestBuilder build(final String action,final String module,UserDetail user,final Object payload){
		
		final Gson gson=new GsonBuilder().setPrettyPrinting().create();
		JSONObject finalPayload = new JSONObject();
		final String uniqueID = UUID.randomUUID().toString();
		final IIBRequest request=new IIBRequest();
		request.setRequestId(uniqueID);
		final RequestContext context=new RequestContext();
		final ClientDetail client=new ClientDetail();
		client.setAction(action);
		client.setChannel(ApplicationConstant.MOBILE);
		client.setModule(module);
		if(null==user){
			 user=new UserDetail();
			 user.setDeviceId("");
			 user.setInbUsername("");
			 user.setLotusId("");
			 user.setSim("");
			 user.setUsername("");
			 user.setUserRole("");
		}
		
		context.setClient(client);
		context.setUser(user);
		request.setContext(context);
		if(null!=payload){
			try {
				finalPayload=JSONObject.parse(gson.toJson(payload));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(null!=user.getCif()){
			finalPayload.put("cif", user.getCif());

		}
		request.setPayload(finalPayload);
		this.lotusRequest=request;
		logger.info(gson.toJson(this.lotusRequest));
		return this;
	}
	
public RequestBuilder build(final String action,final String module,UserDetail user) throws Exception{
		
	    final Gson gson=new GsonBuilder().setPrettyPrinting().create();
		JSONObject payload =new JSONObject();
		
		if(null!=this.requestPayload){
			payload =JSONObject.parse(gson.toJson(this.requestPayload));
		}
		
		final String uniqueID = UUID.randomUUID().toString();
		final IIBRequest request=new IIBRequest();
		request.setRequestId(uniqueID);
		final RequestContext context=new RequestContext();
		final ClientDetail client=new ClientDetail();
		client.setAction(action);
		client.setChannel(ApplicationConstant.MOBILE);
		client.setModule(module);
		if(null==user){
			 user=new UserDetail();
			 user.setDeviceId("");
			 user.setInbUsername("");
			 user.setLotusId("");
			 user.setSim("");
			 user.setUsername("");
			 user.setUserRole("");
		}else{
			if(null!=user.getCif()){
				payload.put("cif", user.getCif());
			}
		}
		
		context.setClient(client);
		context.setUser(user);
		request.setContext(context);
		request.setPayload(payload);
		this.lotusRequest=request;
		logger.info(gson.toJson(this.lotusRequest));
		return this;
	}

	public IIBRequest getLotusRequest() {
		return lotusRequest;
	}

	public void setLotusRequest(final IIBRequest lotusRequest) {
		this.lotusRequest = lotusRequest;
	}

}
