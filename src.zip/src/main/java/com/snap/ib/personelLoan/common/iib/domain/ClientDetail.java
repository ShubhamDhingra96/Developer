package com.snap.ib.personelLoan.common.iib.domain;

public class ClientDetail {
	
	private String module;
	private String action;
	private String subAction;
	private String channel;

	public String getModule() {
		return module;
	}

	public void setModule(final String module) {
		this.module = module;
	}

	public String getAction() {
		return action;
	}

	public void setAction(final String action) {
		this.action = action;
	}

	public String getSubAction() {
		return subAction;
	}

	public void setSubAction(final String subAction) {
		this.subAction = subAction;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(final String channel) {
		this.channel = channel;
	}

}
