package com.snap.ib.personelLoan.common.i18n;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.snap.ib.personelLoan.common.ApplicationConstant;

/**
 * 
 * @author Maksood
 *
 */
public class PropertiesReader {

private  static	PropertiesReader reader;
private final static Logger logger = LoggerFactory.getLogger(PropertiesReader.class ); 
private static String propertiesFileName = ApplicationConstant.REQUEST_MAPPING_FILE;
/*private static String propertiesFileName = ApplicationConstant.MESSAGE_FILE;*/
private static Properties props;

	private static void load() {
		/*props = new Properties();
		try {
			System.out.println("propertiesFileName:"+propertiesFileName);
			InputStream in=	new FileInputStream(propertiesFileName);
			props.load(in);
			in.close();
		} catch (IOException e) {
			logger.error("Failed to load properties", e);
		}*/
		props = new Properties();
		try {
			logger.info("propertiesFileName:"+propertiesFileName);
			final InputStream in=	new FileInputStream(propertiesFileName);
			props.load(in);
			in.close();
		} catch (IOException e) {
			logger.error("Failed to load properties", e);
		}
		
	}

	public static synchronized PropertiesReader getInstance(){
		if (reader == null){
				reader = new PropertiesReader();
				load()	;
			}
		return reader;
	}
	
	public  String getProperty(final String name)  {
		final File file=new File(propertiesFileName);
		if(new java.util.Date().getTime()-file.lastModified()<10000){
			load();	
		}
		return props.getProperty(name);
	}
	
}

