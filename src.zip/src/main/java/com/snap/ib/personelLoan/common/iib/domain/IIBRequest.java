package com.snap.ib.personelLoan.common.iib.domain;

public class IIBRequest {
	
	private RequestContext context;
	private Object payload;
	private String requestId;

	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(final String requestId) {
		this.requestId = requestId;
	}
	public RequestContext getContext() {
		return context;
	}
	public void setContext(final RequestContext context) {
		this.context = context;
	}
	public Object getPayload() {
		return payload;
	}
	public void setPayload(final Object payload) {
		this.payload = payload;
	}
}
