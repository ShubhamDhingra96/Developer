package com.snap.ib.personelLoan.common.provider;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.snap.ib.personelLoan.common.ApplicationConstant;


/**
 * 
 * @author Maksood
 *
 */
@SuppressWarnings("rawtypes")
@Provider
@Consumes({"text/plain","application/json","*/*"})
public class JsonProvider  implements MessageBodyReader {
	
	private final static Logger logger = LoggerFactory.getLogger(JsonProvider.class ); 
    public boolean isReadable(final Class aClass, final Type type, final Annotation[] annotations, final MediaType mediaType) {
        return true;
    }

    @SuppressWarnings("unchecked")
	public Object readFrom(final Class aClass, final Type type, final Annotation[] annotations, final MediaType mediaType, final MultivaluedMap multivaluedMap, final InputStream inputStream) throws IOException, WebApplicationException {
        Object result = null;
        try {
        	final Gson gson=new Gson();
            result = gson.fromJson(getStringFromInputStream(inputStream), aClass); // un marshall custom format to java object here
        	return result;
        }catch (NullPointerException e) {
        	logger.error(ApplicationConstant.ERROR, e);
        }catch (RuntimeException e) {
        	logger.error(ApplicationConstant.ERROR, e);
        }catch (Exception e) {
        	logger.error(ApplicationConstant.ERROR, e);
        }
        return result;
    }
     private static String getStringFromInputStream(final InputStream is) {

		BufferedReader br = null;
		final StringBuilder sb = new StringBuilder();
		String line;
		try {

			br = new BufferedReader(new InputStreamReader(is));
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

		}catch (IOException e) {
			logger.error(ApplicationConstant.ERROR, e);
		}catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
		}finally {
			if (null!=br) {
				try {
					br.close();
				}catch (IOException e) {
					logger.error(ApplicationConstant.ERROR, e);
				}catch (Exception e) {
					logger.error(ApplicationConstant.ERROR, e);
				}
			}
		}
		return sb.toString();
	}
}