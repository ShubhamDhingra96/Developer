package com.snap.ib.personelLoan.common.iib.domain;

public class IIBResponse {
	private IIBResponseType lotusResponse;
	
	private Object data;
	private String responseCode;
	private String responseMessage;

	public Object getData() {
		return data;
	}

	public void setData(final Object data) {
		this.data = data;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(final String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(final String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public IIBResponseType getLotusResponse() {
		return lotusResponse;
	}

	public void setLotusResponse(final IIBResponseType lotusResponse) {
		this.lotusResponse = lotusResponse;
	}
}