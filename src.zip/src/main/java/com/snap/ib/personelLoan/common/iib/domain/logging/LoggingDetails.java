package com.snap.ib.personelLoan.common.iib.domain.logging;

public class LoggingDetails {
	
	private String eventId;
	private String evenyType;
	private String eventTimestamp;
	private String componentType;
	private String serverName;
	private String subServerName;
	private String applicationName;
	private String componentName;
	private String subComponentName;
	private String transactionId;
	private String cif;
	private String userName;
	private String customerIp;
	private String chanelName;
	private String code;	
	private String description;
	
	public String getEventId() {
		return eventId;
	}
	public void setEventId(final String eventId) {
		this.eventId = eventId;
	}
	public String getEvenyType() {
		return evenyType;
	}
	public void setEvenyType(final String evenyType) {
		this.evenyType = evenyType;
	}
	public String getEventTimestamp() {
		return eventTimestamp;
	}
	public void setEventTimestamp(final String eventTimestamp) {
		this.eventTimestamp = eventTimestamp;
	}
	public String getComponentType() {
		return componentType;
	}
	public void setComponentType(final String componentType) {
		this.componentType = componentType;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(final String serverName) {
		this.serverName = serverName;
	}
	public String getSubServerName() {
		return subServerName;
	}
	public void setSubServerName(final String subServerName) {
		this.subServerName = subServerName;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(final String applicationName) {
		this.applicationName = applicationName;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(final String componentName) {
		this.componentName = componentName;
	}
	public String getSubComponentName() {
		return subComponentName;
	}
	public void setSubComponentName(final String subComponentName) {
		this.subComponentName = subComponentName;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(final String transactionId) {
		this.transactionId = transactionId;
	}
	public String getCif() {
		return cif;
	}
	public void setCif(final String cif) {
		this.cif = cif;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(final String userName) {
		this.userName = userName;
	}
	public String getCustomerIp() {
		return customerIp;
	}
	public void setCustomerIp(final String customerIp) {
		this.customerIp = customerIp;
	}
	
	public String getChanelName() {
		return chanelName;
	}
	public void setChanelName(final String chanelName) {
		this.chanelName = chanelName;
	}
	public String getCode() {
		return code;
	}
	public void setCode(final String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(final String description) {
		this.description = description;
	}
}
