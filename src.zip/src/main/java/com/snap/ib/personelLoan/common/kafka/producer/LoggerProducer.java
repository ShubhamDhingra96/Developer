package com.snap.ib.personelLoan.common.kafka.producer;

public class LoggerProducer
  extends Producer
{
  private static Producer producer;
  
  public static Producer getInstance()
  {
    if (null==producer) {
      producer = new LoggerProducer();
    }
    return producer;
  }
  
  public String getTopic()
  {
    return "audit-log";
  }
  
}
