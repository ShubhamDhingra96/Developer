package com.snap.ib.personelLoan.common;

import java.util.Map;
import java.util.Map.Entry;
import com.ibm.mfp.server.security.external.resource.AdapterSecurityContext;
import com.snap.ib.personelLoan.common.iib.domain.UserDetail;

public class BaseResource{

	public static String ompToken = "";

	/**
	 * @param securityContext
	 * @return
	 */
	protected UserDetail getUserSession(final AdapterSecurityContext securityContext) {
		final String clientId = "850001693864";
		final String deviceId = "99999999999";
		final String lotusId = "85001410583";
		final String segmentId = "5";

		final UserDetail detail = new UserDetail();
		if (null!=securityContext && null!=securityContext.getAuthenticatedUser()&& null!=securityContext.getAccessTokenInfo()  ) {
			final Map<String, Object> hashMap = securityContext.getAuthenticatedUser().getAttributes();
			/*for(Entry<String, Object> abc:hashMap.entrySet()){
				//System.out.println("Key from base resource: " + abc.getKey());
				//System.out.println("Value from base resource: " + abc.getValue());
			}*/
			detail.setCif(String.valueOf(hashMap.get("CIF")));
			detail.setLotusId(String.valueOf(hashMap.get("lotusId")));
			detail.setDeviceId(String.valueOf(deviceId));
			detail.setSegmentId(String.valueOf(segmentId));
			detail.setLastLoggedIn(String.valueOf(hashMap.get("lastLoggedIn")));
			detail.setInbUsername(String.valueOf(hashMap.get("inbUsername")));
			detail.setMobileNumber(String.valueOf(hashMap.get("mobileNumber")));
			detail.setLoginCount(String.valueOf(hashMap.get("loginCount")));
			detail.setProfilePasswordSetFlag((Boolean) hashMap.get("profilePasswordSetFlag"));
			detail.setCountryCode(String.valueOf(hashMap.get("countryCode")));
		} else {
			detail.setCif(clientId);
			detail.setLotusId(lotusId);
			detail.setDeviceId(deviceId);
			detail.setSegmentId(segmentId);
		}
		return detail;

	}

	public void putInUserSession(final String key, final String value, final AdapterSecurityContext securityContext) {
		if (null!=securityContext && null!=securityContext.getAuthenticatedUser() ) {
			final Map<String, Object> hashMap = securityContext.getAuthenticatedUser().getAttributes();
			hashMap.put(key, value);
		}
	}

	protected Object getFromUserSession(final String key, final AdapterSecurityContext securityContext) {
		if (null!=securityContext && null!=securityContext.getAuthenticatedUser()) {
			Map<String, Object> hashMap = securityContext.getAuthenticatedUser().getAttributes();
			return hashMap.get(key);
		} else {
			return null;
		}
	}
}
