package com.snap.ib.personelLoan.common.iib.domain;

import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ibm.json.java.JSONObject;
import com.snap.ib.personelLoan.common.ApplicationConstant;

@SuppressWarnings("unchecked")
public class ResponseBuilder {
	
	private static final Logger logger = LoggerFactory.getLogger(ResponseBuilder.class ); 
	private  IIBResponse lotusResponse;
	public IIBResponse getLotusResponse() {
		return lotusResponse;
	}

	public void setLotusResponse(final IIBResponse lotusResponse) {
		this.lotusResponse = lotusResponse;
	}

	/**
	 * 
	 * @param payLoad
	 * @param classObj
	 * @return
	 */
	public static <T> T build(final JSONObject payLoad, final Class<T> classObj) {
		try {
			final Gson gson = new Gson();
			return (T) gson.fromJson(payLoad.toString(), classObj);
		}catch (RuntimeException e) {
			logger.error(ApplicationConstant.ERROR, e);
		}catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
		}
		return null;
	}
	
	/**
	 * 
	 * @param payLoad
	 * @param classObj
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public  IIBResponse parserIIBResponse(final String payLoad, final Class classObj) {
		try {
			
			final Gson gson = new Gson();
			final JsonObject lotusResponseJson=gson.fromJson(payLoad, JsonObject.class);
			final JsonObject lotusResponseObj=lotusResponseJson.get("lotusResponse").getAsJsonObject();
			final JsonObject responseObj=lotusResponseObj.get("response").getAsJsonObject();
			final IIBResponse response = gson.fromJson(responseObj.toString(), IIBResponse.class);
			final String rsponseCode=responseObj.get("responseCode").getAsString();
			final String responseMessage=responseObj.get("responseMessage").getAsString();
			response.setResponseCode(rsponseCode);
			response.setResponseMessage(responseMessage);
			if("0000".equals(rsponseCode)){
				final JsonObject payloadJson=responseObj.getAsJsonObject("payload").getAsJsonObject();
				response.setData(gson.fromJson(payloadJson.toString(),classObj));
			}else{
				final JsonObject errorTag=lotusResponseObj.getAsJsonObject("errorTag").getAsJsonObject();
				if(null!=errorTag){
					final ResponseError responseError=gson.fromJson(errorTag, ResponseError.class);
					if(!responseError.getExceptions().isEmpty()){
						final ExceptionDetail detail=responseError.getExceptions().get(0);
						response.setResponseCode(detail.getErrorCode());
						response.setResponseMessage(detail.getErrorDescription());
					}
				}
			}

			if(null==response.getResponseMessage()||response.getResponseMessage().trim().isEmpty()){
				response.setResponseCode(rsponseCode);
				response.setResponseMessage(responseMessage);
			}
			
			return  response;
		}catch (RuntimeException e) {
			logger.error(ApplicationConstant.ERROR, e);
		}catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
		}
		return null;
	}
	
	/**
	 * @param payLoad
	 * @param classObj
	 * @return
	 */
	
	public static <T> T build(final String payLoad, final Class<T> classObj) {
		try {
			Gson gson = new Gson();
			final Object t = gson.fromJson(payLoad, classObj);
			return (T) t;
		} catch (Exception e) {
			logger.error(ApplicationConstant.ERROR, e);
		}
		return null;

	}

	/**
	 * @param payLoad
	 * @param classObj
	 * @return
	 */
	
	public static <T> T build(final InputStream payLoad, final Class<T> classObj) {
		try{
			Gson gson = new Gson();
			final Object t = gson.fromJson(payLoad.toString(), classObj);
			return (T) t;
		}catch (Exception e){
			logger.error(ApplicationConstant.ERROR, e);
		}
		return null;
	}	
}
