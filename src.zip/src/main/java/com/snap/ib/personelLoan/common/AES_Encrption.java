package com.snap.ib.personelLoan.common;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class AES_Encrption 
{
	//private static Logger logger = LoggerFactory.getLogger(CommonAdapterResource.class);
	public static String encrypt(String input, String key)
	{
	  byte[] crypted = null;
	  try{
	      SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, skey);
	      crypted = cipher.doFinal(input.getBytes());
	    }catch(Exception e){
	    	e.printStackTrace();
	    
	    }
	    return new String(Base64.encodeBase64(crypted));
	}

	
	public static String aesEncrypt(String input, String key)
	{
	  byte[] crypted = null;
	  StringBuffer sb = new StringBuffer();

	  try{
		  MessageDigest md = MessageDigest.getInstance("SHA-256");
	      md.update(input.getBytes());
	      byte byteData[] = md.digest();

	      for (int i = 0; i < byteData.length; i++) {
	      sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
	      }
	      SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.ENCRYPT_MODE, skey);
	      crypted = cipher.doFinal(input.getBytes());
	    }catch(Exception e){
	    	e.printStackTrace();
	    
	    }
	    return new String(Base64.encodeBase64(crypted));
	}
	
	public static String getEncToken(String input, String key) {

		byte[] arr;
		String token = null;
		try {
			if (null != input && null != key) {
				
				arr = key.getBytes("UTF-8");
				MessageDigest md = MessageDigest.getInstance("SHA-256");
				arr = md.digest(arr);
				byte[] arr1 = new byte[16];
				arr1=Arrays.copyOf(arr,16);
				SecretKeySpec skey = new SecretKeySpec(arr1, "AES");
				IvParameterSpec iv = new IvParameterSpec(arr1);
				Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
				cipher.init(Cipher.ENCRYPT_MODE, skey, iv);
				byte[] byteArr = cipher.doFinal(input.getBytes("UTF-8"));
				token = new String(Base64.encodeBase64(byteArr, false));
			}

		} catch (Exception exception) {
		}
		return token;
	}
	
	public static String getDecToken(String input, String key) {

		byte[] arr;
		String token = null;
		try {
			if (null != input && null != key) {
				
				arr = key.getBytes("UTF-8");
				MessageDigest md = MessageDigest.getInstance("SHA-256");
				arr = md.digest(arr);
				byte[] arr1 = new byte[16];
				arr1=Arrays.copyOf(arr,16);
				SecretKeySpec skey = new SecretKeySpec(arr1, "AES");
				IvParameterSpec iv = new IvParameterSpec(arr1);
				Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
				cipher.init(Cipher.DECRYPT_MODE, skey, iv);
				token=new String(cipher.doFinal(Base64.decodeBase64(input)));
				
			}

		} catch (Exception exception) {
		}
		return token;
	}
	
	public static String decrypt(String input, String key){
	    
		byte[] output = null;
		byte[] arr;
		input=input.replaceAll("%2F", "/");
		input=input.replaceAll("%2B", "+");
		input=input.replaceAll("%3D", "=");
	    try{
			/*arr = key.getBytes("UTF-8");
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			arr = md.digest(arr);
			byte[] arr1 = new byte[16];
			arr1=Arrays.copyOf(arr,16);
			SecretKeySpec skey = new SecretKeySpec(arr1, "AES");*/
	      SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
	      Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	      cipher.init(Cipher.DECRYPT_MODE, skey);
	      output = cipher.doFinal(Base64.decodeBase64(input));
	    }catch(Exception e){
	    	e.printStackTrace();
	    
	    }
	    return new String(output);
	}
	
public static void main(String[] args) {
		
		String encdata="uFeo48UBp5WnpfOlkcg/PXTBC3ILC6NXMhXBY9TO2jDfDg+ulg24d6eKT1ej1sB8bpfdqWXEnxy2mPLocXftsAnltfomoqK4hxb6viAf+yzsP573ae7o0CUrvR/t4wZKM8BnTUOyhTlJywGvJjxxhcahMWue+5erkuQA0gF9PKilmS4wNs22clhFBcJC8wgQ7Hkzl7h2Af3u3HEXAoLTIEWNiQbCQ8ujKYMJjoBH9z2TMOqcg2veTVfA1Ey4rgtOS2F93vo/O3vQEDNM+LQV3CWRtj/juYacDznupnPnZ0WJySttDkrr5ibFUcmNGbsMcZHqCLZuyFXPI7CLuw08Am/MnfvXDp5EbVuMkdX77d0DP6mGlk33wcikEuOrkV7boIOwml17IoNcfG1at3pjppQiLEUBTTGVbUiV23E/9D9VjnfheV47IVdpEPSofv8k3l13qGbJTI7JKd/AMs/07EdjZmBDJDMuU/0gLTDNGSDo4P9uG6BIgPsu9zG90qVYpdo05TI3nzZoyMm9KkEeBWvHvzsktbnhktTM1FyRWGFbBM0ItLSNbX+pe3FqGcstoLK2OnVI4x53/WlBSlapo4itY7FLGTCvdZ+72GbFPzUQRw5R10GNvohANaTRlvA/VRwlgdc6z9ZWlbmosgocc3cF4uBDzqjC4zC1iSL8Lkg=";
        System.out.println("YesBankResponse::: "+AES_Encrption.getDecToken(encdata, "Indiabulls2018"));
        //AES_Encrption.decrypt(encdata, "Indiabulls2018");
	}

	public static String checkSum(String input) throws NoSuchAlgorithmException
	{

        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(input.getBytes());
 
        byte byteData[] = md.digest();
        //convert the byte to hex format method 2
        StringBuffer hexString = new StringBuffer();
    	for (int i=0;i<byteData.length;i++) {
    		String hex=Integer.toHexString(0xff & byteData[i]);
   	     	if(hex.length()==1) hexString.append('0');
   	     	hexString.append(hex);
    	}
    
    	return  hexString.toString();
	}
	
	public static long generateRandom(int length) {
	    Random random = new Random();
	    char[] digits = new char[length];
	    digits[0] = (char) (random.nextInt(9) + '1');
	    for (int i = 1; i < length; i++) {
	        digits[i] = (char) (random.nextInt(10) + '0');
	    }
	    return Long.parseLong(new String(digits));
	}
	
}