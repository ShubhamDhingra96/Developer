package com.snap.ib.personelLoan.common.rest.client;

public enum RequestMethod
{
GET,
POST,
PUT,
DELETE,
PATCH
}