package com.snap.ib.personelLoan.common.iib.domain;

public class ClientInfo {

}
