package com.snap.ib.personelLoan.common.kafka.producer;

public class ClickStreamProducer
  extends Producer
{
  private static Producer producer;
  
  public static Producer getInstance()
  {
    if (producer == null) {
      producer = new ClickStreamProducer();
    }
    return producer;
  }
  
  public String getTopic()
  {
    return "ClickStream";
  }

}
