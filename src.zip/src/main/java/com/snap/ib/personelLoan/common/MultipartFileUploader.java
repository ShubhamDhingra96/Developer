package com.snap.ib.personelLoan.common;

 
/**
 * This program demonstrates a usage of the MultipartUtility class.
 * @author www.codejava.net
 *
 */

public class MultipartFileUploader {
 
    /*public static void main(String[] args) {
    	System.out.println("Starting");
        String charset = "UTF-8";
        File uploadFile1 = new File("C:\\Users\\Yash Semwal\\Downloads\\IndusIndStatement.pdf");
        String requestURL = "http://demo.perfios.com/KuberaVault/insights/api/statement/upload";
 
        try {
            MultipartUtility multipart = new MultipartUtility(requestURL,charset);
             
            multipart.addHeaderField("User-Agent", "CodeJava");
            multipart.addHeaderField("Test-Header", "Header-Value");
            multipart.addFormField("vendorId", "indiabullsVentureTest");
            multipart.addFormField("perfiosTransactionId", "Update Me");
            multipart.addFilePart("file", uploadFile1);
 
            List<String> response = multipart.finish();
            System.out.println("SERVER REPLIED:");
             
            for (String line : response) {
                System.out.println(line);
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
        System.out.println("Over");
    }*/
}