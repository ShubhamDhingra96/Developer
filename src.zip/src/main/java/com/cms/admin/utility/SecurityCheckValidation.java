
package com.cms.admin.utility;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cms.admin.bean.CmsCustValidation;
import com.cms.admin.bean.Error_Messages;

@Component
public class SecurityCheckValidation implements Validator {

	@Autowired
	private Environment env;

	@Override
	public boolean supports(Class<?> clazz) {

		return false;

	}

	@Override
	public void validate(Object target, Errors error) {

		ValidationUtils.rejectIfEmptyOrWhitespace(error, "proxyNumber", env.getProperty("customer.proxy.number.empty"));
		
		//Validation for Bin SetUp
		ValidationUtils.rejectIfEmptyOrWhitespace(error, "bin", env.getProperty("binsetup.bin.empty"));

		CmsCustValidation user = (CmsCustValidation) target;

		System.out.println("===T==============>>>>>>>>>>>inside securityCheckValidation!!");

		String bin = env.getRequiredProperty("binsetup.bin.regex");
		String groupcode=env.getRequiredProperty("binsetup.bingroupcode.regex");
		
		

		Map<String, Object> errors = new HashMap<String, Object>();

		if (!user.getBin().matches(bin)) {
			errors.put("bin", env.getProperty("binsetup.bin.invalid"));
		}
		if (!user.getGroupCode().matches(groupcode)) {
			errors.put("groupcode", env.getProperty("binsetup.bingroupcode.invalid"));
		}

		if (!errors.isEmpty()) {
			Error_Messages.SetError(errors);
		}

	}

}
