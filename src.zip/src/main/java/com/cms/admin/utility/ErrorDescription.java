package com.cms.admin.utility;

import java.util.HashMap;
import java.util.Map;

/**
 * @author  : uday.kumar
 * @Project : CMS 
 * @version : 1.0
 * 
 */

public class ErrorDescription {

		private static Map<String, String> codeToDescriptionMap = new HashMap<String, String>();

		static {

			codeToDescriptionMap.put("000", "Invalid Request!");
			codeToDescriptionMap.put("0000", "Customer already exist !");
			
			codeToDescriptionMap.put("00", "SUCCESS");
			codeToDescriptionMap.put("03", "Unable to process the request");
			codeToDescriptionMap.put("09", "Transaction amount is greater than card account balance");
			codeToDescriptionMap.put("10", "Invalid Card No");
			codeToDescriptionMap.put("11", "Error While Extracting Message Format");
			codeToDescriptionMap.put("17", "No records found");
			codeToDescriptionMap.put("20", "Error parsing ASA response");
			codeToDescriptionMap.put("45", "Card is in Closed status/TXN AMOUNT should not be in negative");
			codeToDescriptionMap.put("47", "Card is Not Active");
		}
		
		public static String getDescription(String code) 
		{
			String description = codeToDescriptionMap.get(code);
			if (description == null) 
			{
				description = "Invalid Error Code!";
			}
			return description;
		}
}