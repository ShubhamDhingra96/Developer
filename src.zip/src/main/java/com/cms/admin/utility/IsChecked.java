package com.cms.admin.utility;

public class IsChecked {

	public static final char TRUE = '0';
	public static final char FALSE = '1';

}
