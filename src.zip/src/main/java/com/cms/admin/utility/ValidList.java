package com.cms.admin.utility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.validation.Valid;

public class ValidList<E>  {

    @Valid
    private List<E> list;
    
    public void setList(List<E> list) {
		this.list = list;
	}
    
    public List<E> getList() {
		return list;
	}
    

    @Override
	public String toString() {
		return "ValidList [list=" + list + "]";
	}
    
    


    // Other list methods ...
}