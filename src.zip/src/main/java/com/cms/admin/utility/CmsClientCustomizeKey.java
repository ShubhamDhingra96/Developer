package com.cms.admin.utility;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class CmsClientCustomizeKey implements IdentifierGenerator {

	@Override
	public Serializable generate(SharedSessionContractImplementor si, Object object) throws HibernateException {
		String clientTxnNo = "TXN";
		Connection con = si.connection();
		String query = "select CMSCLIENT_SEQ.nextval from dual";
		try {
			String id = "";
			String appendId = "";
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.next()) {
				id = rs.getString(1);
			}
			if(id.length()<3) {
				for(int x=0;x<=id.length();x++)
					appendId+="0";	
			}
			clientTxnNo = clientTxnNo +appendId+id;
			return clientTxnNo;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
