package com.cms.admin.utility;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Bcrypt {
	
	private String encryptPassword;
	BCryptPasswordEncoder passwordEncoder;
	

	public Bcrypt(String password) {		
		passwordEncoder = new BCryptPasswordEncoder();
		this.encryptPassword = passwordEncoder.encode(password);
		
	}

	public String getEncryptPassword() {
		return encryptPassword;
	}

	public void setEncryptPassword(String encryptPassword) {
		this.encryptPassword = encryptPassword;
	}

	public BCryptPasswordEncoder getPasswordEncoder() {
		return passwordEncoder;
	}

	public void setPasswordEncoder(BCryptPasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}
	
	

}
