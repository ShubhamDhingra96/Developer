package com.cms.admin.api;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import com.cms.admin.bean.AESEncryption;


@Component
public class DES_Encryption_Decryption {

	static Cipher cipher;
	static byte[] b =null;

	public static SecretKey CipherKey() throws Exception {

		KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
		keyGenerator.init(128);
		SecretKey secretKey = keyGenerator.generateKey();
		cipher = Cipher.getInstance("AES");
		b = secretKey.getEncoded();
		return secretKey;

	}
	
	public static SecretKey CiphersKey(byte[] keys) throws Exception {	
		SecretKey secretKey = new SecretKeySpec(keys, "AES");		
		return secretKey;

	}

	public AESEncryption getEncrypt(String str) throws Exception {
		SecretKey secretKey = DES_Encryption_Decryption.CipherKey();
		AESEncryption aecEnc = new AESEncryption();
		aecEnc.setScreteKeyByte(b);
		aecEnc.setEncryptedKey(encrypt(str, secretKey));
		return aecEnc;
	}

	public String getDecrypt(AESEncryption aecEnc) throws Exception {
		
		SecretKey originalKey = new SecretKeySpec(aecEnc.getScreteKeyByte(), 0, aecEnc.getScreteKeyByte().length, "AES");
		
		return decrypt(aecEnc.getEncryptedKey(), originalKey);
	}

	public static String encrypt(String plainText, SecretKey secretKey) throws Exception {
		byte[] plainTextByte = plainText.getBytes();
		cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;
	}

	public static String decrypt(String encryptedText, SecretKey secretKey) throws Exception {
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(encryptedText);
		cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);
		return decryptedText;
	}
	
	
	
}