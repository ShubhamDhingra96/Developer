package com.cms.admin.security;


import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;

@Configuration
@EnableResourceServer
@EnableConfigurationProperties(SecurityProperties.class)
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
	

	private static final String ROOT_PATTERN = "/**";

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/default/**").permitAll().antMatchers("/card/*").permitAll()
		.antMatchers("/location/**").permitAll()
		.antMatchers("/accessrights/**").permitAll()
		.antMatchers("/client/**").permitAll()
		.antMatchers("/PlasticSetup/**").permitAll()
		.antMatchers("/usages/**").permitAll()
		.antMatchers("/binSetup/**").permitAll()
		.antMatchers("/binGroupSetup/**").permitAll()
		.antMatchers("/saveFeeDetails/**").permitAll()
		.antMatchers("/getFeeDetails/**").permitAll()
		.antMatchers("/getFeeDetails/{feeCode}/**").permitAll()
		.antMatchers("/updateFeeDetails/**").permitAll()
		.antMatchers("/cmsFeeDetails/{user}/{parameter}/**").permitAll()
		.antMatchers("/getGroupTransactionData/**").permitAll()
		.antMatchers("/limit/**").permitAll()
		.antMatchers("/getTransactionData/**").permitAll()
		
		.antMatchers("/getLimitDetails/**").permitAll()
		.antMatchers("/saveLimitDetails/**").permitAll()
		.antMatchers("/updateLimitDetails/**").permitAll()
		.antMatchers("/cardusageDetails/**").permitAll()
		.antMatchers("/ProgramDefinition/**").permitAll()
		.antMatchers("/ProgramGroupTypeDefinition/**").permitAll()
		.antMatchers("/CountryCurrency/**").permitAll()
		.antMatchers("/getLimitDetails/{limitCode}/**").permitAll()
		.antMatchers("/customerRegister/**").permitAll()
		.antMatchers("/transaction/**").permitAll()
				.antMatchers("/securityCheckValidation").permitAll().antMatchers(HttpMethod.GET, ROOT_PATTERN)
				.access("#oauth2.hasScope('read')").antMatchers(HttpMethod.POST, ROOT_PATTERN)
				.access("#oauth2.hasScope('write')").antMatchers(HttpMethod.PATCH, ROOT_PATTERN)
				.access("#oauth2.hasScope('write')").antMatchers(HttpMethod.PUT, ROOT_PATTERN)
				.access("#oauth2.hasScope('write')").antMatchers(HttpMethod.DELETE, ROOT_PATTERN)
				.access("#oauth2.hasScope('write')");
	}
}
