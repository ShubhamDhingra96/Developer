package com.cms.admin.security;

import java.security.KeyPair;

import javax.sql.DataSource;

//import org.apache.commons.io.IOUtils;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.oauth2.provider.token.store.KeyStoreKeyFactory;

@Configuration
@EnableAuthorizationServer
@EnableConfigurationProperties(SecurityProperties.class)
public class AuthorizationServerConfiguration extends AuthorizationServerConfigurerAdapter {

	private final DataSource dataSource;
	private final PasswordEncoder passwordEncoder;
	private final AuthenticationManager authenticationManager;
	private final SecurityProperties securityProperties;

	private JwtAccessTokenConverter jwtAccessTokenConverter;
	private TokenStore tokenStore;
//	    private String signingKey="-----BEGIN PUBLIC KEY-----\r\n" + 
//	    		"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvWABda47ijl+7mPYCRu3\r\n" + 
//	    		"GHKNlkYhSV0RjQfEqubQPt1YGCVfm6Tho25cZtxLHy/Z7j6imTMPyM3+2dmt1lhy\r\n" + 
//	    		"iWGAJS56Gqm4h7qCvnf0Xpjfq46wXuZqZg39dmNKFWuQbaJ0K7FNU9q9v7Srbi0/\r\n" + 
//	    		"dLSjqiOabmGWvP0C6yoYOEkaAxVqwIaneCqPrUj7b4mhPFBE1XB/XcPv4qLOtDBs\r\n" + 
//	    		"9WU9IbHcnsAIyz+rA1SzEEricGuVDbmiaA3wNIb8s4yBGMuLal0xv3z9fSY83/x5\r\n" + 
//	    		"YFfY4QUlpt2U5TMpiWvm9yBrq7lu/Wj1vLrt2EediA8wJt5vMv++llV1uggdUxcF\r\n" + 
//	    		"eQIDAQAB\r\n" + 
//	    		"-----END PUBLIC KEY-----";

	private String privateKey = "-----BEGIN RSA PRIVATE KEY-----\r\n"
			+ "MIIEpAIBAAKCAQEA5W89FHfXrJOWnXNEvFw5s30xSjzSMcwiomKX7szvv3bwXwAB\r\n"
			+ "CP2DLGlyeh6ku6v4Cp11IYciZMyikRipOgySLXwD20ZbspNc7ey3e2HSu58Dugq0\r\n"
			+ "JxWWN+z7yy2KR7l8ulJHjWmFGLbXG/I+gwDfn29BD+zoKgR3aP25RqkMnvDTRju/\r\n"
			+ "wyCZzez3a19+q+GyuYOJRhDHCY4FeMLsDoVl30lUTItbdiC/Thso+VfQRb7DZfTi\r\n"
			+ "UyOTsbD4FXyinZSSlUfz1TNAAluQtJHquX47O0Ev8vJvrObuKBLf9QpiU9FjrIu1\r\n"
			+ "4R1noRZMBb0dat+Jybr6hoPfcuT8Uy6yC3VtnwIDAQABAoIBAApEmTIyTtetXz86\r\n"
			+ "qmfXpMlwn+UXpbyOyzoDOZN5Xn1uIEHQKTuyxM0XBwWKG4s+ngIzm8tdVd+2/MuL\r\n"
			+ "k/9CEsSwWSfWFUJ/r9gCERAXh6vX6P3JftiE8c0c8QPdzON63KcmCYe9ojRB8oyQ\r\n"
			+ "odWRE3D6NKo2ywkeXA251THhXOw7+zK6rZJhTqqrm6gHEMFl4WywRwQ94roAoy31\r\n"
			+ "nOM7fNbuX7SFC5YY4fzeI/6osiMkrI84uCZA6tfiwsknRQGa9qnatwlOSbdJcOIn\r\n"
			+ "xCHtX2BIBhvPZzOWeVD4282nJ+qYdHgbw6B0ZkjO0+8VheNPImYki0IEs84XxVu1\r\n"
			+ "rxch4VkCgYEA/GDcofGGn4Qqd33eP3z2w73twLYz6uL7cQllNHNobYIDlPND3gI1\r\n"
			+ "GNHTlZ+HU5YpsoMGbiDRuWATyITYua4JUE7L93aty4K97fYm2xMLA7vS3TpvJmMV\r\n"
			+ "Sg4Mxz0slQnK7VQO1GBJFfg5+1ZArHJVuufz4pGhMYISKb1u72FfBnsCgYEA6LoX\r\n"
			+ "FP+Fz7I2jp9/m3zkk89b2n8zRcW+jeyMKji2fnsxF9zWA2tTbAcilGps0/uI31Gr\r\n"
			+ "NsB/UZBnn3gFkLQxxU1vE9iwTxdi94fPUuJ02UNCH8Md3OJUfG+4WOniB3Drv4bQ\r\n"
			+ "hVBMRKLqY+U2WxPbGAAoNEY8gjrgT+GBuEs2vi0CgYAjMJZS9kxhHZqWQrSkgZYe\r\n"
			+ "wPLPthgTHkcVAcxcveLHsiMxt6G06PXiWg94g1/pJbz2qRJSdL0Jbf4ULYHSkhO2\r\n"
			+ "YOZLwP6Gq9ozvei5DzSv9pZ2RlmNLq+fPcpGVZ9LwKvM37WZoztNlujuxJ4L7X1K\r\n"
			+ "rGDzLH8fWhWSQFmhgyAu1QKBgQDkoBuY10UfOtX52prDpzfuNSDpT1iRTKfcSOuR\r\n"
			+ "dtFhA6jA5oOgLElxsLi50KtEvLBDorluOkFZYWFK+d+Nvle+mklq186shC8HOPXl\r\n"
			+ "WO6tmTNWfJnTqsyQyjfxsSIJaVdPeiNTNAUY0Gsu47g4VRNBSrY0VGORFEHUd5a1\r\n"
			+ "8729qQKBgQDDGXf7bEHSIkuCBERAzIusspHpki8PaRaEP9hh50fdOgIkzsYzSHK3\r\n"
			+ "S3WNtEoIKEOYQLwCDODXu7vlHnVhsESSXl73dQru9aMJxeK+MZwAEcHJ9tUoxS66\r\n"
			+ "TSOWJ4W1p8R3A44rpdemrdAK/5gqcqTZyuVBswr+r+mrhtGsliqvPg==\r\n" + "-----END RSA PRIVATE KEY-----";

	private String signingKey = "-----BEGIN PUBLIC KEY-----\r\n"
			+ "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5W89FHfXrJOWnXNEvFw5\r\n"
			+ "s30xSjzSMcwiomKX7szvv3bwXwABCP2DLGlyeh6ku6v4Cp11IYciZMyikRipOgyS\r\n"
			+ "LXwD20ZbspNc7ey3e2HSu58Dugq0JxWWN+z7yy2KR7l8ulJHjWmFGLbXG/I+gwDf\r\n"
			+ "n29BD+zoKgR3aP25RqkMnvDTRju/wyCZzez3a19+q+GyuYOJRhDHCY4FeMLsDoVl\r\n"
			+ "30lUTItbdiC/Thso+VfQRb7DZfTiUyOTsbD4FXyinZSSlUfz1TNAAluQtJHquX47\r\n"
			+ "O0Ev8vJvrObuKBLf9QpiU9FjrIu14R1noRZMBb0dat+Jybr6hoPfcuT8Uy6yC3Vt\r\n" + "nwIDAQAB\r\n"
			+ "-----END PUBLIC KEY-----";

	public AuthorizationServerConfiguration(final DataSource dataSource, final PasswordEncoder passwordEncoder,
			final AuthenticationManager authenticationManager, final SecurityProperties securityProperties) {
		this.dataSource = dataSource;
		this.passwordEncoder = passwordEncoder;
		this.authenticationManager = authenticationManager;
		this.securityProperties = securityProperties;

	}

	@Bean
	public JwtAccessTokenConverter jwtAccessTokenConverter() {
		if (jwtAccessTokenConverter != null) {
			return jwtAccessTokenConverter;
		}
	       
		SecurityProperties.JwtProperties jwtProperties = securityProperties.getJwt();		
		KeyPair keyPair = keyPair(jwtProperties, keyStoreKeyFactory(jwtProperties));
		jwtAccessTokenConverter = new JwtAccessTokenConverter();
		jwtAccessTokenConverter.setKeyPair(keyPair);
 	
//		jwtAccessTokenConverter = new JwtAccessTokenConverter();
//		jwtAccessTokenConverter.setSigningKey(privateKey);
//		jwtAccessTokenConverter.setVerifierKey(signingKey);

		return jwtAccessTokenConverter;
	}

	@Bean
	public TokenStore tokenStore() {
		if (tokenStore == null) {
			tokenStore = new JwtTokenStore(jwtAccessTokenConverter());
		}
		return tokenStore;
	}

	@Bean
	public DefaultTokenServices tokenServices(final TokenStore tokenStore,
			final ClientDetailsService clientDetailsService) {
		DefaultTokenServices tokenServices = new DefaultTokenServices();
		tokenServices.setSupportRefreshToken(true);
		tokenServices.setTokenStore(tokenStore);
		tokenServices.setClientDetailsService(clientDetailsService);
		tokenServices.setAuthenticationManager(this.authenticationManager);
		return tokenServices;
	}

	@Override
	public void configure(final ClientDetailsServiceConfigurer clients) throws Exception {
		clients.jdbc(this.dataSource);
	}

	@Override
	public void configure(final AuthorizationServerEndpointsConfigurer endpoints) {
		endpoints.authenticationManager(this.authenticationManager).accessTokenConverter(jwtAccessTokenConverter())
				.tokenStore(tokenStore());

	}

	@Override
	public void configure(final AuthorizationServerSecurityConfigurer oauthServer) {
		oauthServer.passwordEncoder(this.passwordEncoder).tokenKeyAccess("permitAll()")
				.checkTokenAccess("isAuthenticated()");
	}

	private KeyPair keyPair(SecurityProperties.JwtProperties jwtProperties, KeyStoreKeyFactory keyStoreKeyFactory) {
		return keyStoreKeyFactory.getKeyPair(jwtProperties.getKeyPairAlias(),
				jwtProperties.getKeyPairPassword().toCharArray());
	}

	private KeyStoreKeyFactory keyStoreKeyFactory(SecurityProperties.JwtProperties jwtProperties) {
		return new KeyStoreKeyFactory(jwtProperties.getKeyStore(), jwtProperties.getKeyStorePassword().toCharArray());
	}

}
