package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsAcquiredNetworkId;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsNetworkType;

@Repository
public class AcquiredNetworkDaoImpl implements AcquiredNetworkDao {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public CmsAcquiringNetworkGroup saveDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup) {
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.save(cmsAcquiringNetworkGroup);
			return cmsAcquiringNetworkGroup;
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}

	}

	@Override
	public CmsAcquiringNetworkGroup updateDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup) {
		Session session = null;

		try {
			session = sessionFactory.getCurrentSession();
			session.update(cmsAcquiringNetworkGroup);
			return cmsAcquiringNetworkGroup;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsAcquiringNetworkGroup deleteDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup) {
		Session session = null;

		try {
			session = sessionFactory.getCurrentSession();
			session.delete(cmsAcquiringNetworkGroup);
			return cmsAcquiringNetworkGroup;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<CmsAcquiringNetworkGroup> getAllCmsAcquiredNetwork() {
		try {

			return sessionFactory.getCurrentSession()
					.createQuery("from CmsAcquiringNetworkGroup", CmsAcquiringNetworkGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsNetworkType> getAll() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsNetworkType", CmsNetworkType.class)
					.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsAcquiredNetworkId> getAllDetail() {
		try {
			return sessionFactory.getCurrentSession()
					.createQuery("from CmsAcquiredNetworkId", CmsAcquiredNetworkId.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsAcquiringNetworkGroup checkAllCmsAcquiredNetwork(String user, String groupCode) {
		try {

			return sessionFactory.getCurrentSession().createQuery(
					"from CmsAcquiringNetworkGroup where insertedBy='" + user + "' AND groupCode='" + groupCode + "'",
					CmsAcquiringNetworkGroup.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
