package com.cms.admin.dao;

import com.cms.admin.entity.CmsMerchantMccGroup;
import com.cms.admin.entity.CmsModules;

public interface CmsMerchantMCCDao {
	
	public CmsMerchantMccGroup get(CmsMerchantMccGroup group); 

}
