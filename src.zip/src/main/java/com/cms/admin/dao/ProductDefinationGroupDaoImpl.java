package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.ProductTypeDefinition;

@Repository
public class ProductDefinationGroupDaoImpl implements ProductDefinationGroupDao {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public ProductTypeDefinition saveDetail(ProductTypeDefinition productTypeDefinition) {
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.save(productTypeDefinition);
			return productTypeDefinition ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<ProductTypeDefinition> getAll(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from ProductTypeDefinition where insertedBy='" + username + "'", ProductTypeDefinition.class).getResultList();
		} catch(Exception e) {
			e.printStackTrace();
			
		}
		return null;
		
	}

}
