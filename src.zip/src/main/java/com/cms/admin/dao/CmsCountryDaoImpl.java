package com.cms.admin.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsCountryCurrency;

@Repository
public class CmsCountryDaoImpl implements CmsCountryDao {

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public List<CmsCountryCurrency> getAll() {
		try {
			return sessionfactory.getCurrentSession().createQuery("from CmsCountryCurrency", CmsCountryCurrency.class)
					.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
