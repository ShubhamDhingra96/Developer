package com.cms.admin.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMCustomer;
import com.cms.admin.entity.CmsMIdentificationType;
@Repository
public class CmsCustomerRegistrationDaoImpl implements CmsCustomerRegistrationDao{

	@Autowired
	private SessionFactory sessionfactory;
	
	@Override
	public Integer saveCustomerRegister(CmsMCustomer cmsMCustomer) {
		// TODO Auto-generated method stub
		
		Session session = sessionfactory.getCurrentSession();
		Integer id = (Integer) session.save(cmsMCustomer);
		System.out.println("id.."+id);
		return id;
	}

	@Override
	public CmsClientLogin save(CmsClientLogin cmsClientLogin) {
		try {
			Session session = sessionfactory.getCurrentSession();
			session.save(cmsClientLogin);
			return cmsClientLogin;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Integer saveIdentificationType(CmsMIdentificationType cmsMIdentificationType) {
		try {
			Session session = sessionfactory.getCurrentSession();
			Integer id = (Integer)session.save(cmsMIdentificationType);
			System.out.println("id...."+id);
			return id;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
