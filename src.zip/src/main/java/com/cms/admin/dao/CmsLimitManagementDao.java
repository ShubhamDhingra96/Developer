package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMTransaction;



public interface CmsLimitManagementDao {
	
	public CmsMLimitManagement saveLimitManagementDetails(CmsMLimitManagement limitManagement); 
	
	public List<CmsMLimitManagement> getLimitDetails();
	
	public boolean updateLimitDetails(CmsMLimitManagement limitManagement); 
	
	public CmsMLimitManagement getLmitDetailByCode(String limitCode);
	
	public List<CmsMTransaction> getTransactionType(); 	
	
	public CmsMLimitManagement getLmitDetailByCode(String createdby,String limitCode);

}
