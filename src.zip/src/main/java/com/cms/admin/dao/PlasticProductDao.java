package com.cms.admin.dao;

import java.util.List;
import com.cms.admin.entity.CmsPlasticProductSetup;

public interface PlasticProductDao {

	public CmsPlasticProductSetup savePlasticProductSetupDetails(CmsPlasticProductSetup entity);

	public List<CmsPlasticProductSetup> getPlasticProductList() throws Exception;

	public List<CmsPlasticProductSetup> getSpecificPlasticProductList(String clientId) throws Exception;
	
	public CmsPlasticProductSetup getSpecificPlasticProductList(String clientId,String groupCode) throws Exception;
}
