package com.cms.admin.dao;

import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMCustomer;
import com.cms.admin.entity.CmsMIdentificationType;

public interface CmsCustomerRegistrationDao {

	public Integer saveCustomerRegister(CmsMCustomer cmsMCustomer);
	
	public CmsClientLogin save(CmsClientLogin cmsClientLogin);
	
	public Integer saveIdentificationType(CmsMIdentificationType cmsMIdentificationType);
	
	
}
