package com.cms.admin.dao;

import com.cms.admin.entity.LogCmsException;

public interface LoggingDao {
	
	 public Integer saveExceptionLog(LogCmsException exceptionLog);

}
