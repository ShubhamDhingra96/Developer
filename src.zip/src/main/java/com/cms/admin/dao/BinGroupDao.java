package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.entity.CmsPlasticProductSetup;

public interface BinGroupDao {

	public Integer addBinGroup(CmsBinGroup bean)throws Exception;
	
	public CmsBin getBinDetails(BinGroupSetupBin bean)throws Exception;
	
	public CmsBin getCmsBinDetails(String binNumber)throws Exception; 
	
	public List<CmsPlasticProductSetup> getPlasticCodelist()throws Exception; 
	
	public List<CmsBinGroup> getBinGroupSetUpDetails();
	
	public CmsBinGroup getCmsBinGroupDetails(String groupCode)throws Exception; 
	
	public CmsBinGroup getCmsBinGroupDetails(String user,String groupCode)throws Exception; 

	public List<CmsBinGroup> getBinGroupClientId(String clientId) throws Exception;
	
	public List<CmsBinGroup> getAll(String user);
}
