package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsMccGroupCode;
import com.cms.admin.entity.CmsMerchantDetails;
import com.cms.admin.entity.CmsMerchantMccGroup;

@Repository
public class MerchantDetailsImpl implements MerchantDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsMerchantDetails saveDetails(CmsMerchantDetails cmsMerchantDetails) {
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.save(cmsMerchantDetails);
			return cmsMerchantDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsMerchantDetails updateDetails(CmsMerchantDetails cmsMerchantDetails) {
		Session session = null;

		try {
			session = sessionFactory.getCurrentSession();
			session.update(cmsMerchantDetails);
			return cmsMerchantDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsMerchantDetails deleteDetails(CmsMerchantDetails cmsMerchantDetails) {
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			session.delete(cmsMerchantDetails);
			return cmsMerchantDetails;
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}

	}

	@Override
	public List<CmsMerchantMccGroup> getAll() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsMerchantMccGroup" , CmsMerchantMccGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsMccGroupCode> getAllDetail() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsMccGroupCode", CmsMccGroupCode.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsMerchantDetails getMerchant(String username, String groupCode) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsMerchantDetails where insertedBy='"+username+"' AND merchantGroupCode='"+groupCode+"'", CmsMerchantDetails.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
