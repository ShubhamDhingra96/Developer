package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsCities;
import com.cms.admin.entity.CmsCountries;
import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;

public interface CountriesStatesCitiesDao {

	public CmsCountries getCountries(Number countryid);

	public List<CmsCountries> getCountries();
	
	public List<CmsCountry> getCountry();

	public CmsStates getStates(Long stateId);

	public CmsCities getCities(Long cityid);

	public List<CmsStates> getStatesByCountryid(Long countryid);

	public List<CmsCities> getCitiesByStateid(Long stateid);

}
