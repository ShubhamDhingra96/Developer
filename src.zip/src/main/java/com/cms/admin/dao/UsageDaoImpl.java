package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsCountryGroup;
import com.cms.admin.entity.CmsDeliveryChannel;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMerchantDetails;

@Repository
public class UsageDaoImpl implements UsageDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsCountryGroup save(CmsCountryGroup cmsCountryGroup) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsCountryGroup);
			return cmsCountryGroup;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsCountryGroup update(CmsCountryGroup cmsCountryGroup) {
		// TODO Auto-generated method stub
		throw new RuntimeException("Does not implements");
	}

	@Override
	public CmsCountryGroup getCountryGroup(Integer groupId) {
		try {
			return sessionFactory.getCurrentSession().get(CmsCountryGroup.class, groupId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsDeliveryChannelGroup save(CmsDeliveryChannelGroup cmsDeliveryChannelGroup) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsDeliveryChannelGroup);
			return cmsDeliveryChannelGroup;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsDeliveryChannelGroup update(CmsDeliveryChannelGroup cmsDeliveryChannelGroup) {

		throw new RuntimeException("Method does not implements");
	}

	@Override
	public CmsDeliveryChannelGroup getDeliveryChannelGroup(Integer groupId) {
		try {
			return sessionFactory.getCurrentSession().get(CmsDeliveryChannelGroup.class, groupId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCountryGroup> getAllCountryGroup() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsCountryGroup",CmsCountryGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsDeliveryChannelGroup> getAllDeliveryChannelGroup() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsDeliveryChannelGroup",CmsDeliveryChannelGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsDeliveryChannel> getAll() {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsDeliveryChannel", CmsDeliveryChannel.class).getResultList();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsCountryGroup getCountryGroup(String username, String groupCode) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsCountryGroup where insertedBy='"+username+"' and groupCode='"+groupCode+"' ",CmsCountryGroup.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsDeliveryChannelGroup getDeliveryChannelGroup(String username, String groupCode) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsDeliveryChannelGroup where insertedBy='"+username+"' and groupCode='"+groupCode+"' ",CmsDeliveryChannelGroup.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCountryGroup> getCountryGroup(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsCountryGroup where insertedBy='"+username+"' ",CmsCountryGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsDeliveryChannelGroup> getDeliveryChannelGroup(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsDeliveryChannelGroup where insertedBy='"+username+"'",CmsDeliveryChannelGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsAcquiringNetworkGroup> getAcquiringNetworkGroup(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsAcquiringNetworkGroup where insertedBy='"+username+"'",CmsAcquiringNetworkGroup.class).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCardUsage> viewCardUsageSetting(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsCardUsage where insertedBy='"+username+"'",CmsCardUsage.class).getResultList();
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsMerchantDetails> viewMerchantDetails(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsMerchantDetails where insertedBy='"+username+"'",CmsMerchantDetails.class).getResultList();
		}catch(Exception e) {
			e.printStackTrace();
			
		return null;	
		}
	}

	@Override
	public List<CmsMLimitManagement> viewLimitManagement(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsMLimitManagement where createdby='"+username+"'",CmsMLimitManagement.class).getResultList();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsFeeManagement> viewFeeManagement(String username) {
		try {
			return sessionFactory.getCurrentSession().createQuery("from CmsFeeManagement where createdby='"+username+"'",CmsFeeManagement.class).getResultList();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	

}
