package com.cms.admin.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsFunctions;
import com.cms.admin.entity.CmsJobs;
import com.cms.admin.entity.CmsModules;

@Repository
public class AccessRightsDAOImpl implements AccessRightsDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsModules save(CmsModules modules) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(modules);
			return modules;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsFunctions save(CmsFunctions functions) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(functions);
			return functions;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsJobs save(CmsJobs jobs) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(jobs);
			return jobs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsModules> getMenu(String username) {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsModules> query = session.createQuery("FROM CmsModules WHERE clientUser=:username", CmsModules.class);
			query.setParameter("username", username);
			return query.getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsModules delete(CmsModules modules) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.delete(modules);
			return modules;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsFunctions delete(CmsFunctions functions) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.delete(functions);
			return functions;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsJobs delete(CmsJobs jobs) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.delete(jobs);
			return jobs;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsModules get(CmsModules modules) {
		try {
			Session session = sessionFactory.getCurrentSession();
			
			return session.get(CmsModules.class, modules.getmId());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsFunctions get(CmsFunctions functions) {
		try {
			Session session = sessionFactory.getCurrentSession();
			
			return session.get(CmsFunctions.class, functions.getfId());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsJobs get(CmsJobs jobs) {
		try {
			Session session = sessionFactory.getCurrentSession();			
			return session.get(CmsJobs.class, jobs.getjId());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	

}
