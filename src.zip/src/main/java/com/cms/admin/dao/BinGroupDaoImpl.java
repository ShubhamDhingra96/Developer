package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.entity.CmsPlasticProductSetup;

@Repository
//@Transactional
//@Service("binGroupDao")
public class BinGroupDaoImpl implements BinGroupDao {

	@Autowired
	CommonDao dao;

	@Autowired
	private SessionFactory sessionfactory;

//	@Autowired
//	Utility util;

//	@Override
//	public Integer addBinGroup(BinGroupSetupBin bean) throws Exception {
//		// TODO Auto-generated method stub
//		Integer i=0;
//		System.out.println(" addBinGroup:" + String.join(",", bean.getPlacticCodes()));
//		
//		CmsBinGroup group=new CmsBinGroup();
//		CmsBin binId=dao.getMaster(CmsBin.class, Integer.parseInt(bean.getSelectBin()));
//		if(bean.getBinGroupSetupId()!=null) {
//			
//			group=dao.getMaster(CmsBinGroup.class, Integer.parseInt(bean.getBinGroupSetupId()));
//			group.setBinGroupId(group.getBinGroupId());
//			group.setBinSettlementCurrency(Integer.parseInt(bean.getBinSettlementCurrency()));
//			group.setBinSettlementType(Integer.parseInt(bean.getBinSettlementType()));
//			group.setBinCurrency(Integer.parseInt(bean.getBinCurrency()));
//			group.setBinDesc(bean.getBinDesc());
//			group.setBinGroupDesc(bean.getBinGroupDesc());
//			group.setBinId(binId);
//			group.setBinRangeTo(Integer.parseInt(bean.getBinRangeFrom()));
//			group.setBinRnangeFrom(Integer.parseInt(bean.getBinRangeFrom()));
//			group.setPlasticCode(String.join(",", bean.getPlacticCodes()));
//			group.setTotalNumber(Integer.parseInt(bean.getTotalNumberOfCard()));
//			group.setTransactionSettlementCurrency(String.join(",", bean.getTransactionSettlementCurrency()));
//			group.setInsertedBy("");
//			group.setModifiedBy("");
//			group.setModifiedDate(new Date());
//			group.setInsertedDate(new Date());
//			dao.Modify(group);
//		}else {
//			group.setBinSettlementCurrency(Integer.parseInt(bean.getBinSettlementCurrency()));
//			group.setBinSettlementType(Integer.parseInt(bean.getBinSettlementType()));
//			group.setBinCurrency(Integer.parseInt(bean.getBinCurrency()));
//			group.setBinDesc(bean.getBinDesc());
//			group.setBinGroupDesc(bean.getBinGroupDesc());
//			group.setBinId(binId);
//			group.setBinRangeTo(Integer.parseInt(bean.getBinRangeFrom()));
//			group.setBinRnangeFrom(Integer.parseInt(bean.getBinRangeFrom()));
//			group.setPlasticCode(String.join(",", bean.getPlacticCodes()));
//			group.setTotalNumber(Integer.parseInt(bean.getTotalNumberOfCard()));
//			group.setTransactionSettlementCurrency(String.join(",", bean.getPlacticCodes()));
//			group.setInsertedBy("");
//			group.setModifiedBy("");
//			group.setModifiedDate(new Date());
//			group.setInsertedDate(new Date());
//			
//			dao.Create(group);
//			
//		}
//		return i;
//	}

	@Override
	public CmsBin getBinDetails(BinGroupSetupBin bean) throws Exception {
		// TODO Auto-generated method stub

		// util.println("inside getBinDetails :"+bean.getSelectBin());
		CmsBin cmsBin = dao.getMaster(CmsBin.class, Integer.parseInt(bean.getSelectBin()));
		return cmsBin;
	}

//	@Override
//	public List<CmsBin> getBinList(CmsBinRequest bean) throws Exception {
//		// TODO Auto-generated method stub
//		List<CmsBin> list = session.getCurrentSession().createQuery("from CmsBin").list();
//
//		return list;
//	}

	@Override
	public CmsBin getCmsBinDetails(String binNumber) throws Exception {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsBin where binId=:binId");
			query.setParameter("binId", Integer.parseInt(binNumber));
			CmsBin results = (CmsBin) query.uniqueResult();
			System.out.println("Result.1.1." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<CmsPlasticProductSetup> getPlasticCodelist() throws Exception {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsPlasticProductSetup");
			List<CmsPlasticProductSetup> results = query.list();
			System.out.println("Result CmsPlasticProductSetup.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<CmsBinGroup> getBinGroupSetUpDetails() {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsBinGroup");
			List<CmsBinGroup> results = query.list();
			System.out.println("Result CmsBinGroup.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer addBinGroup(CmsBinGroup bean) throws Exception {
		Session session = sessionfactory.getCurrentSession();
	
		Integer id = 0;
		try {
			if (bean.getBinGroupId() == null) {
				id = (Integer) session.save(bean);
				
				return id;
			}

			else {
				CmsBinGroup binGroupDetails = (CmsBinGroup) session.get(CmsBinGroup.class, bean.getBinGroupId());
			
				binGroupDetails.setTransactionSettlementCurrency(bean.getTransactionSettlementCurrency());
				binGroupDetails.setPlasticCode(bean.getPlasticCode());
				binGroupDetails.setModifiedBy(bean.getModifiedBy());
				binGroupDetails.setModifiedDate(bean.getModifiedDate());
				session.update(binGroupDetails);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public CmsBinGroup getCmsBinGroupDetails(String binGroupCode) throws Exception {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsBinGroup where binGroupCode=:binGroupCode");
			query.setParameter("binGroupCode", binGroupCode);
			CmsBinGroup results = (CmsBinGroup) query.uniqueResult();
			System.out.println("Result.1.1." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public CmsBinGroup getCmsBinGroupDetails(String user, String groupCode) throws Exception {
		try {					
			return sessionfactory.getCurrentSession().createQuery("from CmsBinGroup where insertedBy='"+user+"' AND  binGroupCode='"+groupCode+"'",CmsBinGroup.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<CmsBinGroup> getBinGroupClientId(String clientId) throws Exception {
		List<CmsBinGroup> list = dao.getBinGroupByClientId(clientId);
		return list;
	}

	@Override
	public List<CmsBinGroup> getAll(String user) {
		try {
			return sessionfactory.getCurrentSession().createQuery("from CmsBinGroup where insertedBy='"+ user+"'", CmsBinGroup.class).getResultList();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
