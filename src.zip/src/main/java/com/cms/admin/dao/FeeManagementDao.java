package com.cms.admin.dao;

import java.util.List;


import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMGroupTransaction;
;


public interface FeeManagementDao {
	
	public CmsFeeManagement saveFeeDetails(CmsFeeManagement cmsfeemanagement);
	 	
	public List<CmsFeeManagement> getFeeDetails();
	
	public boolean updateFeeDetails(CmsFeeManagement cmsfeemanagement); 
	
	public CmsFeeManagement getFeeDetailsByCode(String feeCode);
	
	public CmsFeeManagement getFeeDetails(String user,String feeCode);
	
	public List<CmsMGroupTransaction> getTransactionType();


}
