package com.cms.admin.dao;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.LogCmsException;



@Repository
public class LoggingDaoImpl implements LoggingDao {

	private static Logger logger = LoggerFactory.getLogger(LoggingDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Integer saveExceptionLog(LogCmsException exceptionLog) {
		Integer exceptionLogId = 0;
		try {
			exceptionLogId = (Integer) sessionFactory.getCurrentSession().save(exceptionLog);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return exceptionLogId;
	}

}
