package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cms.admin.entity.CmsPlasticProductSetup;

@Repository
@Service("plasticDao")
public class PlasticProductDaoImpl implements PlasticProductDao {

	@Autowired
	CommonDao dao;

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public List<CmsPlasticProductSetup> getPlasticProductList() throws Exception {
		List<CmsPlasticProductSetup> list = dao.getList();
		return list;
	}

	@Override
	public CmsPlasticProductSetup savePlasticProductSetupDetails(CmsPlasticProductSetup entity) {
		try {
			Session session = sessionfactory.getCurrentSession();
			session.save(entity);
			return entity;
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsPlasticProductSetup> getSpecificPlasticProductList(String clientId) throws Exception {
		List<CmsPlasticProductSetup> list = dao.getSpecificPlasticCodeList(clientId);
		return list;
	}

	@Override
	public CmsPlasticProductSetup getSpecificPlasticProductList(String clientId, String groupCode) throws Exception {
		try {

			return sessionfactory.getCurrentSession().createQuery("from CmsPlasticProductSetup where clientID='"
					+ clientId + "'" + " AND plasticCode='" + groupCode + "' ", CmsPlasticProductSetup.class)
					.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
