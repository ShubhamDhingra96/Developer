package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinSetupBean;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsMBin;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsCurrency;
import com.cms.admin.entity.CmsPlasticProductSetup;

public interface BinSetupDao {

	//public Integer addBin(CmsBinRequest bean)throws Exception;
	
	public Integer addBin(CmsMBin cmsMbin);
	
	public List<CmsBin> getBinList(CmsBinRequest bean)throws Exception;
	
	public List<CmsCurrency> getBinCurrency()throws Exception;
	
	public CmsBin getBin(String user,String groupCode)throws Exception; 
	
	public List<CmsBin> getBinsetupByClientId(String clientId) throws Exception;
}
