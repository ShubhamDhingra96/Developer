package com.cms.admin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsMTransaction;
import com.cms.admin.entity.CmsTransactionGrouping;

@Repository
public class TransactionGroupDaoImpl implements TransactionGroupDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	CommonDao dao;
	
	@Override
	public List<CmsMTransaction> getTransactionType() {
		try {
			Session session1 = sessionFactory.getCurrentSession();
			Query query = session1.createQuery("from CmsMTransaction");
			List<CmsMTransaction> results = query.list();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsTransactionGrouping saveTransactionGrouping(CmsTransactionGrouping cmsTransactionGrouping) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsTransactionGrouping);
			return cmsTransactionGrouping;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsTransactionGrouping> getTransactionGroupDetails() {
		try {
			Session session1 = sessionFactory.getCurrentSession();
			Query query = session1.createQuery("from CmsTransactionGrouping");
			List<CmsTransactionGrouping> results = query.list();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsTransactionGrouping getTransactionCode(String user, String groupCode) throws Exception {
		try {
			System.out.println("In dao....");
			return sessionFactory.getCurrentSession().createQuery("from CmsTransactionGrouping where insertedBy='"+user+"' AND groupTxnCode='"+groupCode+"'", CmsTransactionGrouping.class)
					.getSingleResult();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsTransactionGrouping> getTransactionCodeByClientId(String clientId) throws Exception {
		List<CmsTransactionGrouping> list = dao.getTransactionCodeByClientId(clientId);
		return list;
	}
	
}
