package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.bean.ProgrammeDefinitionBean;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsPlasticProductSetup;
import com.cms.admin.entity.CmsProgrammeDefinition;

public interface ProgramDefinitionDao {

	public CmsProgrammeDefinition saveProgramDefinitionDetails(CmsProgrammeDefinition programentity);
	
	public List<CmsProgrammeDefinition> getProgramDefinitionDetails();
	
	public CmsProgrammeDefinition updateProgramDefinitionBean(CmsProgrammeDefinition programDefinitionentity);
	
	public CmsProgrammeDefinition isExistProgramCode(String programcode);

	public CmsProgrammeDefinition getProgramDefinitionByCode(String username, String programcode); 
	
	public List<CmsProgrammeDefinition> getAll(String username);
}
