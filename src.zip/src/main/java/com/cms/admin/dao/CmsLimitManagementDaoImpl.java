package com.cms.admin.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsCurrency;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMTransaction;

@Repository
public class CmsLimitManagementDaoImpl implements CmsLimitManagementDao {

	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * save Limit Management details
	 */
	@Override
	public CmsMLimitManagement saveLimitManagementDetails(CmsMLimitManagement limitManagement) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(limitManagement);
			return limitManagement;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Get Limit Management details
	 * 
	 */
	@Override
	public List<CmsMLimitManagement> getLimitDetails() {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMLimitManagement ");
			List<CmsMLimitManagement> details = (ArrayList<CmsMLimitManagement>) query.list();
			return details;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Update Limit Management Details
	 */
	@Override
	public boolean updateLimitDetails(CmsMLimitManagement limitManagement) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.saveOrUpdate(limitManagement);
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * get Limit details by Limit code
	 * 
	 */
	@Override
	public CmsMLimitManagement getLmitDetailByCode(String limitCode) {
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMLimitManagement where limitCode =:limitCode ");
			query.setParameter("limitCode", limitCode);
			CmsMLimitManagement results = (CmsMLimitManagement) query.getSingleResult();
			return results;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;

	}

	@Override
	public List<CmsMTransaction> getTransactionType() {
		try {
			Session session1 = sessionFactory.getCurrentSession();
			Query query = session1.createQuery("from CmsMTransaction");
			List<CmsMTransaction> results = query.list();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsMLimitManagement getLmitDetailByCode(String createdby, String limitCode) {
		try {

			return sessionFactory.getCurrentSession().createQuery(
					"from CmsMLimitManagement where createdby='" + createdby + "' and limitCode ='" + limitCode + "' ",
					CmsMLimitManagement.class).getSingleResult();

		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}
}
