package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsFunctions;
import com.cms.admin.entity.CmsJobs;
import com.cms.admin.entity.CmsModules;

public interface AccessRightsDAO {

	public CmsModules save(CmsModules modules);

	public CmsFunctions save(CmsFunctions functions);

	public CmsJobs save(CmsJobs jobs);

	public CmsModules delete(CmsModules modules);

	public CmsFunctions delete(CmsFunctions functions);

	public CmsJobs delete(CmsJobs jobs);

	public CmsModules get(CmsModules modules);

	public CmsFunctions get(CmsFunctions functions);

	public CmsJobs get(CmsJobs jobs);

//	public CmsJobs update(CmsJobs jobs);
//
//	public CmsModules update(CmsModules modules);
//
//	public CmsFunctions update(CmsFunctions functions);

	public List<CmsModules> getMenu(String username);

}
