package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsContactPersonDetail;

public interface CmsClientDao {

	public CmsClient save(CmsClient cmsClient);

	public CmsClient update(CmsClient cmsClient);
	
	public CmsClient update(String  clientid);

	public CmsClient get(CmsClient cmsClient);

	public CmsClient get(String clientId);
	
	public List<CmsClient> getAllClients();
	
	public CmsContactPersonDetail save(CmsContactPersonDetail[] cmsCompanyPersonDetail);
	
	public CmsContactPersonDetail update(CmsContactPersonDetail cmsCompanyPersonDetail);
	
	public CmsContactPersonDetail update(CmsContactPersonDetail[] cmsCompanyPersonDetail);
	
	public CmsContactPersonDetail get(CmsContactPersonDetail cmsCompanyPersonDetail);
	
	public CmsContactPersonDetail get(Long  personID);
	
	public CmsClient getClientDetailsbyClientId(String clientId);
	
	public Boolean hasCompany(String company);
	
	public List<CmsClient> getAllCorporates(); 

}
