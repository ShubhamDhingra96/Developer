package com.cms.admin.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsCities;
import com.cms.admin.entity.CmsCountries;
import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;

@Repository
public class CountriesStatesCitiesDaoimpl implements CountriesStatesCitiesDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsCountries getCountries(Number countryid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.createQuery("FROM CmsCountries Where countryId=:countryId", CmsCountries.class)
					.setParameter("countryId", countryid)
					.getSingleResult();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		
	}

	@Override
	public CmsStates getStates(Long stateId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsStates> query = session.createQuery("FROM CmsStates Where stateId=:stateid", CmsStates.class);
			query.setParameter("stateid", stateId);
			return query.getSingleResult();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsCities getCities(Long cityid) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.get(CmsCities.class, cityid);
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsStates> getStatesByCountryid(Long countryid) {
		try {
//			CmsCountries country = new CmsCountries();
//			country.setCountryId(countryid.longValue());
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsStates> query = session.createQuery("FROM CmsStates Where countryId=:countryId", CmsStates.class);
			query.setParameter("countryId", countryid);
			return query.getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCities> getCitiesByStateid(Long stateid) {
		try {
//			CmsStates state = new CmsStates();
//			state.setStateId(stateid.longValue());
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsCities> query = session.createQuery("FROM CmsCities Where stateId=:stateId", CmsCities.class);
			query.setParameter("stateId", stateid);
			return query.getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCountries> getCountries() {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.createQuery("FROM CmsCountries", CmsCountries.class)
					//.setParameter("countryId", countryid)
					.getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsCountry> getCountry() {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.createQuery("FROM CmsCountry", CmsCountry.class)
					//.setParameter("countryId", countryid)
					.getResultList();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
