package com.cms.admin.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsMJobs;
import com.cms.admin.entity.CmsMJobsMapping;
import com.cms.admin.entity.CmsMModules;

@Repository
public class CmsClientLoginDaoImpl implements CmsClientLoginDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsClientLogin save(CmsClientLogin cmsClientLogin) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsClientLogin);
			return cmsClientLogin;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClientLogin update(CmsClientLogin cmsClientLogin) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(cmsClientLogin);
			return cmsClientLogin;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClientLogin get(CmsClientLogin cmsClientLogin) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.get(CmsClientLogin.class, cmsClientLogin.getUsername());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClientLogin get(String username) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.get(CmsClientLogin.class, username);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClientLogin getClientDetailsByUsername(String username) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsClientLogin where username =: username");
			query.setParameter("username", username);
			CmsClientLogin results = (CmsClientLogin) query.uniqueResult();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClientLogin getClientDetailsByTokenKey(String tokenKey) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsClientLogin where tokenKey =: tokenKey");
			query.setParameter("tokenKey", tokenKey);
			CmsClientLogin results = (CmsClientLogin) query.uniqueResult();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsMModules> getModules() {
		try {

			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMModules");
			List<CmsMModules> results = query.list();
			System.out.println("Results.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsMFunctions> getModuleFunctions(String moduleId) {

		try {
			System.out.println("moduleId..." + moduleId);
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMFunctions where cmsMModules.cmsModuleId =: moduleId");
			query.setParameter("moduleId", moduleId);
			List<CmsMFunctions> results = query.list();
			System.out.println("Results.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsMJobsMapping> getJobMappingDetails(String functionId) {
		try {
			System.out.println("functionId..." + functionId);
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMJobsMapping where cmsMFunctions.cmsMFunctionId =: functionId");
			query.setParameter("functionId", functionId);
			List<CmsMJobsMapping> results = query.list();
			System.out.println("Results.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsMJobs> getJobsName(List<CmsMJobs> jobId) {
		try {
			System.out.println("functionId..." + jobId);
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsMJobs where jobId IN (:jobId)");
			query.setParameterList("jobId", jobId);
			List<CmsMJobs> results = query.list();
			System.out.println("Results.." + results);
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsClientLogin> getAllSuperAdminUser() {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsClientLogin> query = session.createQuery("from CmsClientLogin where insertedBy ='superadmin'",
					CmsClientLogin.class);

			return query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsClientLogin> getAll() {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsClientLogin> query = session.createQuery("FROM CmsClientLogin", CmsClientLogin.class);
			return query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
