package com.cms.admin.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsMBin;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsCurrency;

@Repository
//@Transactional
//@Service("binSetupDao")
public class BinSetupDaoImpl implements BinSetupDao {

	@Autowired
	CommonDao dao;

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public Integer addBin(CmsMBin bean) {
		
		Session session=sessionfactory.getCurrentSession();
		Integer i=0;
		CmsBin cmsBinData = new CmsBin();
		if (bean.getBinSetupId() != null) {
			cmsBinData = dao.getMaster(CmsBin.class, Integer.parseInt(bean.getBinSetupId()));
			cmsBinData.setSettlementCurrency(bean.getSettlementCurrency());
			cmsBinData.setBinCurrency(bean.getBinCurrency());
			cmsBinData.setBinDigit(bean.getBinDigit());
			cmsBinData.setBinDiscription(bean.getBinDescription());
			cmsBinData.setBinType(bean.getBinType());
			cmsBinData.setCheckParity(bean.getCheckPerity());
			cmsBinData.setBinIssuer(bean.getBinIssue());
			cmsBinData.setBinType(bean.getBinType());
			cmsBinData.setBinNumber(bean.getBin());
			cmsBinData.setBinStatus(1);
			cmsBinData.setModifiedBy(bean.getModifiedBy());
			cmsBinData.setModifiedDate(bean.getModifiedDate());
			cmsBinData.setInsertedDate(new Date());
			cmsBinData.setModifiedDate(new Date());
			session.saveOrUpdate(cmsBinData);
			
		} else {
			cmsBinData.setSettlementCurrency(bean.getSettlementCurrency());
			cmsBinData.setBinCurrency(bean.getBinCurrency());
			cmsBinData.setBinDigit(bean.getBinDigit());
			cmsBinData.setBinDiscription(bean.getBinDescription());
			cmsBinData.setBinType(bean.getBinType());
			cmsBinData.setCheckParity(bean.getCheckPerity());
			cmsBinData.setBinIssuer(bean.getBinIssue());
			cmsBinData.setBinType(bean.getBinType());
			cmsBinData.setBinNumber(bean.getBin());
			cmsBinData.setBinStatus(1);
			cmsBinData.setInsertedDate(new Date());
			cmsBinData.setClientID(bean.getInsertedBy());
			cmsBinData.setInsertedBy(bean.getInsertedBy());
			 i = (Integer) session.save(cmsBinData);
			
		}
		return i;
	}
	
	@Override
	public List<CmsBin> getBinList(CmsBinRequest bean) throws Exception {
		Session session=sessionfactory.getCurrentSession();
		List<CmsBin> list = session.createQuery("from CmsBin").list();
		return list;
	}

	@Override
	public List<CmsCurrency> getBinCurrency() throws Exception {
		
		try{
			Session session=sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsCurrency");
			List<CmsCurrency> results= query.list();
			return results;
		}catch(Exception e) {
		e.printStackTrace();
		}
		
		
		return null;
		
		
	}

	@Override
	public CmsBin getBin(String user, String groupCode) throws Exception {
		try {
			return sessionfactory.getCurrentSession().createQuery("from CmsBin where insertedBy='"+user+"' AND binNumber='"+groupCode+"'", CmsBin.class)
					.getSingleResult();
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public List<CmsBin> getBinsetupByClientId(String clientId) throws Exception {
		List<CmsBin> list = dao.getBinsetupByClientId(clientId);
		return list;
	}

}
