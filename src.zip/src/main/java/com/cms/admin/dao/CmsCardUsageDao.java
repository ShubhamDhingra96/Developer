package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.entity.CmsCardUsage;


public interface CmsCardUsageDao {
	
	public CmsCardUsage saveCmsCardUsageDetails(CmsCardUsage cmscardusage);
	
	public List<CmsCardUsage> getCmsCardUsageDetails();
	
	public CmsCardUsage updateCardUsageDetails(CmsCardUsage cmscardusage);
	
	public CmsCardUsage getCardUsageDetailsByCode(String groupcode); 
	
	public CmsCardUsage getCardUsageDetailsByCode(String username,String groupcode); 

}
