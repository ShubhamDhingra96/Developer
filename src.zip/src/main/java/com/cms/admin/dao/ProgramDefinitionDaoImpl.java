package com.cms.admin.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsProgrammeDefinition;

@Repository
@Service
public class ProgramDefinitionDaoImpl implements ProgramDefinitionDao {

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public CmsProgrammeDefinition saveProgramDefinitionDetails(CmsProgrammeDefinition programentity) {
		try {
			Session session = sessionfactory.getCurrentSession();
			session.save(programentity);

			return programentity;

		} catch (Exception exception) {

			exception.printStackTrace();
		}
		return null;

	}

	@Override
	public List<CmsProgrammeDefinition> getProgramDefinitionDetails() {
		try {
			Session session = sessionfactory.getCurrentSession();

			TypedQuery<CmsProgrammeDefinition> query = session.createQuery("from CmsProgrammeDefinition",
					CmsProgrammeDefinition.class);

			return query.getResultList();

		} catch (HibernateException exception) {

			exception.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsProgrammeDefinition updateProgramDefinitionBean(CmsProgrammeDefinition programDefinitionentity) {
		try {
			Session session = sessionfactory.getCurrentSession();
			session.update(programDefinitionentity);
			return programDefinitionentity;
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsProgrammeDefinition isExistProgramCode(String programcode) {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsProgrammeDefinition where programcode=:programcode");
			query.setParameter("programcode", programcode);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsProgrammeDefinition getProgramDefinitionByCode(String username, String programcode) {
		try {
			return sessionfactory.getCurrentSession().createQuery("from CmsProgrammeDefinition where insertedBy='" + username + "' AND programCode='" + programcode + "'",
							CmsProgrammeDefinition.class)
					.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public List<CmsProgrammeDefinition> getAll(String username) {
		try {
			return sessionfactory.getCurrentSession().createQuery("from CmsProgrammeDefinition where insertedBy='" + username + "'", CmsProgrammeDefinition.class).getResultList();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}