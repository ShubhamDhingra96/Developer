package com.cms.admin.dao;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsMerchantMccGroup;

@Repository
public class CmsMerchantDaoImpl implements CmsMerchantMCCDao {

	@Override
	public CmsMerchantMccGroup get(CmsMerchantMccGroup group) {
		
		
		
		
		return null;
	}

}
