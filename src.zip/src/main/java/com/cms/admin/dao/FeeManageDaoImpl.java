package com.cms.admin.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMGroupTransaction;

import com.cms.admin.entity.CmsMerchantDetails;

@Repository
@Transactional
public class FeeManageDaoImpl implements FeeManagementDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsFeeManagement saveFeeDetails(CmsFeeManagement cmsfeemanagement) {

		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsfeemanagement);
			return cmsfeemanagement;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<CmsFeeManagement> getFeeDetails() {
		try {

			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsFeeManagement");
			List<CmsFeeManagement> details = (ArrayList<CmsFeeManagement>) query.list();
			return details;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean updateFeeDetails(CmsFeeManagement cmsfeemanagement) {
		try {

			Session session = sessionFactory.getCurrentSession();
			session.saveOrUpdate(cmsfeemanagement);
			return true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public CmsFeeManagement getFeeDetailsByCode(String feeCode) {
		try {

			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsFeeManagement where FEE_CODE=:feeCode");
			query.setParameter("feeCode", feeCode);
			CmsFeeManagement result = (CmsFeeManagement) query.getSingleResult();
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsFeeManagement getFeeDetails(String user, String feeCode) {
		try {		
			
			return sessionFactory.getCurrentSession().createQuery("from CmsFeeManagement where createdBy='"+user+"' and feeCode='"+feeCode+"' ",CmsFeeManagement.class).getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public List<CmsMGroupTransaction> getTransactionType() {
		try {
			Session session1 = sessionFactory.getCurrentSession();
			Query query = session1.createQuery("from CmsMGroupTransaction");
			List<CmsMGroupTransaction> results = query.list();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
}
