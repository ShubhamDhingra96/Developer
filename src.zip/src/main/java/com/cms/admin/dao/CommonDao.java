package com.cms.admin.dao;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.entity.CmsPlasticProductSetup;
import com.cms.admin.entity.CmsTransactionGrouping;

@Repository
@Transactional
public class CommonDao {

	@Autowired
	private SessionFactory sessionFactory;
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");

	public int Create(Object obj) throws Exception {
		System.out.println("###############---Create---#################");
		int id = 0;

		if (obj != null) {
			id = (int) sessionFactory.getCurrentSession().save(obj);

			Method[] methods = obj.getClass().getMethods();
			for (int i = 0; i < methods.length; i++) {
				Method method = methods[i];
				if (method.getName().equalsIgnoreCase("getParent")) {
					Object parentObj = method.invoke(obj);
					if (parentObj != null) {
						id = (int) sessionFactory.getCurrentSession().save(parentObj);
					}
				}
			}
		}
		return id;
	}

	public boolean Modify(Object obj) throws Exception {
		if (obj != null) {

			sessionFactory.getCurrentSession().update(obj);

			Method[] methods = obj.getClass().getMethods();
			for (int i = 0; i < methods.length; i++) {
				Method method = methods[i];
				if (method.getName().equalsIgnoreCase("getParent")) {
					Object parentObj = method.invoke(obj);
					if (parentObj != null) {
						sessionFactory.getCurrentSession().saveOrUpdate(parentObj);
					}
				}
			}
		}
		return true;

	}

	public <T> T getMaster(Class<T> clazz, Integer id) {
		return (T) sessionFactory.getCurrentSession().get(clazz, id);
	}

	public <T> T getMaster(Class<T> clazz, String id) {
		return (T) sessionFactory.getCurrentSession().get(clazz, id);

	}

	public List<CmsPlasticProductSetup> getList() {
		List<CmsPlasticProductSetup> list = sessionFactory.getCurrentSession()
				.createQuery("from CmsPlasticProductSetup").list();

		return list;

	}

	public List<CmsPlasticProductSetup> getSpecificPlasticCodeList(String clientId) {
		return sessionFactory.getCurrentSession()
				.createQuery("from CmsPlasticProductSetup where  CMS_CLIENT_ID = '" + clientId + "'",
						CmsPlasticProductSetup.class)
				.getResultList();

	}
	
	public List<CmsBin> getBinsetupByClientId(String clientId) {
		return sessionFactory.getCurrentSession()
				.createQuery("from CmsBin where  CMS_CLIENT_ID = '" + clientId + "'",
						CmsBin.class)
				.getResultList();

	}
	
	public List<CmsBinGroup> getBinGroupByClientId(String clientId) {
		return sessionFactory.getCurrentSession()
				.createQuery("from CmsBinGroup where  CMS_CLIENT_ID = '" + clientId + "'",
						CmsBinGroup.class)
				.getResultList();

	}
	
	public List<CmsTransactionGrouping> getTransactionCodeByClientId(String clientId) {
		return sessionFactory.getCurrentSession()
				.createQuery("from CmsTransactionGrouping where  INSERTED_BY = '" + clientId + "'",
						CmsTransactionGrouping.class)
				.getResultList();

	}
}
