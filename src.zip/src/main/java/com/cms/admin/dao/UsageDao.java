package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsCountryGroup;
import com.cms.admin.entity.CmsDeliveryChannel;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMerchantDetails;

public interface UsageDao {

	public CmsCountryGroup save(CmsCountryGroup cmsCountryGroup);

	public CmsCountryGroup update(CmsCountryGroup cmsCountryGroup);

	public CmsCountryGroup getCountryGroup(Integer groupId);
	
	public CmsCountryGroup getCountryGroup(String username,String groupCode);
	
	public List<CmsCountryGroup> getCountryGroup(String username);
	
	public List<CmsCountryGroup> getAllCountryGroup();

	public CmsDeliveryChannelGroup save(CmsDeliveryChannelGroup cmsDeliveryChannelGroup);

	public CmsDeliveryChannelGroup update(CmsDeliveryChannelGroup cmsDeliveryChannelGroup);

	public CmsDeliveryChannelGroup getDeliveryChannelGroup(Integer groupId);
	
	public CmsDeliveryChannelGroup getDeliveryChannelGroup(String username,String groupCode);
	
	public List<CmsDeliveryChannelGroup> getDeliveryChannelGroup(String username);
	
	public List<CmsDeliveryChannelGroup> getAllDeliveryChannelGroup();
	
	public List<CmsDeliveryChannel> getAll();

	public List<CmsAcquiringNetworkGroup> getAcquiringNetworkGroup(String username);

	public List<CmsCardUsage> viewCardUsageSetting(String username);

	public List<CmsMerchantDetails> viewMerchantDetails(String username);

	public List<CmsMLimitManagement> viewLimitManagement(String username);

	public List<CmsFeeManagement> viewFeeManagement(String username);
	
	

}
