package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsCountryCurrency;

public interface CmsCountryDao {
	
	public List<CmsCountryCurrency> getAll();

}
