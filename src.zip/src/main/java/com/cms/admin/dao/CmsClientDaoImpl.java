package com.cms.admin.dao;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsContactPersonDetail;

@Repository
public class CmsClientDaoImpl implements CmsClientDao {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public CmsClient save(CmsClient cmsClient) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(cmsClient);
			return cmsClient;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsClient update(CmsClient cmsClient) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.update(cmsClient);
			return cmsClient;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClient get(CmsClient cmsClient) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.get(CmsClient.class, cmsClient.getCmsClientId());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClient get(String clientId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			return session.get(CmsClient.class, clientId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsContactPersonDetail save(CmsContactPersonDetail[] cmsCompanyPersonDetail) {
		try {
			Session session = sessionFactory.getCurrentSession();
			for (CmsContactPersonDetail companyPersonDetail : cmsCompanyPersonDetail) {
				session.save(companyPersonDetail);
			}

			return cmsCompanyPersonDetail[0];
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsContactPersonDetail update(CmsContactPersonDetail cmsCompanyPersonDetail) {
		try {
			Session session = sessionFactory.getCurrentSession();

			session.update(cmsCompanyPersonDetail);

			return cmsCompanyPersonDetail;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsContactPersonDetail update(CmsContactPersonDetail[] cmsCompanyPersonDetail) {
		try {
			Session session = sessionFactory.getCurrentSession();
			for (CmsContactPersonDetail companyPersonDetail : cmsCompanyPersonDetail) {
				session.update(companyPersonDetail);
			}

			return cmsCompanyPersonDetail[0];
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsContactPersonDetail get(CmsContactPersonDetail cmsCompanyPersonDetail) {
		return null;
	}

	@Override
	public CmsContactPersonDetail get(Long personID) {
		return null;
	}

	@Override
	public CmsClient getClientDetailsbyClientId(String clientId) {
		try {

			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from CmsClient where cmsClientId = :cmsClientId ");
			query.setParameter("cmsClientId", clientId);
			CmsClient results = (CmsClient) query.getSingleResult();
			return results;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsClient> getAllClients() {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsClient> query = session.createQuery("FROM CmsClient", CmsClient.class);
			return query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsClient update(String clientid) {
		try {

			Session session = sessionFactory.getCurrentSession();
			Query query = session
					.createQuery("update  CmsClient  set ref1='User Created' where cmsClientId = :cmsClientId ");
			query.setParameter("cmsClientId", clientid);
			query.executeUpdate();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Boolean hasCompany(String company) {
		try {

			System.out.println(company+"             ????");
			Session session = sessionFactory.getCurrentSession();			
			
			TypedQuery<CmsClient> query = session.createQuery("from CmsClient where cmsCompanyName = :company ",
					CmsClient.class);
			query.setParameter("company", company.toUpperCase());
			CmsClient results = query.getSingleResult();
			if (results != null)
				return true;
			else
				return false;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	@Override
	public List<CmsClient> getAllCorporates() {
		try {
			Session session = sessionFactory.getCurrentSession();
			TypedQuery<CmsClient> query = session.createQuery("FROM CmsClient where corporateType=:corporateType ", CmsClient.class);
			query.setParameter("corporateType","Y");
			return query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}



}
