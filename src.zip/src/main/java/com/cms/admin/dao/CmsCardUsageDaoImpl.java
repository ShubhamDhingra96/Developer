package com.cms.admin.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.entity.CmsCardUsage;

@Repository
public class CmsCardUsageDaoImpl implements CmsCardUsageDao {

	@Autowired
	private SessionFactory sessionfactory;

	@Override
	public CmsCardUsage saveCmsCardUsageDetails(CmsCardUsage cmscardusage) {
		try {
			Session session = sessionfactory.getCurrentSession();
			session.save(cmscardusage);

			return cmscardusage;

		} catch (HibernateException exception) {
			exception.printStackTrace();
		}

		return null;
	}

	@Override
	public CmsCardUsage updateCardUsageDetails(CmsCardUsage cmscardusage) {
		try {
			Session session = sessionfactory.getCurrentSession();

			session.update(cmscardusage);

			return cmscardusage;

		} catch (HibernateException exception) {

			exception.printStackTrace();

		}
		return null;
	}

	@Override
	public List<CmsCardUsage> getCmsCardUsageDetails() {
		try {
			Session session = sessionfactory.getCurrentSession();
			Query query = session.createQuery("from CmsCardUsage");
			List<CmsCardUsage> cardusagedetails = (ArrayList<CmsCardUsage>) query.list();
			return cardusagedetails;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsCardUsage getCardUsageDetailsByCode(String groupcode) {
		try {
			Session session = sessionfactory.getCurrentSession();

			Query query = session.createQuery("from CmsCardUsage where groupcode=:groupcode");
			query.setParameter("groupcode", groupcode);

			CmsCardUsage results = (CmsCardUsage) query.getSingleResult();

			return results;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public CmsCardUsage getCardUsageDetailsByCode(String username, String groupcode) {
		try {
			return sessionfactory.getCurrentSession()
					.createQuery(
							"from CmsCardUsage where insertedBy='" + username + "' AND groupCode='" + groupcode + "'",
							CmsCardUsage.class)
					.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
