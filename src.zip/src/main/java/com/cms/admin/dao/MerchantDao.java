package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsMccGroupCode;
import com.cms.admin.entity.CmsMerchantDetails;
import com.cms.admin.entity.CmsMerchantMccGroup;

public interface MerchantDao {

	public CmsMerchantDetails saveDetails(CmsMerchantDetails cmsMerchantDetails);

	public CmsMerchantDetails updateDetails(CmsMerchantDetails cmsMerchantDetails);

	public CmsMerchantDetails deleteDetails(CmsMerchantDetails cmsMerchantDetails);
	
	public List<CmsMerchantMccGroup> getAll();
	
	public List<CmsMccGroupCode> getAllDetail();
	
	public CmsMerchantDetails getMerchant(String username,String groupCode);

}