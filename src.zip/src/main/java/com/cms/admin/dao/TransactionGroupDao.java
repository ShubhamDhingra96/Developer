package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMTransaction;
import com.cms.admin.entity.CmsTransactionGrouping;

public interface TransactionGroupDao {

	public List<CmsMTransaction> getTransactionType();
	
	public CmsTransactionGrouping saveTransactionGrouping(CmsTransactionGrouping cmsTransactionGrouping);
	
	public List<CmsTransactionGrouping> getTransactionGroupDetails();
	
	public CmsTransactionGrouping getTransactionCode(String user,String groupCode)throws Exception; 
	
	public List<CmsTransactionGrouping> getTransactionCodeByClientId(String clientId) throws Exception;
}
