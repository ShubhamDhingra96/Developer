package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsAcquiredNetworkId;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsNetworkType;

public interface AcquiredNetworkDao {

	public CmsAcquiringNetworkGroup saveDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup);

	public CmsAcquiringNetworkGroup updateDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup);

	public CmsAcquiringNetworkGroup deleteDetail(CmsAcquiringNetworkGroup cmsAcquiringNetworkGroup);

	public List<CmsAcquiringNetworkGroup> getAllCmsAcquiredNetwork();

	public List<CmsNetworkType> getAll();

	public List<CmsAcquiredNetworkId> getAllDetail();

	public CmsAcquiringNetworkGroup checkAllCmsAcquiredNetwork(String user, String groupCode);
}
