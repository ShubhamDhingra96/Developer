package com.cms.admin.dao;

import java.util.List;

import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsLoginPrivledges;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsMJobs;
import com.cms.admin.entity.CmsMJobsMapping;
import com.cms.admin.entity.CmsMModules;

public interface CmsClientLoginDao {

	public CmsClientLogin save(CmsClientLogin cmsClientLogin);
	
	public List<CmsClientLogin> getAllSuperAdminUser();

	public CmsClientLogin update(CmsClientLogin cmsClientLogin);

	public CmsClientLogin get(CmsClientLogin cmsClientLogin);

	public CmsClientLogin get(String username);
	
	public List<CmsClientLogin> getAll();
	
	public CmsClientLogin getClientDetailsByUsername(String username);

	public CmsClientLogin getClientDetailsByTokenKey(String tokenKey);

	public List<CmsMModules> getModules();
	
	public List<CmsMFunctions> getModuleFunctions(String moduleId);
	
	public List<CmsMJobsMapping> getJobMappingDetails(String functionId);
	
	public List<CmsMJobs> getJobsName(List<CmsMJobs> jobId);
}
