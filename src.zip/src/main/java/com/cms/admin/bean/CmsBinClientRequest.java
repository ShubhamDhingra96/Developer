package com.cms.admin.bean;

public class CmsBinClientRequest {
	
	 

}
