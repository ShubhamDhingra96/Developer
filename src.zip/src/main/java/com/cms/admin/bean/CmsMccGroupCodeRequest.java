package com.cms.admin.bean;

public class CmsMccGroupCodeRequest {

	private String mccId;
	private String mccName;
	private String mccDescription;
	private String mccGroupCodeId;
	private String insertedDate;
	private String insertedBy;
	private String modifiedDate;
	private String modifiedBy;

	public String getMccId() {
		return mccId;
	}

	public void setMccId(String mccId) {
		this.mccId = mccId;
	}

	public String getMccName() {
		return mccName;
	}

	public void setMccName(String mccName) {
		this.mccName = mccName;
	}

	public String getMccDescription() {
		return mccDescription;
	}

	public void setMccDescription(String mccDescription) {
		this.mccDescription = mccDescription;
	}

	public String getMccGroupCodeId() {
		return mccGroupCodeId;
	}

	public void setMccGroupCodeId(String mccGroupCodeId) {
		this.mccGroupCodeId = mccGroupCodeId;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
