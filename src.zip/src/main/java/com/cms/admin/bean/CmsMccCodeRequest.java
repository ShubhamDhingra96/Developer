package com.cms.admin.bean;

public class CmsMccCodeRequest {

	private String groupId;
	private String mccCodeName;
	private String mccCodeDescription;
	private String insertedDate;
	private String insertedBy;
	private String modifiedDate;
	private String modifiedBy;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getMccCodeName() {
		return mccCodeName;
	}

	public void setMccCodeName(String mccCodeName) {
		this.mccCodeName = mccCodeName;
	}

	public String getMccCodeDescription() {
		return mccCodeDescription;
	}

	public void setMccCodeDescription(String mccCodeDescription) {
		this.mccCodeDescription = mccCodeDescription;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
