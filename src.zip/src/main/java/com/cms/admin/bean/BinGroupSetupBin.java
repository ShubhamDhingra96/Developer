package com.cms.admin.bean;

import java.util.Date;

public class BinGroupSetupBin {

	private Integer binGroupid;
	private String binGroupSetupId;
	private String bin;
	private String groupCode;
	private String binGroupDescription;
	private String binGroupName;
	private String selectBin;
	private String binDesc;
	private String binCurrency;
	private String binSettlement;
	private String binSettlementType;
	private String binRangeFrom;
	private String binRangeTo;
	private String insertedBy;
	private Date insertedDate;
	private String modifiedBy;
	private Date modifiedDate;
	
	
	
	
	
	
	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}
	
	public String getBin() {
		return bin;
	}

	public Integer getBinGroupid() {
		return binGroupid;
	}
	public void setBinGroupid(Integer binGroupid) {
		this.binGroupid = binGroupid;
	}
	public String getBinGroupSetupId() {
		return binGroupSetupId;
	}
	public void setBinGroupSetupId(String binGroupSetupId) {
		this.binGroupSetupId = binGroupSetupId;
	}
	
	public String getGroupCode() {
		return groupCode;
	}
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	//	public Integer getBinGroupCode() {
//		return binGroupCode;
//	}
//	public void setBinGroupCode(Integer binGroupCode) {
//		this.binGroupCode = binGroupCode;
//	}
//	
	public String getBinGroupName() {
		return binGroupName;
	}
	public void setBinGroupName(String binGroupName) {
		this.binGroupName = binGroupName;
	}
	public String getSelectBin() {
		return selectBin;
	}
	public void setSelectBin(String selectBin) {
		this.selectBin = selectBin;
	}
	public String getBinDesc() {
		return binDesc;
	}
	public void setBinDesc(String binDesc) {
		this.binDesc = binDesc;
	}
	public String getBinCurrency() {
		return binCurrency;
	}
	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}
	
	public String getBinSettlementType() {
		return binSettlementType;
	}
	public void setBinSettlementType(String binSettlementType) {
		this.binSettlementType = binSettlementType;
	}
	public String getBinRangeFrom() {
		return binRangeFrom;
	}
	public void setBinRangeFrom(String binRangeFrom) {
		this.binRangeFrom = binRangeFrom;
	}
	public void setBinRangeTo(String binRangeTo) {
		this.binRangeTo = binRangeTo;
	}
	
	public String getBinRangeTo() {
		return binRangeTo;
	}
	
	public String getTotalNumberOfCards() {
		return totalNumberOfCards;
	}
	public void setTotalNumberOfCards(String totalNumberOfCards) {
		this.totalNumberOfCards = totalNumberOfCards;
	}
	public String[] getTransactionSettlementCurrency() {
		return transactionSettlementCurrency;
	}
	public void setTransactionSettlementCurrency(String[] transactionSettlementCurrency) {
		this.transactionSettlementCurrency = transactionSettlementCurrency;
	}
	
	
	
	public String[] getPlasticCode() {
		return plasticCode;
	}
	public void setPlasticCode(String[] plasticCode) {
		this.plasticCode = plasticCode;
	}
	public String getBinGroupDescription() {
		return binGroupDescription;
	}
	public void setBinGroupDescription(String binGroupDescription) {
		this.binGroupDescription = binGroupDescription;
	}
	public String getBinSettlement() {
		return binSettlement;
	}
	public void setBinSettlement(String binSettlement) {
		this.binSettlement = binSettlement;
	}

	
	private String totalNumberOfCards;
	private String[] transactionSettlementCurrency;
	private String[] plasticCode;
	
}
