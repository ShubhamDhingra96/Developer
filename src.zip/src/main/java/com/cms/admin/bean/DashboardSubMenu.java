package com.cms.admin.bean;

import java.util.Date;
import java.util.List;

public class DashboardSubMenu {

	private Long fId;
	private String functionId;
	private String functionName;
	private Long mId;
	private Date insertedDate;
	private Date modifiedDate;
	private String insertedBy;
	private String modifiedBy;
	private char status;
	private Boolean isChecked;

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	}

	private List<DashboardSubmenuSubmenu> cmsJobsList;

	public List<DashboardSubmenuSubmenu> getCmsJobsList() {
		return cmsJobsList;
	}

	public void setCmsJobsList(List<DashboardSubmenuSubmenu> cmsJobsList) {
		this.cmsJobsList = cmsJobsList;
	}

	public Long getfId() {
		return fId;
	}

	public void setfId(Long fId) {
		this.fId = fId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public Long getmId() {
		return mId;
	}

	public void setmId(Long mId) {
		this.mId = mId;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

}
