package com.cms.admin.bean;

public class TransactionGroup {

	private String groupTransactionCode;
    private String groupTransactionName;
    private String transactions;
    private String insertedBy;
    private String insertedOn;
    private String modifiedBy;
    private String modifiedOn;
    private String status;
	public String getGroupTransactionCode() {
		return groupTransactionCode;
	}
	public void setGroupTransactionCode(String groupTransactionCode) {
		this.groupTransactionCode = groupTransactionCode;
	}
	public String getGroupTransactionName() {
		return groupTransactionName;
	}
	public void setGroupTransactionName(String groupTransactionName) {
		this.groupTransactionName = groupTransactionName;
	}
	
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}
	
	
	public String getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}
	public String getInsertedOn() {
		return insertedOn;
	}
	public void setInsertedOn(String insertedOn) {
		this.insertedOn = insertedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
    
    
}
