package com.cms.admin.bean;

public class CmsCustValidation {

	private int groupId;
	private String groupCode;
	private String groupName;
	private String groupDescription;
	private String transactionAmount;
	private String groupDeliveryChannel;
	private String transactions;
	private String networkType;
	private String networkId;
	private String countryCode;
	private String deliveryChannelName;
	private String location;
	private String terminalId;
	private String merchantId;
	private String merchantMCCGroup;
	private String merchantMCCCode;
	private String groupTransactionalChannel;
	private String cardUsageGroupCode;
	private String cardUsageGroupName;
	private String cardUsageGroupDesc;
	private String cardUsageGroupTransactionAmount;
	private String plasticId;
	private String plasticCode;
	private String serviceCode;
	private String plasticDescription;
	private String serviceDescription;
	private String merchantGroupCode;
	private String merchantGroupName;
	private String merchantGroupDescription;
	private String merchantNetworkType;
	private String binSetupId;
	private String deliveryChannel;
	private String bin;
	private String binDescription;
	private String binCurrency;
	private String currencyDescription;
	private String settlementCurrency;
	private String settlementCurrencyDesc;
	private String binType;
	private String binIssue;
	private String checkPerity;
	private String binGroupid;
	private String binGroupSetupId;
	private String binGroupDescription;
	private String binGroupName;
	private String selectBin;
	private String binDesc;
	private String binSettlement;
	private String binSettlementType;
	private String binRangeFrom;
	private String binRnageTo;
	private String binDigit;

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getGroupDeliveryChannel() {
		return groupDeliveryChannel;
	}

	public void setGroupDeliveryChannel(String groupDeliveryChannel) {
		this.groupDeliveryChannel = groupDeliveryChannel;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getDeliveryChannelName() {
		return deliveryChannelName;
	}

	public void setDeliveryChannelName(String deliveryChannelName) {
		this.deliveryChannelName = deliveryChannelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantMCCGroup() {
		return merchantMCCGroup;
	}

	public void setMerchantMCCGroup(String merchantMCCGroup) {
		this.merchantMCCGroup = merchantMCCGroup;
	}

	public String getMerchantMCCCode() {
		return merchantMCCCode;
	}

	public void setMerchantMCCCode(String merchantMCCCode) {
		this.merchantMCCCode = merchantMCCCode;
	}

	public String getGroupTransactionalChannel() {
		return groupTransactionalChannel;
	}

	public void setGroupTransactionalChannel(String groupTransactionalChannel) {
		this.groupTransactionalChannel = groupTransactionalChannel;
	}

	public String getCardUsageGroupCode() {
		return cardUsageGroupCode;
	}

	public void setCardUsageGroupCode(String cardUsageGroupCode) {
		this.cardUsageGroupCode = cardUsageGroupCode;
	}

	public String getCardUsageGroupName() {
		return cardUsageGroupName;
	}

	public void setCardUsageGroupName(String cardUsageGroupName) {
		this.cardUsageGroupName = cardUsageGroupName;
	}

	public String getCardUsageGroupDesc() {
		return cardUsageGroupDesc;
	}

	public void setCardUsageGroupDesc(String cardUsageGroupDesc) {
		this.cardUsageGroupDesc = cardUsageGroupDesc;
	}

	public String getCardUsageGroupTransactionAmount() {
		return cardUsageGroupTransactionAmount;
	}

	public void setCardUsageGroupTransactionAmount(String cardUsageGroupTransactionAmount) {
		this.cardUsageGroupTransactionAmount = cardUsageGroupTransactionAmount;
	}

	public String getPlasticId() {
		return plasticId;
	}

	public void setPlasticId(String plasticId) {
		this.plasticId = plasticId;
	}

	public String getPlasticCode() {
		return plasticCode;
	}

	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getPlasticDescription() {
		return plasticDescription;
	}

	public void setPlasticDescription(String plasticDescription) {
		this.plasticDescription = plasticDescription;
	}

	public String getServiceDescription() {
		return serviceDescription;
	}

	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

	public String getMerchantGroupCode() {
		return merchantGroupCode;
	}

	public void setMerchantGroupCode(String merchantGroupCode) {
		this.merchantGroupCode = merchantGroupCode;
	}

	public String getMerchantGroupName() {
		return merchantGroupName;
	}

	public void setMerchantGroupName(String merchantGroupName) {
		this.merchantGroupName = merchantGroupName;
	}

	public String getMerchantGroupDescription() {
		return merchantGroupDescription;
	}

	public void setMerchantGroupDescription(String merchantGroupDescription) {
		this.merchantGroupDescription = merchantGroupDescription;
	}

	public String getMerchantNetworkType() {
		return merchantNetworkType;
	}

	public void setMerchantNetworkType(String merchantNetworkType) {
		this.merchantNetworkType = merchantNetworkType;
	}

	public String getBinSetupId() {
		return binSetupId;
	}

	public void setBinSetupId(String binSetupId) {
		this.binSetupId = binSetupId;
	}

	public String getDeliveryChannel() {
		return deliveryChannel;
	}

	public void setDeliveryChannel(String deliveryChannel) {
		this.deliveryChannel = deliveryChannel;
	}

	public String getBin() {
		return bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}

	public String getBinDescription() {
		return binDescription;
	}

	public void setBinDescription(String binDescription) {
		this.binDescription = binDescription;
	}

	public String getBinCurrency() {
		return binCurrency;
	}

	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}

	public String getCurrencyDescription() {
		return currencyDescription;
	}

	public void setCurrencyDescription(String currencyDescription) {
		this.currencyDescription = currencyDescription;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public String getSettlementCurrencyDesc() {
		return settlementCurrencyDesc;
	}

	public void setSettlementCurrencyDesc(String settlementCurrencyDesc) {
		this.settlementCurrencyDesc = settlementCurrencyDesc;
	}

	public String getBinType() {
		return binType;
	}

	public void setBinType(String binType) {
		this.binType = binType;
	}

	public String getBinIssue() {
		return binIssue;
	}

	public void setBinIssue(String binIssue) {
		this.binIssue = binIssue;
	}

	public String getCheckPerity() {
		return checkPerity;
	}

	public void setCheckPerity(String checkPerity) {
		this.checkPerity = checkPerity;
	}

	public String getBinGroupid() {
		return binGroupid;
	}

	public void setBinGroupid(String binGroupid) {
		this.binGroupid = binGroupid;
	}

	public String getBinGroupSetupId() {
		return binGroupSetupId;
	}

	public void setBinGroupSetupId(String binGroupSetupId) {
		this.binGroupSetupId = binGroupSetupId;
	}

	public String getBinGroupDescription() {
		return binGroupDescription;
	}

	public void setBinGroupDescription(String binGroupDescription) {
		this.binGroupDescription = binGroupDescription;
	}

	public String getBinGroupName() {
		return binGroupName;
	}

	public void setBinGroupName(String binGroupName) {
		this.binGroupName = binGroupName;
	}

	public String getSelectBin() {
		return selectBin;
	}

	public void setSelectBin(String selectBin) {
		this.selectBin = selectBin;
	}

	public String getBinDesc() {
		return binDesc;
	}

	public void setBinDesc(String binDesc) {
		this.binDesc = binDesc;
	}

	public String getBinSettlement() {
		return binSettlement;
	}

	public void setBinSettlement(String binSettlement) {
		this.binSettlement = binSettlement;
	}

	public String getBinSettlementType() {
		return binSettlementType;
	}

	public void setBinSettlementType(String binSettlementType) {
		this.binSettlementType = binSettlementType;
	}

	public String getBinRangeFrom() {
		return binRangeFrom;
	}

	public void setBinRangeFrom(String binRangeFrom) {
		this.binRangeFrom = binRangeFrom;
	}

	public String getBinRnageTo() {
		return binRnageTo;
	}

	public void setBinRnageTo(String binRnageTo) {
		this.binRnageTo = binRnageTo;
	}

	public String getBinDigit() {
		return binDigit;
	}

	public void setBinDigit(String binDigit) {
		this.binDigit = binDigit;
	}

}
