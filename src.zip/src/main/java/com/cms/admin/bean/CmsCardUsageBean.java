package com.cms.admin.bean;

import java.util.Date;

public class CmsCardUsageBean {
	
	    private int groupId;
	   
	    private String cardUsageGroupCode;
	    
	    private String cardUsageGroupName;
	   
	    private String cardUsageGroupDesc;
		
		private String cardUsageGrouptransactionAmount;
		
		private int status;
	    
		private String insertedBy;
	    
		private Date insertedDate; 
	    
		private String modifiedBy;
	    
	    private Date modifiedDate;

		public int getGroupId() {
			return groupId;
		}

		public void setGroupId(int groupId) {
			this.groupId = groupId;
		}

		public String getCardUsageGroupCode() {
			return cardUsageGroupCode;
		}

		public void setCardUsageGroupCode(String cardUsageGroupCode) {
			this.cardUsageGroupCode = cardUsageGroupCode;
		}

		public String getCardUsageGroupName() {
			return cardUsageGroupName;
		}

		public void setCardUsageGroupName(String cardUsageGroupName) {
			this.cardUsageGroupName = cardUsageGroupName;
		}

		public String getCardUsageGroupDesc() {
			return cardUsageGroupDesc;
		}

		public void setCardUsageGroupDesc(String cardUsageGroupDesc) {
			this.cardUsageGroupDesc = cardUsageGroupDesc;
		}

		public String getCardUsageGrouptransactionAmount() {
			return cardUsageGrouptransactionAmount;
		}

		public void setCardUsageGrouptransactionAmount(String cardUsageGrouptransactionAmount) {
			this.cardUsageGrouptransactionAmount = cardUsageGrouptransactionAmount;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public String getInsertedBy() {
			return insertedBy;
		}

		public void setInsertedBy(String insertedBy) {
			this.insertedBy = insertedBy;
		}

		public Date getInsertedDate() {
			return insertedDate;
		}

		public void setInsertedDate(Date insertedDate) {
			this.insertedDate = insertedDate;
		}

		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public Date getModifiedDate() {
			return modifiedDate;
		}

		public void setModifiedDate(Date modifiedDate) {
			this.modifiedDate = modifiedDate;
		}


}
