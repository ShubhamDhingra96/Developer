package com.cms.admin.bean;

public class CmsMerchantGroupRequest {

	private String groupId;

	private String merchantGroupCode;

	private String merchantGroupName;

	private String merchantGroupDescription;

	private String merchantNetworkType;

	private String merchantMCCGroup;

	private String merchantMCCCode;

	private String insertedDate;

	private String insertedBy;

	private String modifiedDate;

	private String modifiedBy;

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getMerchantGroupCode() {
		return merchantGroupCode;
	}

	public void setMerchantGroupCode(String merchantGroupCode) {
		this.merchantGroupCode = merchantGroupCode;
	}

	public String getMerchantGroupName() {
		return merchantGroupName;
	}

	public void setMerchantGroupName(String merchantGroupName) {
		this.merchantGroupName = merchantGroupName;
	}

	public String getMerchantGroupDescription() {
		return merchantGroupDescription;
	}

	public void setMerchantGroupDescription(String merchantGroupDescription) {
		this.merchantGroupDescription = merchantGroupDescription;
	}

	public String getMerchantNetworkType() {
		return merchantNetworkType;
	}

	public void setMerchantNetworkType(String merchantNetworkType) {
		this.merchantNetworkType = merchantNetworkType;
	}

	public String getMerchantMCCGroup() {
		return merchantMCCGroup;
	}

	public void setMerchantMCCGroup(String merchantMCCGroup) {
		this.merchantMCCGroup = merchantMCCGroup;
	}

	public String getMerchantMCCCode() {
		return merchantMCCCode;
	}

	public void setMerchantMCCCode(String merchantMCCCode) {
		this.merchantMCCCode = merchantMCCCode;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
