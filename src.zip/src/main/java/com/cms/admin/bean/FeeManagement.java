package com.cms.admin.bean;

import java.util.Date;

import javax.persistence.Column;

public class FeeManagement {

	private String feeCode;

	private String feeDescription;

	private String transaction;

	private String frequency;
	
	private String perFlat;

	private String percentage;
	
	private String flat;

	private String limit;
	
	private String maxLimit;
	
	private String minLimit;

	private String chargeFeeTo;

	private String groupTransactions;

	private String criteria;
	
	private String criteriaFrom;
	
	private String criteriaTo;
	
	private String countryCode;
	
	private String acquiringNetwork;
	
    private String acquiringNetworkName;
	
	private String deliveryChannels;
	
	private String deliveryChannelName;
	
	private String merchantIdGroup;
	
	private String merchantIdGroupName;
	
	private String rule;
	
	private String seperateLine;

	private String createdBy;

	private Date createdOn;

	private String modifiedBy;

	private Date modifiedOn;
	
	private String feeType;

	public String getFeeCode() {
		return feeCode;
	}

	public void setFeeCode(String feeCode) {
		this.feeCode = feeCode;
	}

	public String getFeeDescription() {
		return feeDescription;
	}

	public void setFeeDescription(String feeDescription) {
		this.feeDescription = feeDescription;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	
	public String getPerFlat() {
		return perFlat;
	}

	public void setPerFlat(String perFlat) {
		this.perFlat = perFlat;
	}

	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
    
	public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}

	public String getLimit() {
		return limit;
	}

	public void setLimit(String limit) {
		this.limit = limit;
	}
	
	public String getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(String maxLimit) {
		this.maxLimit = maxLimit;
	}

	public String getMinLimit() {
		return minLimit;
	}

	public void setMinLimit(String minLimit) {
		this.minLimit = minLimit;
	}

	public String getChargeFeeTo() {
		return chargeFeeTo;
	}

	public void setChargeFeeTo(String chargeFeeTo) {
		this.chargeFeeTo = chargeFeeTo;
	}

	public String getGroupTransactions() {
		return groupTransactions;
	}

	public void setGroupTransactions(String groupTransactions) {
		this.groupTransactions = groupTransactions;
	}

	public String getCriteria() {
		return criteria;
	}

	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getCriteriaFrom() {
		return criteriaFrom;
	}

	public void setCriteriaFrom(String criteriaFrom) {
		this.criteriaFrom = criteriaFrom;
	}

	public String getCriteriaTo() {
		return criteriaTo;
	}

	public void setCriteriaTo(String criteriaTo) {
		this.criteriaTo = criteriaTo;
	}
		
	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getAcquiringNetwork() {
		return acquiringNetwork;
	}

	public void setAcquiringNetwork(String acquiringNetwork) {
		this.acquiringNetwork = acquiringNetwork;
	}

	public String getDeliveryChannels() {
		return deliveryChannels;
	}

	public void setDeliveryChannels(String deliveryChannels) {
		this.deliveryChannels = deliveryChannels;
	}

	public String getMerchantIdGroup() {
		return merchantIdGroup;
	}

	public void setMerchantIdGroup(String merchantIdGroup) {
		this.merchantIdGroup = merchantIdGroup;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public String getAcquiringNetworkName() {
		return acquiringNetworkName;
	}

	public void setAcquiringNetworkName(String acquiringNetworkName) {
		this.acquiringNetworkName = acquiringNetworkName;
	}

	public String getDeliveryChannelName() {
		return deliveryChannelName;
	}

	public void setDeliveryChannelName(String deliveryChannelName) {
		this.deliveryChannelName = deliveryChannelName;
	}

	public String getMerchantIdGroupName() {
		return merchantIdGroupName;
	}

	public void setMerchantIdGroupName(String merchantIdGroupName) {
		this.merchantIdGroupName = merchantIdGroupName;
	}

	public String getSeperateLine() {
		return seperateLine;
	}

	public void setSeperateLine(String seperateLine) {
		this.seperateLine = seperateLine;
	}
	
	
	



}
