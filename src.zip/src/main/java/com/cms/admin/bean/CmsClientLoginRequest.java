package com.cms.admin.bean;

import java.util.Date;

import com.cms.admin.entity.CmsClient;

public class CmsClientLoginRequest {


	private String city;
	private String country;
	private String currencyAgent;
	private String designation;
	private String email;
	private String employeeNo;
	private String expiryDate;
	private String faxno;
	private String firstName;
	private String lastName;
	private String mobile;
	private String passportNo;
	private String postCode;
	private String region;
	private String state;
	private String telephoneOff;
	private String telephoneRes;
	private String userID;
	private Date insertedDate;
	private String insertedBy;
	private Date modifiedDate;
	private String modifiedBy;
	
	private String user;
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public String getUser() {
		return user;
	}
	
	private CmsClient cmsClient;
	
	
	public void setCmsClient(CmsClient cmsClient) {
		this.cmsClient = cmsClient;
	}
	
	public CmsClient getCmsClient() {
		return cmsClient;
	}

	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrencyAgent() {
		return currencyAgent;
	}

	public void setCurrencyAgent(String currencyAgent) {
		this.currencyAgent = currencyAgent;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getFaxno() {
		return faxno;
	}

	public void setFaxno(String faxno) {
		this.faxno = faxno;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTelephoneOff() {
		return telephoneOff;
	}

	public void setTelephoneOff(String telephoneOff) {
		this.telephoneOff = telephoneOff;
	}

	public String getTelephoneRes() {
		return telephoneRes;
	}

	public void setTelephoneRes(String telephoneRes) {
		this.telephoneRes = telephoneRes;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
