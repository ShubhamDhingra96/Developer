package com.cms.admin.bean;

import java.util.Date;

public class CmsMBin {

	private String binSetupId;
	private String bin;
	private String binDescription;
	private String binCurrency;
	private String currencyDescription;
	private String settlementCurrency;
	private String settlementCurrencyDesc;
	private String binType;
	private String binDigit;
	private String binIssue;
	private String checkPerity;
	private String insertedBy;
	private Date insertedDate;
	private String modifiedBy;
	private Date modifiedDate;

	
	
	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getBinSetupId() {
		return binSetupId;
	}

	public void setBinSetupId(String binSetupId) {
		this.binSetupId = binSetupId;
	}

	public String getBin() {
		return bin;
	}

	public void setBin(String bin) {
		this.bin = bin;
	}

	public String getBinDescription() {
		return binDescription;
	}

	public void setBinDescription(String binDescription) {
		this.binDescription = binDescription;
	}

	public String getBinCurrency() {
		return binCurrency;
	}

	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}

	public String getCurrencyDescription() {
		return currencyDescription;
	}

	public void setCurrencyDescription(String currencyDescription) {
		this.currencyDescription = currencyDescription;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public String getSettlementCurrencyDesc() {
		return settlementCurrencyDesc;
	}

	public void setSettlementCurrencyDesc(String settlementCurrencyDesc) {
		this.settlementCurrencyDesc = settlementCurrencyDesc;
	}

	public String getBinType() {
		return binType;
	}

	public void setBinType(String binType) {
		this.binType = binType;
	}

	public String getBinDigit() {
		return binDigit;
	}

	public void setBinDigit(String binDigit) {
		this.binDigit = binDigit;
	}

	public String getBinIssue() {
		return binIssue;
	}

	public void setBinIssue(String binIssue) {
		this.binIssue = binIssue;
	}

	public String getCheckPerity() {
		return checkPerity;
	}

	public void setCheckPerity(String checkPerity) {
		this.checkPerity = checkPerity;
	}

}
