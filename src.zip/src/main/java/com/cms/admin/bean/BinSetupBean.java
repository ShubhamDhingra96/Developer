package com.cms.admin.bean;

public class BinSetupBean {

	
	private String binSetupId;
	
	private String bin;
	public String getBinSetupId() {
		return binSetupId;
	}
	public void setBinSetupId(String binSetupId) {
		this.binSetupId = binSetupId;
	}
	public String getBin() {
		return bin;
	}
	public void setBin(String bin) {
		this.bin = bin;
	}
	public String getBinDesc() {
		return binDesc;
	}
	public void setBinDesc(String binDesc) {
		this.binDesc = binDesc;
	}
	public String getBinCurrency() {
		return binCurrency;
	}
	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}
	public String getCurrencyDesc() {
		return currencyDesc;
	}
	public void setCurrencyDesc(String currencyDesc) {
		this.currencyDesc = currencyDesc;
	}
	public String getSettlementCurrency() {
		return settlementCurrency;
	}
	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBinType() {
		return binType;
	}
	public void setBinType(String binType) {
		this.binType = binType;
	}
	public String getBinDigit() {
		return binDigit;
	}
	public void setBinDigit(String binDigit) {
		this.binDigit = binDigit;
	}
	public String getBinIssue() {
		return binIssue;
	}
	public void setBinIssue(String binIssue) {
		this.binIssue = binIssue;
	}
	public String getCheckPriority() {
		return checkPriority;
	}
	public void setCheckPriority(String checkPriority) {
		this.checkPriority = checkPriority;
	}
	private String binDesc;
	private String binCurrency;
	private String currencyDesc;
	private String settlementCurrency;
	private String description;
	private String binType;
	private String binDigit;
	private String binIssue;
	private String checkPriority;
}
