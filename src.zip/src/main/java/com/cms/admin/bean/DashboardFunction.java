package com.cms.admin.bean;

import java.util.ArrayList;
import java.util.List;

public class DashboardFunction {
	private String functionId;
	private String functionName;
	private List<DashbordFunctionJobs> jobs = new ArrayList<>();
	public String getFunctionId() {
		return functionId;
	}
	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	
	public List<DashbordFunctionJobs> getJobs() {
		return jobs;
	}
	
	public void setJobs(List<DashbordFunctionJobs> jobs) {
		this.jobs = jobs;
	}

	
	
}
