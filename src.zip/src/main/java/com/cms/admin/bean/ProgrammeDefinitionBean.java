package com.cms.admin.bean;

import java.util.Date;

public class ProgrammeDefinitionBean{

	private String applicationType;
	private String  authorizationrule;
	private String programmecode;
	private String programmedescription;
	private String shortdescription;
	private String insertedBy;
	private Date insertedDate;
	private String modifiedBy;
	private Date  modifiedDate;
	private String multipleProductAccount;
	
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getAuthorizationrule() {
		return authorizationrule;
	}
	public void setAuthorizationrule(String authorizationrule) {
		this.authorizationrule = authorizationrule;
	}
	public String getProgrammecode() {
		return programmecode;
	}
	public void setProgrammecode(String programmecode) {
		this.programmecode = programmecode;
	}
	public String getProgrammedescription() {
		return programmedescription;
	}
	public void setProgrammedescription(String programmedescription) {
		this.programmedescription = programmedescription;
	}
	public String getShortdescription() {
		return shortdescription;
	}
	public void setShortdescription(String shortdescription) {
		this.shortdescription = shortdescription;
	}
	public String getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}
	public Date getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getMultipleProductAccount() {
		return multipleProductAccount;
	}
	public void setMultipleProductAccount(String multipleProductAccount) {
		this.multipleProductAccount = multipleProductAccount;
	}
}
