package com.cms.admin.bean;

public class CmsClientRegisterRequest {

	private String cmsCompanyName;
	private String cmsCompanylocation;
	private String cmsCompanyAddress1;
	private String cmsCompanyAddress2;
	private String cmsCompanyCity;
	private String cmsCompanyState;
	private String cmsCompanyCountry;
	private String cmsCompanyCode;
	private String cmsCompanyPincode;
	private String cmsCompanyPhone1;
	private String clientID;
	private String companyid;
	private String insertedBy;
	private String modifiedBy;
	private String corporateType;
	private String userCreated;

	private CmsCompanyPersonDetail contactPersons[];

	public CmsCompanyPersonDetail[] getContactPersons() {
		return contactPersons;
	}

	public void setContactPersons(CmsCompanyPersonDetail[] contactPersons) {
		this.contactPersons = contactPersons;
	}

	public String getCmsCompanyName() {
		return cmsCompanyName;
	}

	public void setCmsCompanyName(String cmsCompanyName) {
		this.cmsCompanyName = cmsCompanyName;
	}

	public String getCmsCompanylocation() {
		return cmsCompanylocation;
	}

	public void setCmsCompanylocation(String cmsCompanylocation) {
		this.cmsCompanylocation = cmsCompanylocation;
	}

	public String getCmsCompanyAddress1() {
		return cmsCompanyAddress1;
	}

	public void setCmsCompanyAddress1(String cmsCompanyAddress1) {
		this.cmsCompanyAddress1 = cmsCompanyAddress1;
	}

	public String getCmsCompanyAddress2() {
		return cmsCompanyAddress2;
	}

	public void setCmsCompanyAddress2(String cmsCompanyAddress2) {
		this.cmsCompanyAddress2 = cmsCompanyAddress2;
	}

	public String getCmsCompanyCity() {
		return cmsCompanyCity;
	}

	public void setCmsCompanyCity(String cmsCompanyCity) {
		this.cmsCompanyCity = cmsCompanyCity;
	}

	public String getCmsCompanyState() {
		return cmsCompanyState;
	}

	public void setCmsCompanyState(String cmsCompanyState) {
		this.cmsCompanyState = cmsCompanyState;
	}

	public String getCmsCompanyCountry() {
		return cmsCompanyCountry;
	}

	public void setCmsCompanyCountry(String cmsCompanyCountry) {
		this.cmsCompanyCountry = cmsCompanyCountry;
	}

	public String getCmsCompanyCode() {
		return cmsCompanyCode;
	}

	public void setCmsCompanyCode(String cmsCompanyCode) {
		this.cmsCompanyCode = cmsCompanyCode;
	}

	public String getCmsCompanyPincode() {
		return cmsCompanyPincode;
	}

	public void setCmsCompanyPincode(String cmsCompanyPincode) {
		this.cmsCompanyPincode = cmsCompanyPincode;
	}

	public String getCmsCompanyPhone1() {
		return cmsCompanyPhone1;
	}

	public void setCmsCompanyPhone1(String cmsCompanyPhone1) {
		this.cmsCompanyPhone1 = cmsCompanyPhone1;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	public String getCompanyid() {
		return companyid;
	}

	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCorporateType() {
		return corporateType;
	}

	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

	public String getUserCreated() {
		return userCreated;
	}

	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	
	

}
