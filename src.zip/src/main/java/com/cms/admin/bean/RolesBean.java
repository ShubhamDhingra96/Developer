package com.cms.admin.bean;

import java.util.Arrays;

public class RolesBean {
	
	private AccessRightsBean roles[];
	
	public void setRoles(AccessRightsBean[] roles) {
		this.roles = roles;
	}
	
	public AccessRightsBean[] getRoles() {
		return roles;
	}

	@Override
	public String toString() {
		return "RolesBean [roles=" + Arrays.toString(roles) + "]";
	}
	
	

}
