package com.cms.admin.bean;

import java.util.Date;

public class AccessRightsBean {

	private Long mId;
	private String moduleId;
	private String moduleName;
	private Boolean isChecked;
	private String assignuser;
	private String user;
	private String clientid;
	private Date insertedDate;
	private Date modifiedDate;
	private String insertedBy;
	private String modifiedBy;
	private char status;
	private CmsFunctionsBean functions[];

	
	
	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public void setmId(Long mId) {
		this.mId = mId;
	}

	public Long getmId() {
		return mId;
	}

	public String getAssignuser() {
		return assignuser;
	}

	public void setAssignuser(String assignuser) {
		this.assignuser = assignuser;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getClientid() {
		return clientid;
	}

	public void setClientid(String clientid) {
		this.clientid = clientid;
	}

	public void setFunctions(CmsFunctionsBean[] functions) {
		this.functions = functions;
	}

	public CmsFunctionsBean[] getFunctions() {
		return functions;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	}

}
