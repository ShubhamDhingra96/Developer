package com.cms.admin.bean;

import java.util.Date;

public class CmsLimitManagement {
	
	   private String limitCode;
	    private String limitName;
	    private String countryCode;
	    private String acquiringNetwork;
	    private String deliveryChannels;
	    private String transaction;
	    private String frequency;
	    private String levelCheck;
	    private String maxCount;
	    private String currency;
	    private String minAmount;
	    private String maxAmount;
	    private String createdby;
	    private Date createdon;
	    private String modifiedby;
	    private Date modifiedon;
	    private String limitType;
		public String getLimitCode() {
			return limitCode;
		}
		public void setLimitCode(String limitCode) {
			this.limitCode = limitCode;
		}
		public String getLimitName() {
			return limitName;
		}
		public void setLimitName(String limitName) {
			this.limitName = limitName;
		}
		public String getCountryCode() {
			return countryCode;
		}
		public void setCountryCode(String countryCode) {
			this.countryCode = countryCode;
		}
		public String getAcquiringNetwork() {
			return acquiringNetwork;
		}
		public void setAcquiringNetwork(String acquiringNetwork) {
			this.acquiringNetwork = acquiringNetwork;
		}
		public String getDeliveryChannels() {
			return deliveryChannels;
		}
		public void setDeliveryChannels(String deliveryChannels) {
			this.deliveryChannels = deliveryChannels;
		}
		public String getTransaction() {
			return transaction;
		}
		public void setTransaction(String transaction) {
			this.transaction = transaction;
		}
		public String getFrequency() {
			return frequency;
		}
		public void setFrequency(String frequency) {
			this.frequency = frequency;
		}
		public String getLevelCheck() {
			return levelCheck;
		}
		public void setLevelCheck(String levelCheck) {
			this.levelCheck = levelCheck;
		}
		public String getMaxCount() {
			return maxCount;
		}
		public void setMaxCount(String maxCount) {
			this.maxCount = maxCount;
		}
		public String getCurrency() {
			return currency;
		}
		public void setCurrency(String currency) {
			this.currency = currency;
		}
		public String getMinAmount() {
			return minAmount;
		}
		public void setMinAmount(String minAmount) {
			this.minAmount = minAmount;
		}
		public String getMaxAmount() {
			return maxAmount;
		}
		public void setMaxAmount(String maxAmount) {
			this.maxAmount = maxAmount;
		}
		public String getCreatedby() {
			return createdby;
		}
		public void setCreatedby(String createdby) {
			this.createdby = createdby;
		}
		public Date getCreatedon() {
			return createdon;
		}
		public void setCreatedon(Date createdon) {
			this.createdon = createdon;
		}
		public String getModifiedby() {
			return modifiedby;
		}
		public void setModifiedby(String modifiedby) {
			this.modifiedby = modifiedby;
		}
		public Date getModifiedon() {
			return modifiedon;
		}
		public void setModifiedon(Date modifiedon) {
			this.modifiedon = modifiedon;
		}
		
		public String getLimitType() {
			return limitType;
		}
		public void setLimitType(String limitType) {
			this.limitType = limitType;
		}
		@Override
		public String toString() {
			return "CmsLimitManagement [limitCode=" + limitCode + ", limitName=" + limitName + ", countryCode="
					+ countryCode + ", acquiringNetwork=" + acquiringNetwork + ", deliveryChannels=" + deliveryChannels
					+ ", transaction=" + transaction + ", frequency=" + frequency + ", levelCheck=" + levelCheck
					+ ", maxCount=" + maxCount + ", currency=" + currency + ", minAmount=" + minAmount + ", maxAmount="
					+ maxAmount + ", createdby=" + createdby + ", createdon=" + createdon + ", modifiedby=" + modifiedby
					+ ", modifiedon=" + modifiedon + ", limitType=" + limitType + "]";
		}
	    
	    

}
