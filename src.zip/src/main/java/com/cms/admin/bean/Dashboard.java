package com.cms.admin.bean;

import java.util.List;

import com.cms.admin.entity.CmsMFunctions;

public class Dashboard {
	private String moduleId;
	private String moduleName;
	private List<CmsMFunctions> functions;

	

	public List<CmsMFunctions> getFunctions() {
		return functions;
	}

	public void setFunctions(List<CmsMFunctions> functions) {
		this.functions = functions;
	}

	public String getModuleId() {
		return moduleId;
	}

	public void setModuleId(String moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

}
