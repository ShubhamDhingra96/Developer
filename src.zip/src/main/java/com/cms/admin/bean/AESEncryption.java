package com.cms.admin.bean;

public class AESEncryption {

	private byte[] screteKeyByte;
	private String encryptedKey;
	private String decryptedKey;
	

	public byte[] getScreteKeyByte() {
		return screteKeyByte;
	}
	public void setScreteKeyByte(byte[] screteKeyByte) {
		this.screteKeyByte = screteKeyByte;
	}
	public String getEncryptedKey() {
		return encryptedKey;
	}
	public void setEncryptedKey(String encryptedKey) {
		this.encryptedKey = encryptedKey;
	}
	public String getDecryptedKey() {
		return decryptedKey;
	}
	public void setDecryptedKey(String decryptedKey) {
		this.decryptedKey = decryptedKey;
	}
	
	
	
	
}
