package com.cms.admin.bean;

import java.util.HashMap;

import java.util.Map;

public class Error_Messages {

	private static Map<String, Object> message = new HashMap<String, Object>();

	public Error_Messages() {

	}

	public static void SetError(Map<String, Object> message) {
		Error_Messages.message = message;
	}

	public static Map<String, Object> getMessage() {
		return Error_Messages.message;
	}

}
