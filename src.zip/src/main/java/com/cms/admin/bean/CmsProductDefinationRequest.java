package com.cms.admin.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CmsProductDefinationRequest {

	private String productCode;
	private String productName;
	private String productDescription;
	private String pairCards;
	private String applicationType;
	private String programType;
	private String programDescription;
	private String productCurrency;
	private String currencyDescription;
	private String serviceCode;
	private String pinTryLimit;
	private String cardGenerationMethod;
	private String cardExpiryMethod;
	private String deliverMethod;
	private String expiryMonth;
	private String binGroup;
	private String binCurrency;
	private String binGroupDescription;
	private String binRangeFrom;
	private String binrangeTo;
	private String pinDeliveryMethod;
	private String expiryPeriod;
	private String embossingTemplateId;
	private String replacementTemplateId;
	private String welcomeTemplate;
	private String issuingCurrencyCountry;
	private String variableExpiryPeriod;
	private String programCode;
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> cardActivationGroup;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> countryCurrencyListDB;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> countryCurrencyList;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> cardActivationGroupAdd;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> cardActivationRemove;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> plasticCode;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> plasticCodeAdd;
	@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
	private List<String> plasticCodeRemove;
	private String insertedDate;
	private String modifiedDate;
	private String clientId;
	private String insertedBy;
	private String modifiedBy;
	private String cardEmbossingEncode;
	private String cardEmbossing;
	
	public String getCardEmbossing() {
		return cardEmbossing;
	}
	public void setCardEmbossing(String cardEmbossing) {
		this.cardEmbossing = cardEmbossing;
	}
	public String getVariableExpiryPeriod() {
		return variableExpiryPeriod;
	}
	public void setVariableExpiryPeriod(String variableExpiryPeriod) {
		this.variableExpiryPeriod = variableExpiryPeriod;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getPairCards() {
		return pairCards;
	}
	public void setPairCards(String pairCards) {
		this.pairCards = pairCards;
	}
	public String getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}
	public String getProgramType() {
		return programType;
	}
	public void setProgramType(String programType) {
		this.programType = programType;
	}
	public String getProgramDescription() {
		return programDescription;
	}
	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}
	public String getProductCurrency() {
		return productCurrency;
	}
	public void setProductCurrency(String productCurrency) {
		this.productCurrency = productCurrency;
	}
	public String getCurrencyDescription() {
		return currencyDescription;
	}
	public void setCurrencyDescription(String currencyDescription) {
		this.currencyDescription = currencyDescription;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getPinTryLimit() {
		return pinTryLimit;
	}
	public void setPinTryLimit(String pinTryLimit) {
		this.pinTryLimit = pinTryLimit;
	}
	public String getCardGenerationMethod() {
		return cardGenerationMethod;
	}
	public void setCardGenerationMethod(String cardGenerationMethod) {
		this.cardGenerationMethod = cardGenerationMethod;
	}
	public String getCardExpiryMethod() {
		return cardExpiryMethod;
	}
	public void setCardExpiryMethod(String cardExpiryMethod) {
		this.cardExpiryMethod = cardExpiryMethod;
	}
	public String getDeliverMethod() {
		return deliverMethod;
	}
	public void setDeliverMethod(String deliverMethod) {
		this.deliverMethod = deliverMethod;
	}
	public String getExpiryMonth() {
		return expiryMonth;
	}
	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth = expiryMonth;
	}
	public String getBinGroup() {
		return binGroup;
	}
	public void setBinGroup(String binGroup) {
		this.binGroup = binGroup;
	}
	public String getBinCurrency() {
		return binCurrency;
	}
	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}
	public String getBinGroupDescription() {
		return binGroupDescription;
	}
	public void setBinGroupDescription(String binGroupDescription) {
		this.binGroupDescription = binGroupDescription;
	}
	public String getBinRangeFrom() {
		return binRangeFrom;
	}
	public void setBinRangeFrom(String binRangeFrom) {
		this.binRangeFrom = binRangeFrom;
	}
	public String getBinrangeTo() {
		return binrangeTo;
	}
	public void setBinrangeTo(String binrangeTo) {
		this.binrangeTo = binrangeTo;
	}
	public String getPinDeliveryMethod() {
		return pinDeliveryMethod;
	}
	public void setPinDeliveryMethod(String pinDeliveryMethod) {
		this.pinDeliveryMethod = pinDeliveryMethod;
	}
	public String getExpiryPeriod() {
		return expiryPeriod;
	}
	public void setExpiryPeriod(String expiryPeriod) {
		this.expiryPeriod = expiryPeriod;
	}
	public String getEmbossingTemplateId() {
		return embossingTemplateId;
	}
	public void setEmbossingTemplateId(String embossingTemplateId) {
		this.embossingTemplateId = embossingTemplateId;
	}
	public String getReplacementTemplateId() {
		return replacementTemplateId;
	}
	public void setReplacementTemplateId(String replacementTemplateId) {
		this.replacementTemplateId = replacementTemplateId;
	}
	public String getWelcomeTemplate() {
		return welcomeTemplate;
	}
	public void setWelcomeTemplate(String welcomeTemplate) {
		this.welcomeTemplate = welcomeTemplate;
	}
	public String getIssuingCurrencyCountry() {
		return issuingCurrencyCountry;
	}
	public void setIssuingCurrencyCountry(String issuingCurrencyCountry) {
		this.issuingCurrencyCountry = issuingCurrencyCountry;
	}
	public List<String> getCardActivationGroup() {
		return cardActivationGroup;
	}
	public void setCardActivationGroup(List<String> cardActivationGroup) {
		this.cardActivationGroup = cardActivationGroup;
	}
	public List<String> getCountryCurrencyListDB() {
		return countryCurrencyListDB;
	}
	public void setCountryCurrencyListDB(List<String> countryCurrencyListDB) {
		this.countryCurrencyListDB = countryCurrencyListDB;
	}
	public List<String> getCountryCurrencyList() {
		return countryCurrencyList;
	}
	public void setCountryCurrencyList(List<String> countryCurrencyList) {
		this.countryCurrencyList = countryCurrencyList;
	}
	public List<String> getCardActivationGroupAdd() {
		return cardActivationGroupAdd;
	}
	public void setCardActivationGroupAdd(List<String> cardActivationGroupAdd) {
		this.cardActivationGroupAdd = cardActivationGroupAdd;
	}
	public List<String> getCardActivationRemove() {
		return cardActivationRemove;
	}
	public void setCardActivationRemove(List<String> cardActivationRemove) {
		this.cardActivationRemove = cardActivationRemove;
	}
	
	public List<String> getPlasticCode() {
		return plasticCode;
	}
	public void setPlasticCode(List<String> plasticCode) {
		this.plasticCode = plasticCode;
	}
	public List<String> getPlasticCodeAdd() {
		return plasticCodeAdd;
	}
	public void setPlasticCodeAdd(List<String> plasticCodeAdd) {
		this.plasticCodeAdd = plasticCodeAdd;
	}
	public List<String> getPlasticCodeRemove() {
		return plasticCodeRemove;
	}
	public void setPlasticCodeRemove(List<String> plasticCodeRemove) {
		this.plasticCodeRemove = plasticCodeRemove;
	}
	public String getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCardEmbossingEncode() {
		return cardEmbossingEncode;
	}
	public void setCardEmbossingEncode(String cardEmbossingEncode) {
		this.cardEmbossingEncode = cardEmbossingEncode;
	}
	
	
	
}