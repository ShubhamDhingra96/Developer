package com.cms.admin.bean;

public class CmsDeliveryChannelRequest {

	private Integer groupId;

	private String groupCode;
	
	private String groupName;

	private String groupDescription;

	private String groupDeliveryChannel;

	private String groupTransactionChannel;

	private String insertedDate;

	private String insertedBy;

	private String modifiedDate;

	private String modifiedBy;

	public String getInsertedDate() {
		return insertedDate;
	}

	public String getGroupDeliveryChannel() {
		return groupDeliveryChannel;
	}

	public void setGroupDeliveryChannel(String groupDeliveryChannel) {
		this.groupDeliveryChannel = groupDeliveryChannel;
	}

	public String getGroupTransactionChannel() {
		return groupTransactionChannel;
	}

	public void setGroupTransactionChannel(String groupTransactionChannel) {
		this.groupTransactionChannel = groupTransactionChannel;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}



	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	
	public String getGroupCode() {
		return groupCode;
	}

}
