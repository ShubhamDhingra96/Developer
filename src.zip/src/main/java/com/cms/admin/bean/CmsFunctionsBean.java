package com.cms.admin.bean;

import java.util.Date;

public class CmsFunctionsBean {

	private Long fId;
	private Long mId;
	private Date insertedDate;
	private Date modifiedDate;
	private String insertedBy;
	private String modifiedBy;
	private char status;

	private String cmsMFunctionId;
	private String cmsMFunctionName;
	private Boolean isChecked;
	private CmsJobsBean cmsMJobsMappingList[];

	public Long getfId() {
		return fId;
	}

	public void setfId(Long fId) {
		this.fId = fId;
	}

	public Long getmId() {
		return mId;
	}

	public void setmId(Long mId) {
		this.mId = mId;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getCmsMFunctionId() {
		return cmsMFunctionId;
	}

	public void setIsChecked(Boolean isChecked) {
		this.isChecked = isChecked;
	}

	public Boolean getIsChecked() {
		return isChecked;
	}

	public void setCmsMFunctionId(String cmsMFunctionId) {
		this.cmsMFunctionId = cmsMFunctionId;
	}

	public String getCmsMFunctionName() {
		return cmsMFunctionName;
	}

	public void setCmsMFunctionName(String cmsMFunctionName) {
		this.cmsMFunctionName = cmsMFunctionName;
	}

	public CmsJobsBean[] getCmsMJobsMappingList() {
		return cmsMJobsMappingList;
	}

	public void setCmsMJobsMappingList(CmsJobsBean[] cmsMJobsMappingList) {
		this.cmsMJobsMappingList = cmsMJobsMappingList;
	}

}
