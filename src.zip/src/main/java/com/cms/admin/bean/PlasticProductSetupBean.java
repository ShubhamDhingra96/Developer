package com.cms.admin.bean;

import java.sql.Date;
import java.util.List;


import javax.validation.constraints.Min;
import javax.validation.constraints.Size;


public class PlasticProductSetupBean {
	
	
	private String plasticId;
	@Size(min = 10,message = "Length should not be less than 10 digit.")
	private String plasticCode;
	private int serviceCode;
	private String plasticDescription;
	private String serviceDescription;
    private Date insertedDate;
    private Date modifiedDate;
    private String clientId;
    
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public int getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(int serviceCode) {
		this.serviceCode = serviceCode;
	}
	public Date getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getPlasticId() {
		return plasticId;
	}
	public void setPlasticId(String plasticId) {
		this.plasticId = plasticId;
	}
	public String getPlasticCode() {
		return plasticCode;
	}
	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public String getPlasticDescription() {
		return plasticDescription;
	}
	public void setPlasticDescription(String plasticDescription) {
		this.plasticDescription = plasticDescription;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
	List<PlasticProductSetupBean> plasticDetails;
	public List<PlasticProductSetupBean> getPlasticDetails() {
		return plasticDetails;
	}
	public void setPlasticDetails(List<PlasticProductSetupBean> plasticDetails) {
		this.plasticDetails = plasticDetails;
	}

}
