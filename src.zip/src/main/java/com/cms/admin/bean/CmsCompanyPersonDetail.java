package com.cms.admin.bean;

public class CmsCompanyPersonDetail {
	private String cmsCompanyCPMailingAddress;
	private String cmsCompanyCPTelRes;
	private String cmsCompanyCPMobile;
	private String cmsCompanyCPfax;
	private String cmsCompanyCity;
	private String cmsCompanyState;
	private String cmsCompanyCPPincode;
	private String cmsCompanyCPFname;
	private String cmsCompanyCPLname;
	private boolean selected;
	private String cmsCompanyCPfullName;
	private String cmsCompanyCPTelOff;
	private String cmsCompanyCPlocation;
	private String cmsCompanyCPEmail;
	private String cmsCompanyCountry;

	public String getCmsCompanyCPMailingAddress() {
		return cmsCompanyCPMailingAddress;
	}

	public void setCmsCompanyCPMailingAddress(String cmsCompanyCPMailingAddress) {
		this.cmsCompanyCPMailingAddress = cmsCompanyCPMailingAddress;
	}

	public String getCmsCompanyCPTelRes() {
		return cmsCompanyCPTelRes;
	}

	public void setCmsCompanyCPTelRes(String cmsCompanyCPTelRes) {
		this.cmsCompanyCPTelRes = cmsCompanyCPTelRes;
	}

	public String getCmsCompanyCPMobile() {
		return cmsCompanyCPMobile;
	}

	public void setCmsCompanyCPMobile(String cmsCompanyCPMobile) {
		this.cmsCompanyCPMobile = cmsCompanyCPMobile;
	}

	public String getCmsCompanyCPfax() {
		return cmsCompanyCPfax;
	}

	public void setCmsCompanyCPfax(String cmsCompanyCPfax) {
		this.cmsCompanyCPfax = cmsCompanyCPfax;
	}

	public String getCmsCompanyCity() {
		return cmsCompanyCity;
	}

	public void setCmsCompanyCity(String cmsCompanyCity) {
		this.cmsCompanyCity = cmsCompanyCity;
	}

	public String getCmsCompanyState() {
		return cmsCompanyState;
	}

	public void setCmsCompanyState(String cmsCompanyState) {
		this.cmsCompanyState = cmsCompanyState;
	}

	public String getCmsCompanyCPPincode() {
		return cmsCompanyCPPincode;
	}

	public void setCmsCompanyCPPincode(String cmsCompanyCPPincode) {
		this.cmsCompanyCPPincode = cmsCompanyCPPincode;
	}

	public String getCmsCompanyCPFname() {
		return cmsCompanyCPFname;
	}

	public void setCmsCompanyCPFname(String cmsCompanyCPFname) {
		this.cmsCompanyCPFname = cmsCompanyCPFname;
	}

	public String getCmsCompanyCPLname() {
		return cmsCompanyCPLname;
	}

	public void setCmsCompanyCPLname(String cmsCompanyCPLname) {
		this.cmsCompanyCPLname = cmsCompanyCPLname;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}

	public String getCmsCompanyCPfullName() {
		return cmsCompanyCPfullName;
	}

	public void setCmsCompanyCPfullName(String cmsCompanyCPfullName) {
		this.cmsCompanyCPfullName = cmsCompanyCPfullName;
	}

	public String getCmsCompanyCPTelOff() {
		return cmsCompanyCPTelOff;
	}

	public void setCmsCompanyCPTelOff(String cmsCompanyCPTelOff) {
		this.cmsCompanyCPTelOff = cmsCompanyCPTelOff;
	}

	public String getCmsCompanyCPlocation() {
		return cmsCompanyCPlocation;
	}

	public void setCmsCompanyCPlocation(String cmsCompanyCPlocation) {
		this.cmsCompanyCPlocation = cmsCompanyCPlocation;
	}

	public String getCmsCompanyCPEmail() {
		return cmsCompanyCPEmail;
	}

	public void setCmsCompanyCPEmail(String cmsCompanyCPEmail) {
		this.cmsCompanyCPEmail = cmsCompanyCPEmail;
	}

	public String getCmsCompanyCountry() {
		return cmsCompanyCountry;
	}

	public void setCmsCompanyCountry(String cmsCompanyCountry) {
		this.cmsCompanyCountry = cmsCompanyCountry;
	}

}
