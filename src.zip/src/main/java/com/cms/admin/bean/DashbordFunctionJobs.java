package com.cms.admin.bean;

public class DashbordFunctionJobs {
private String jobId;
private String jobName;
public String getJobId() {
	return jobId;
}
public void setJobId(String jobId) {
	this.jobId = jobId;
}
public String getJobName() {
	return jobName;
}
public void setJobName(String jobName) {
	this.jobName = jobName;
}


}
