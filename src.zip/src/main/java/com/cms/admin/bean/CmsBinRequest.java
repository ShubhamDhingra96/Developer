package com.cms.admin.bean;

public class CmsBinRequest {

	private CmsClientLoginRequest loginUser;
	private String binSetupId;
	public String getBinSetupId() {
		return binSetupId;
	}

	public void setBinSetupId(String binSetupId) {
		this.binSetupId = binSetupId;
	}

	private String cmsBinNumber;
	private String cmsBinDiscription;
	private String cmsBinCurrency;
	private String cmsBinCurrencyDesc;
	private String binNumber;
	
	
	public void setBinNumber(String binNumber) {
		this.binNumber = binNumber;
	}
	
	public String getBinNumber() {
		return binNumber;
	}
	
	public String getCmsBinCurrencyDesc() {
		return cmsBinCurrencyDesc;
	}

	public void setCmsBinCurrencyDesc(String cmsBinCurrencyDesc) {
		this.cmsBinCurrencyDesc = cmsBinCurrencyDesc;
	}

	public String getCmsSettlementCurrencyDesc() {
		return cmsSettlementCurrencyDesc;
	}

	public void setCmsSettlementCurrencyDesc(String cmsSettlementCurrencyDesc) {
		this.cmsSettlementCurrencyDesc = cmsSettlementCurrencyDesc;
	}

	private String cmsSettlementCurrency;
	private String cmsSettlementCurrencyDesc;
	private String cmsBinType;
	private String cmsBinDigit;
	private String cmsBinIssuer;
	private String cmsBinStatus;
	private String cmsCheckParity;
	private String cmsBinrangeFrom;
	private String cmsBinrangeTo;
	private String plasticCode;
	private String clientId;

	public CmsClientLoginRequest getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(CmsClientLoginRequest loginUser) {
		this.loginUser = loginUser;
	}

	public String getCmsBinNumber() {
		return cmsBinNumber;
	}

	public void setCmsBinNumber(String cmsBinNumber) {
		this.cmsBinNumber = cmsBinNumber;
	}

	public String getCmsBinDiscription() {
		return cmsBinDiscription;
	}

	public void setCmsBinDiscription(String cmsBinDiscription) {
		this.cmsBinDiscription = cmsBinDiscription;
	}

	public String getCmsBinCurrency() {
		return cmsBinCurrency;
	}

	public void setCmsBinCurrency(String cmsBinCurrency) {
		this.cmsBinCurrency = cmsBinCurrency;
	}

	public String getCmsSettlementCurrency() {
		return cmsSettlementCurrency;
	}

	public void setCmsSettlementCurrency(String cmsSettlementCurrency) {
		this.cmsSettlementCurrency = cmsSettlementCurrency;
	}

	public String getCmsBinType() {
		return cmsBinType;
	}

	public void setCmsBinType(String cmsBinType) {
		this.cmsBinType = cmsBinType;
	}

	public String getCmsBinDigit() {
		return cmsBinDigit;
	}

	public void setCmsBinDigit(String cmsBinDigit) {
		this.cmsBinDigit = cmsBinDigit;
	}

	public String getCmsBinIssuer() {
		return cmsBinIssuer;
	}

	public void setCmsBinIssuer(String cmsBinIssuer) {
		this.cmsBinIssuer = cmsBinIssuer;
	}

	public String getCmsBinStatus() {
		return cmsBinStatus;
	}

	public void setCmsBinStatus(String cmsBinStatus) {
		this.cmsBinStatus = cmsBinStatus;
	}

	public String getCmsCheckParity() {
		return cmsCheckParity;
	}

	public void setCmsCheckParity(String cmsCheckParity) {
		this.cmsCheckParity = cmsCheckParity;
	}

	public String getCmsBinrangeFrom() {
		return cmsBinrangeFrom;
	}

	public void setCmsBinrangeFrom(String cmsBinrangeFrom) {
		this.cmsBinrangeFrom = cmsBinrangeFrom;
	}

	public String getCmsBinrangeTo() {
		return cmsBinrangeTo;
	}

	public void setCmsBinrangeTo(String cmsBinrangeTo) {
		this.cmsBinrangeTo = cmsBinrangeTo;
	}

	public String getPlasticCode() {
		return plasticCode;
	}

	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	

}
