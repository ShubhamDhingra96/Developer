package com.cms.admin.bean;

public class CustomerRegistration {

	private String customerId;
	private String firstName;
	private String middleName;
	private String lastName;
	private String dateOfBirth;
	private String motherName;
	private String gender;
	private String nationality;
	private String maritalStatus;
	private String residenceAddress1;
	private String residenceAddress2;
	private String residenceAddress3;
	private String residenceAddress4;
	private String city;
	private String state;
	private String country;
	private String pinCode;
	private String phoneNumber;
	private String officeAddress1;
	private String officeAddress2;
	private String officeAddress3;
	private String officeAddress4;
	private String officeCity;
	private String officeState;
	private String officeCountry;
	private String officePinCode;
	private String officePhoneNumber;
	private String officeExtensionNumber;
	private String mobileNumber;
	private String mailTo;
	private String emailAddress;
	private String alternativeEmailAddress;
	private String applicationDate;
	private String passportNumber;
	private String passportIssueDate;
	private String passportExpiryDate;
	private String panOrForm;
	private String panNumber;
	private IdentificationType[] identificationTable;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getResidenceAddress1() {
		return residenceAddress1;
	}
	public void setResidenceAddress1(String residenceAddress1) {
		this.residenceAddress1 = residenceAddress1;
	}
	public String getResidenceAddress2() {
		return residenceAddress2;
	}
	public void setResidenceAddress2(String residenceAddress2) {
		this.residenceAddress2 = residenceAddress2;
	}
	public String getResidenceAddress3() {
		return residenceAddress3;
	}
	public void setResidenceAddress3(String residenceAddress3) {
		this.residenceAddress3 = residenceAddress3;
	}
	public String getResidenceAddress4() {
		return residenceAddress4;
	}
	public void setResidenceAddress4(String residenceAddress4) {
		this.residenceAddress4 = residenceAddress4;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getOfficeAddress1() {
		return officeAddress1;
	}
	public void setOfficeAddress1(String officeAddress1) {
		this.officeAddress1 = officeAddress1;
	}
	public String getOfficeAddress2() {
		return officeAddress2;
	}
	public void setOfficeAddress2(String officeAddress2) {
		this.officeAddress2 = officeAddress2;
	}
	public String getOfficeAddress3() {
		return officeAddress3;
	}
	public void setOfficeAddress3(String officeAddress3) {
		this.officeAddress3 = officeAddress3;
	}
	public String getOfficeAddress4() {
		return officeAddress4;
	}
	public void setOfficeAddress4(String officeAddress4) {
		this.officeAddress4 = officeAddress4;
	}
	public String getOfficeCity() {
		return officeCity;
	}
	public void setOfficeCity(String officeCity) {
		this.officeCity = officeCity;
	}
	public String getOfficeState() {
		return officeState;
	}
	public void setOfficeState(String officeState) {
		this.officeState = officeState;
	}
	public String getOfficeCountry() {
		return officeCountry;
	}
	public void setOfficeCountry(String officeCountry) {
		this.officeCountry = officeCountry;
	}
	public String getOfficePinCode() {
		return officePinCode;
	}
	public void setOfficePinCode(String officePinCode) {
		this.officePinCode = officePinCode;
	}
	public String getOfficePhoneNumber() {
		return officePhoneNumber;
	}
	public void setOfficePhoneNumber(String officePhoneNumber) {
		this.officePhoneNumber = officePhoneNumber;
	}
	public String getOfficeExtensionNumber() {
		return officeExtensionNumber;
	}
	public void setOfficeExtensionNumber(String officeExtensionNumber) {
		this.officeExtensionNumber = officeExtensionNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getMailTo() {
		return mailTo;
	}
	public void setMailTo(String mailTo) {
		this.mailTo = mailTo;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getAlternativeEmailAddress() {
		return alternativeEmailAddress;
	}
	public void setAlternativeEmailAddress(String alternativeEmailAddress) {
		this.alternativeEmailAddress = alternativeEmailAddress;
	}
	public String getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(String applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getPassportNumber() {
		return passportNumber;
	}
	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}
	public String getPassportIssueDate() {
		return passportIssueDate;
	}
	public void setPassportIssueDate(String passportIssueDate) {
		this.passportIssueDate = passportIssueDate;
	}
	public String getPassportExpiryDate() {
		return passportExpiryDate;
	}
	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}
	public String getPanOrForm() {
		return panOrForm;
	}
	public void setPanOrForm(String panOrForm) {
		this.panOrForm = panOrForm;
	}
	public IdentificationType[] getIdentificationTable() {
		return identificationTable;
	}
	public void setIdentificationTable(IdentificationType[] identificationTable) {
		this.identificationTable = identificationTable;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	
	
	
	
}
