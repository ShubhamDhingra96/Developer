package com.cms.admin.bean;

import java.util.List;

public class CMS_Message {
	
	private String message;
	private Integer messageCode;
	private String access_token;
	private String session;
	private String role;
	private List<Object> loginUser;
	
	
	
	
	
	public CMS_Message(String message, Integer messageCode, String access_token, String session, String role) {
		super();
		this.message = message;
		this.messageCode = messageCode;
		this.access_token = access_token;
		this.session = session;
		this.role = role;
		
	}
	public CMS_Message() {
		
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(Integer messageCode) {
		this.messageCode = messageCode;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public List<Object> getLoginUser() {
		return loginUser;
	}
	public void setLoginUser(List<Object> loginUser) {
		this.loginUser = loginUser;
	}
	
	

}
