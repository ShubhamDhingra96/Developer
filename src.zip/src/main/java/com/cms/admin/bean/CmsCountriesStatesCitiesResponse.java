package com.cms.admin.bean;

import java.util.List;

import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;

public class CmsCountriesStatesCitiesResponse {

	private List<CmsCountry> countries;
	private List<CmsStates> states;

	public List<CmsCountry> getCountries() {
		return countries;
	}

	public void setCountries(List<CmsCountry> countries) {
		this.countries = countries;
	}

	public List<CmsStates> getStates() {
		return states;
	}

	public void setStates(List<CmsStates> states) {
		this.states = states;
	}

}
