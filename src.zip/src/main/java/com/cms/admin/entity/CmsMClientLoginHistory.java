package com.cms.admin.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.ForeignKey;

/**
 *
 * @author sahadeo.naik
 */
@Entity
@Table(name = "CMS_M_CLIENT_LOGIN_HISTORY")
@SequenceGenerator(sequenceName = "CMS_M_CLIENT_LOGIN_HISTORY_SEQ", name = "CMS_M_CLIENT_LOGIN_HISTORY_SEQ", allocationSize = 1)
public class CmsMClientLoginHistory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_M_CLIENT_LOGIN_HISTORY_SEQ")
    @Column(name = "LOGIN_ID")
    private int loginId;
    
   
    @ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "USERNAME", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
    private CmsClientLogin username;

    
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "PASSWORD")
    private String password;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "CMS_CLIENT_ID")
    private String cmsClientId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PASSWORDSTATUS")
    private String passwordstatus;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ISADMIN")
    private String isadmin;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ISUSER")
    private String isuser;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ISCLIENT")
    private String isclient;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "PERMISSION_ID")
    private String permissionId;
    @Column(name = "INSERTED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertedDate;
    @Size(max = 20)
    @Column(name = "INSERTEDBY")
    private String insertedby;
    @Column(name = "MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Size(max = 20)
    @Column(name = "MODIFIEDBY")
    private String modifiedby;
    @Size(max = 255)
    @Column(name = "CLIENTSTATUS")
    private String clientstatus;
    @Column(name = "LOGIN_APPEMPTS")
    private BigInteger loginAppempts;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ACCOUNTLOCK_FLAG")
    private short accountlockFlag;
    @Column(name = "PASSWORD_MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date passwordModifiedDate;
    @Column(name = "LAST_LOGIN_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastLoginTime;

    public CmsMClientLoginHistory() {
    }

    public CmsMClientLoginHistory(int loginId) {
        this.loginId = loginId;
    }


    public int getLoginId() {
        return loginId;
    }

    public void setLoginId(int loginId) {
        this.loginId = loginId;
    }

    public CmsClientLogin getUsername() {
		return username;
	}

	public void setUsername(CmsClientLogin username) {
		this.username = username;
	}

	public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCmsClientId() {
        return cmsClientId;
    }

    public void setCmsClientId(String cmsClientId) {
        this.cmsClientId = cmsClientId;
    }

    public String getPasswordstatus() {
        return passwordstatus;
    }

    public void setPasswordstatus(String passwordstatus) {
        this.passwordstatus = passwordstatus;
    }

    public String getIsadmin() {
        return isadmin;
    }

    public void setIsadmin(String isadmin) {
        this.isadmin = isadmin;
    }

    public String getIsuser() {
        return isuser;
    }

    public void setIsuser(String isuser) {
        this.isuser = isuser;
    }

    public String getIsclient() {
        return isclient;
    }

    public void setIsclient(String isclient) {
        this.isclient = isclient;
    }

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    public String getInsertedby() {
        return insertedby;
    }

    public void setInsertedby(String insertedby) {
        this.insertedby = insertedby;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifiedby() {
        return modifiedby;
    }

    public void setModifiedby(String modifiedby) {
        this.modifiedby = modifiedby;
    }

    public String getClientstatus() {
        return clientstatus;
    }

    public void setClientstatus(String clientstatus) {
        this.clientstatus = clientstatus;
    }

    public BigInteger getLoginAppempts() {
        return loginAppempts;
    }

    public void setLoginAppempts(BigInteger loginAppempts) {
        this.loginAppempts = loginAppempts;
    }

    public short getAccountlockFlag() {
        return accountlockFlag;
    }

    public void setAccountlockFlag(short accountlockFlag) {
        this.accountlockFlag = accountlockFlag;
    }

    public Date getPasswordModifiedDate() {
        return passwordModifiedDate;
    }

    public void setPasswordModifiedDate(Date passwordModifiedDate) {
        this.passwordModifiedDate = passwordModifiedDate;
    }

    public Date getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(Date lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    @Override
    public String toString() {
        return "com.cms.entity.CmsMClientLoginHistory[ loginId=" + loginId + " ]";
    }
    
}
