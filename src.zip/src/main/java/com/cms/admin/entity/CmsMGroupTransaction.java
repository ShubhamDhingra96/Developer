package com.cms.admin.entity;
	
	import javax.persistence.Basic;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.Id;	
	import javax.persistence.Table;
	

	/**
	 *
	 * @author ritu.kanade
	 */
	@Entity
	@Table(name = "CMS_M_GROUP_TRANSACTION")
	
	public class CmsMGroupTransaction  {

	    @Id
	    @Basic(optional = false)
	    @Column(name = "GROUP_ID")
	    private String groupId;
	    @Column(name = "GROUP_DESCRIPTION")
	    private String groupDescription;
	    @Column(name = "STATUS")
	    private Long status;

	    public CmsMGroupTransaction() {
	    }

	    public CmsMGroupTransaction(String groupId) {
	        this.groupId = groupId;
	    }

	    public String getGroupId() {
	        return groupId;
	    }

	    public void setGroupId(String groupId) {
	        this.groupId = groupId;
	    }

	    public String getGroupDescription() {
	        return groupDescription;
	    }

	    public void setGroupDescription(String groupDescription) {
	        this.groupDescription = groupDescription;
	    }

	    public Long getStatus() {
	        return status;
	    }

	    public void setStatus(Long status) {
	        this.status = status;
	    }

	    @Override
	    public String toString() {
	        return "javaapplication1.CmsMGroupTransaction[ groupId=" + groupId + " ]";
	    }
	    
	}



