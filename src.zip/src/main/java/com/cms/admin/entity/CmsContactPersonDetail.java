package com.cms.admin.entity;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CMS_M_CONTACT_PERSON_DETAIL")
@SequenceGenerator(sequenceName = "CMS_CONTACT_PERSON_SEQ", name = "CMS_CONTACT_PERSON_SEQ", allocationSize = 1)
public class CmsContactPersonDetail {

	@Column(name = "DETAIL_ID")
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_CONTACT_PERSON_SEQ")
	private Long detailId;
	@Column(name = "PERSON_NAME")
	private String personName;
	@Column(name = "PERSON_MAILING_ADDRESS")
	private String personMailingAddress;
	@Column(name = "PERSON_TEL_OFF")
	private String personTelOff;
	@Column(name = "PERSON_TEL_RES")
	private String personTelRes;
	@Column(name = "PERSON_MOBILE")
	private String personMobile;
	@Column(name = "PERSON_FAX")
	private String personFax;
	@Column(name = "PERSON_LOCATION")
	private String personLocation;
	@Column(name = "PERSON_CITY")
	private String personCity;
	@Column(name = "PERSON_STATE")
	private String personState;
	@Column(name = "PERSON_COUNTRY")
	private String personCountry;
	@Column(name = "PERSION_EMAIL")
	private String personEmail;
	@Column(name = "PERSION_POSTALCODE")
	private String personPostalCode;
	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "CLIENT_ID", referencedColumnName = "CMS_CLIENT_ID")
	@ForeignKey(name = "none")
	private CmsClient clientId;
	

	public Long getDetailId() {
		return detailId;
	}

	public void setDetailId(Long detailId) {
		this.detailId = detailId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getPersonMailingAddress() {
		return personMailingAddress;
	}

	public void setPersonMailingAddress(String personMailingAddress) {
		this.personMailingAddress = personMailingAddress;
	}

	public String getPersonTelOff() {
		return personTelOff;
	}

	public void setPersonTelOff(String personTelOff) {
		this.personTelOff = personTelOff;
	}

	public String getPersonTelRes() {
		return personTelRes;
	}

	public void setPersonTelRes(String personTelRes) {
		this.personTelRes = personTelRes;
	}

	public String getPersonMobile() {
		return personMobile;
	}

	public void setPersonMobile(String personMobile) {
		this.personMobile = personMobile;
	}

	public String getPersonFax() {
		return personFax;
	}

	public void setPersonFax(String personFax) {
		this.personFax = personFax;
	}

	public String getPersonLocation() {
		return personLocation;
	}

	public void setPersonLocation(String personLocation) {
		this.personLocation = personLocation;
	}

	public String getPersonCity() {
		return personCity;
	}

	public void setPersonCity(String personCity) {
		this.personCity = personCity;
	}

	public String getPersonState() {
		return personState;
	}

	public void setPersonState(String personState) {
		this.personState = personState;
	}

	public String getPersonCountry() {
		return personCountry;
	}

	public void setPersonCountry(String personCountry) {
		this.personCountry = personCountry;
	}

	public String getPersonEmail() {
		return personEmail;
	}

	public void setPersonEmail(String personEmail) {
		this.personEmail = personEmail;
	}

	public String getPersonPostalCode() {
		return personPostalCode;
	}

	public void setPersonPostalCode(String personPostalCode) {
		this.personPostalCode = personPostalCode;
	}

	public CmsClient getClientId() {
		return clientId;
	}

	public void setClientId(CmsClient clientId) {
		this.clientId = clientId;
	}

}
