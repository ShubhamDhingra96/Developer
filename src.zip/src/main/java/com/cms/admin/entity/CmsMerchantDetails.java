package com.cms.admin.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "CMS_MERCHANT_CATEGORY")
@SequenceGenerator(sequenceName = "MERCHANT_CATEGORY", name = "MERCHANT_CATEGORY", allocationSize = 1)
public class CmsMerchantDetails {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MERCHANT_ID")
	@NotNull
	@Basic(optional = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MERCHANT_CATEGORY")
	private Integer groupId;

	@Column(name = "MERCHANT_GROUP_CODE")
	private String merchantGroupCode;

	@Column(name = "MERCHANT_GROUP_NAME")
	private String merchantGroupName;

	@Column(name = "MERCHANT_GROUP_DESCRIPTION")
	private String merchantGroupDescription;

	@Column(name = "MERCHANT_NETWORK_TYPE")
	private String merchantNetworkType;

	@Column(name = "MERCHANT_MCC_GROUP")
	private String merchantMCCGroup;

	@Column(name = "MERCHANT_MCC_CODE")
	private String merchantMCCCode;

	@Column(name = "INSERTED_DATE")
	private String insertedDate;
	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_DATE")
	private String modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	
	
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	
	public Integer getGroupId() {
		return groupId;
	}

	public String getMerchantGroupCode() {
		return merchantGroupCode;
	}

	public void setMerchantGroupCode(String merchantGroupCode) {
		this.merchantGroupCode = merchantGroupCode;
	}

	public String getMerchantGroupName() {
		return merchantGroupName;
	}

	public void setMerchantGroupName(String merchantGroupName) {
		this.merchantGroupName = merchantGroupName;
	}

	public String getMerchantGroupDescription() {
		return merchantGroupDescription;
	}

	public void setMerchantGroupDescription(String merchantGroupDescription) {
		this.merchantGroupDescription = merchantGroupDescription;
	}

	public String getMerchantNetworkType() {
		return merchantNetworkType;
	}

	public void setMerchantNetworkType(String merchantNetworkType) {
		this.merchantNetworkType = merchantNetworkType;
	}

	public String getMerchantMCCGroup() {
		return merchantMCCGroup;
	}

	public void setMerchantMCCGroup(String merchantMCCGroup) {
		this.merchantMCCGroup = merchantMCCGroup;
	}

	public String getMerchantMCCCode() {
		return merchantMCCCode;
	}

	public void setMerchantMCCCode(String merchantMCCCode) {
		this.merchantMCCCode = merchantMCCCode;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
