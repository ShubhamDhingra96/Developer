
package com.cms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 *
 * @author ritu.kanade
 */
@Entity
@Table(name = "CMS_M_FEE_MANAGEMENT")  
public class CmsFeeManagement {

    
    @Id    
    @Column(name = "FEE_CODE")
    private String feeCode;
    
    @Column(name = "FEE_DESCRIPTION")
    private String feeDescription;
    
    @Column(name = "TRANSACTION")
    private String transaction;
    
    @Column(name = "FREQUENCY")
    private String frequency;
    
    @Column(name = "PER_FLAT")
    private String perFlat;
    
    @Column(name = "PERCENTAGE")
    private String percentage;
    
    @Column(name = "FLAT")
    private String flat;
    
    @Column(name = "LIMIT")
    private String limit;
    
    @Column(name = "MAX_LIMIT")
    private String maxLimit;
    
    @Column(name = "MIN_LIMIT")
    private String minLimit;
    
    @Column(name = "CHARGE_FEE_TO")
    private String chargeFeeTo;
    
    @Column(name = "GROUP_TRANSACTIONS")
    private String groupTransactions;
    
    @Column(name = "CRITERIA")
    private String criteria;
    
    @Column(name = "CRITERIA_FROM")
	private String criteriaFrom;
    
    @Column(name = "CRITERIA_TO")
	private String criteriaTo;
	
    @Column(name = "CREATEDBY")
    private String createdBy;
    
    @Column(name = "CREATEDON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdOn;
    
    @Column(name = "MODIFIEDBY")
    private String modifiedBy;
    
    @Column(name = "MODIFIEDON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedOn;
    
    @Column(name = "COUNTRY_CODE")
    private String countryCode;
    
    @Column(name = "ACQUIRING_NETWORK")
    private String acquiringNetwork;
    
    @Column(name = "ACQUIRING_NETWORK_NAME")
    private String acquiringNetworkName;
    
    @Column(name = "DELIVERY_CHANNELS")
    private String deliveryChannels;
    
    @Column(name = "DELIVERY_CHANNEL_NAME")
    private String deliveryChannelName;
    
    @Column(name = "MERCHANT_ID_GROUP")
    private String merchantIdGroup;
    
    @Column(name = "MERCHANT_ID_GROUP_NAME")
    private String merchantIdGroupName;
    
    @Column(name = "RULE")
    private String rule;
    
    @Column(name = "SEPERATE_LINE")
    private String seperateLine;
    
    @Basic(optional = false)
    @Column(name = "FEE_TYPE")
    private short feeType;

    public CmsFeeManagement() {
    }

    public CmsFeeManagement(String feeCode) {
        this.feeCode = feeCode;
    }

    public CmsFeeManagement(String feeCode, short feeType) {
        this.feeCode = feeCode;
        this.feeType = feeType;
    }

    public String getFeeCode() {
        return feeCode;
    }

    public void setFeeCode(String feeCode) {
        this.feeCode = feeCode;
    }

    public String getFeeDescription() {
        return feeDescription;
    }

    public void setFeeDescription(String feeDescription) {
        this.feeDescription = feeDescription;
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public String getFrequency() {
        return frequency;
    }
    
	public void setFrequency(String frequency) {
        this.frequency = frequency;
    }
    public String getPerFlat() {
			return perFlat;
	}

	public void setPerFlat(String perFlat) {
			this.perFlat = perFlat;
	}
    public String getPercentage() {
        return percentage;
    }

    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }
    
    public String getFlat() {
		return flat;
	}

	public void setFlat(String flat) {
		this.flat = flat;
	}

	public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }
    
    public String getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(String maxLimit) {
		this.maxLimit = maxLimit;
	}

	public String getMinLimit() {
		return minLimit;
	}

	public void setMinLimit(String minLimit) {
		this.minLimit = minLimit;
	}

	public String getChargeFeeTo() {
        return chargeFeeTo;
    }

    public void setChargeFeeTo(String chargeFeeTo) {
        this.chargeFeeTo = chargeFeeTo;
    }

    public String getGroupTransactions() {
        return groupTransactions;
    }

    public void setGroupTransactions(String groupTransactions) {
        this.groupTransactions = groupTransactions;
    }

    public String getCriteria() {
        return criteria;
    }

    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }
    
    public String getCriteriaFrom() {
		return criteriaFrom;
	}

	public void setCriteriaFrom(String criteriaFrom) {
		this.criteriaFrom = criteriaFrom;
	}

	public String getCriteriaTo() {
		return criteriaTo;
	}

	public void setCriteriaTo(String criteriaTo) {
		this.criteriaTo = criteriaTo;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAcquiringNetwork() {
        return acquiringNetwork;
    }

    public void setAcquiringNetwork(String acquiringNetwork) {
        this.acquiringNetwork = acquiringNetwork;
    }
   
    public String getAcquiringNetworkName() {
		return acquiringNetworkName;
	}

	public void setAcquiringNetworkName(String acquiringNetworkName) {
		this.acquiringNetworkName = acquiringNetworkName;
	}

	public String getDeliveryChannels() {
        return deliveryChannels;
    }

    public void setDeliveryChannels(String deliveryChannels) {
        this.deliveryChannels = deliveryChannels;
    }
    
    public String getDeliveryChannelName() {
		return deliveryChannelName;
	}

	public void setDeliveryChannelName(String deliveryChannelName) {
		this.deliveryChannelName = deliveryChannelName;
	}

	public String getMerchantIdGroup() {
        return merchantIdGroup;
    }
  
    public void setMerchantIdGroup(String merchantIdGroup) {
        this.merchantIdGroup = merchantIdGroup;
    }
    
    public String getMerchantIdGroupName() {
		return merchantIdGroupName;
	}

	public void setMerchantIdGroupName(String merchantIdGroupName) {
		this.merchantIdGroupName = merchantIdGroupName;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}
    
	public String getSeperateLine() {
		return seperateLine;
	}

	public void setSeperateLine(String seperateLine) {
		this.seperateLine = seperateLine;
	}

	public short getFeeType() {
        return feeType;
    }

    public void setFeeType(short feeType) {
        this.feeType = feeType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (feeCode != null ? feeCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CmsFeeManagement)) {
            return false;
        }
        CmsFeeManagement other = (CmsFeeManagement) object;
        if ((this.feeCode == null && other.feeCode != null) || (this.feeCode != null && !this.feeCode.equals(other.feeCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "javaapplication1.CmsMFeeManagement[ feeCode=" + feeCode + " ]";
    }
    
}
