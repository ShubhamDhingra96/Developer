package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.Generated;

@Entity
@Table(name = "CMS_M_BIN")
public class CmsBin {

	@Id
	@SequenceGenerator(name = "cms_cms_bin_gen", sequenceName = "CMS_M_BIN_SEQ",allocationSize = 1)
	@GeneratedValue(generator = "cms_cms_bin_gen",strategy = GenerationType.SEQUENCE)
	@Column(name="BIN_ID")
	private Integer binId;
	
	@Column(name = "BIN_NUMBER")
	private String binNumber;
	@Column(name = "BIN_DESCRIPTION")
	private String binDiscription;
	@Column(name = "BIN_CURRENCY")
	private String binCurrency;
	@Column(name = "SETTLEMENT_CURRENCY")
	private String settlementCurrency;
	@Column(name = "BIN_TYPE")
	private String binType;
	@Column(name = "BIN_DIGIT")
	private String binDigit;
	@Column(name = "BIN_ISSUER")
	private String binIssuer;
	@Column(name = "BIN_STATUS")
	private Integer binStatus;
	@Column(name = "CHECK_PARITY")
	private String checkParity;
	@Column(name = "BINRANGE_FROM")
	private String binrangeFrom;
	@Column(name = "BINRANGE_TO")
	private String binrangeTo;
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name = "CMS_CLIENT_ID")
	private String clientID;
	
	public Number getBinId() {
		return binId;
	}

	

	public String getBinNumber() {
		return binNumber;
	}



	public void setBinId(Integer binId) {
		this.binId = binId;
	}



	public void setBinNumber(String binNumber) {
		this.binNumber = binNumber;
	}

	public String getBinDiscription() {
		return binDiscription;
	}

	public void setBinDiscription(String binDiscription) {
		this.binDiscription = binDiscription;
	}

	public String getBinCurrency() {
		return binCurrency;
	}

	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}

	public String getSettlementCurrency() {
		return settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public String getBinType() {
		return binType;
	}

	public void setBinType(String binType) {
		this.binType = binType;
	}

	public String getBinDigit() {
		return binDigit;
	}

	public void setBinDigit(String binDigit) {
		this.binDigit = binDigit;
	}

	public String getBinIssuer() {
		return binIssuer;
	}

	public void setBinIssuer(String binIssuer) {
		this.binIssuer = binIssuer;
	}

	

	public Integer getBinStatus() {
		return binStatus;
	}



	public void setBinStatus(Integer binStatus) {
		this.binStatus = binStatus;
	}



	public String getCheckParity() {
		return checkParity;
	}

	public void setCheckParity(String checkParity) {
		this.checkParity = checkParity;
	}

	public String getBinrangeFrom() {
		return binrangeFrom;
	}

	public void setBinrangeFrom(String binrangeFrom) {
		this.binrangeFrom = binrangeFrom;
	}

	public String getBinrangeTo() {
		return binrangeTo;
	}

	public void setBinrangeTo(String binrangeTo) {
		this.binrangeTo = binrangeTo;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

//	public CmsClientLogin getInsertedBy() {
//		return insertedBy;
//	}
//
//	public void setInsertedBy(CmsClientLogin insertedBy) {
//		this.insertedBy = insertedBy;
//	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getClientID() {
		return clientID;
	}

    public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	
	

//	public CmsClientLogin getModifiedBy() {
//		return modifiedBy;
//	}
//
//	public void setModifiedBy(CmsClientLogin modifiedBy) {
//		this.modifiedBy = modifiedBy;
//	}

}
