/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sahadeo.naik
 */
@Entity
@Table(name = "LOG_CMS_EXCEPTION")
@SequenceGenerator(sequenceName = "LOG_CMS_EXCEPTION_SEQ", name = "LOG_CMS_EXCEPTION_SEQ", allocationSize = 1)
public class LogCmsException implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "LOG_CMS_EXCEPTION_SEQ")
    @Column(name = "EXCEPTION_LOG_ID")
    private Integer exceptionLogId;
    @Column(name = "ERROR_CODE")
    private String errorCode;
    @Lob
    @Column(name = "ROOT_CAUSE")
    private String rootCause;
    @Size(max = 100)
    @Column(name = "ERROR_MESSAGE")
    private String errorMessage;
    @Size(max = 50)
    @Column(name = "USER_ID")
    private String userId;
    @Size(max = 50)
    @Column(name = "T_TRANSACTION_ID")
    private String tTransactionId;
    @Lob
    @Column(name = "EXCEPTION_REQUEST")
    private String exceptionRequest;
    @Lob
    @Column(name = "EXCEPTION_RESPONSE")
    private String exceptionResponse;
    @Column(name = "INSERTED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertedDate;

    public LogCmsException() {
    }

    public LogCmsException(Integer exceptionLogId) {
        this.exceptionLogId = exceptionLogId;
    }

    public Integer getExceptionLogId() {
        return exceptionLogId;
    }

    public void setExceptionLogId(Integer exceptionLogId) {
        this.exceptionLogId = exceptionLogId;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getRootCause() {
        return rootCause;
    }

    public void setRootCause(String rootCause) {
        this.rootCause = rootCause;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTTransactionId() {
        return tTransactionId;
    }

    public void setTTransactionId(String tTransactionId) {
        this.tTransactionId = tTransactionId;
    }

    public String getExceptionRequest() {
        return exceptionRequest;
    }

    public void setExceptionRequest(String exceptionRequest) {
        this.exceptionRequest = exceptionRequest;
    }

    public String getExceptionResponse() {
        return exceptionResponse;
    }

    public void setExceptionResponse(String exceptionResponse) {
        this.exceptionResponse = exceptionResponse;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (exceptionLogId != null ? exceptionLogId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LogCmsException)) {
            return false;
        }
        LogCmsException other = (LogCmsException) object;
        if ((this.exceptionLogId == null && other.exceptionLogId != null) || (this.exceptionLogId != null && !this.exceptionLogId.equals(other.exceptionLogId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.cms.entity.LogCmsException[ exceptionLogId=" + exceptionLogId + " ]";
    }
    
}
