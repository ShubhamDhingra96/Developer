package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CMS_M_CARD_USAGE")
@SequenceGenerator(sequenceName = "CMS_CARD_USAGE_SEQ", name = "CMS_CARD_USAGE_SEQ", allocationSize = 1)
public class CmsCardUsage {

	    
	    @Id
	    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_CARD_USAGE_SEQ")
	    @Column(name = "GROUP_ID")
	    private Integer groupId;
	
	
	    @Column(name="GROUP_CODE")
	    private String groupCode;
	    
	    @Column(name="GROUP_NAME")
	    private String groupName;
	    
	    @Column(name="GROUP_DESC")
	    private String groupDesc;
		
	    @Column(name="TRANSACTION_AMT")
		private String transactionAmount;
		
	    @Column(name="STATUS")
		private int status;
	    
	    @Column(name="INSERTEDBY")
		private String insertedBy;
	    
	    @Column(name="INSERTEDON")
		private Date insertedOn; 
	    
	    @Column(name="MODIFIEDBY")
		private String modifyBy;
	    
	    @Column(name="MODIFIEDON")
		private Date modifyOn;

		

		public String getGroupCode() {
			return groupCode;
		}

		public void setGroupCode(String groupCode) {
			this.groupCode = groupCode;
		}

		public String getGroupName() {
			return groupName;
		}

		public void setGroupName(String groupName) {
			this.groupName = groupName;
		}

		public String getGroupDesc() {
			return groupDesc;
		}

		public void setGroupDesc(String groupDesc) {
			this.groupDesc = groupDesc;
		}

		public String getTransactionAmount() {
			return transactionAmount;
		}

		public void setTransactionAmount(String transactionAmount) {
			this.transactionAmount = transactionAmount;
		}

		public int getStatus() {
			return status;
		}

		public void setStatus(int status) {
			this.status = status;
		}

		public String getInsertedBy() {
			return insertedBy;
		}

		public void setInsertedBy(String insertedBy) {
			this.insertedBy = insertedBy;
		}

		public Date getInsertedOn() {
			return insertedOn;
		}

		public void setInsertedOn(Date insertedOn) {
			this.insertedOn = insertedOn;
		}

		public String getModifyBy() {
			return modifyBy;
		}

		public void setModifyBy(String modifyBy) {
			this.modifyBy = modifyBy;
		}

		public Date getModifyOn() {
			return modifyOn;
		}

		public Integer getGroupId() {
			return groupId;
		}

		public void setGroupId(Integer groupId) {
			this.groupId = groupId;
		}

		public void setModifyOn(Date modifyOn) {
			this.modifyOn = modifyOn;
		}

		
		
}
