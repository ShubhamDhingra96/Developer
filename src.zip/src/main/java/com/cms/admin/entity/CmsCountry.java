package com.cms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "COUNTRIES")
public class CmsCountry {
	
	@Id
	@Column(name = "COUNTRY_ID")
	private Long countryId;

	@Column(name = "SHORT_COUNTRY_NAME")
	private String shortCountryName;

	@Column(name = "COUNTRY_NAME")
	private String countryName;	
	
	@Column(name = "PHONE_CODE")
	private Long phoneCode;
	
	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getShortCountryName() {
		return shortCountryName;
	}

	public void setShortCountryName(String shortCountryName) {
		this.shortCountryName = shortCountryName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Long getPhoneCode() {
		return phoneCode;
	}

	public void setPhoneCode(Long phoneCode) {
		this.phoneCode = phoneCode;
	}

	


}
