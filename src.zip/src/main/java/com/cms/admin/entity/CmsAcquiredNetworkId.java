package com.cms.admin.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_ACQUIRED_NETWORK_ID")
public class CmsAcquiredNetworkId {

	@Id
	@Column(name = "NETWORK_ID")
	private String networkId;
	@Column(name = "NETWORK_NAME")
	private String networkName;
	@Column(name = "NETWORK_DESCRIPTION")
	private String networkDescription;
	@Column(name = "ACQUIRED_NETWORK_GROUP_ID")
	private String networkGroupId;
	@Column(name = "INSERTED_DATE")
	private String insertedDate;
	@Column(name = "INSERTED_BY")
	private String insertedBy;
	@Column(name = "MODIFIED_DATE")
	private String modifiedDate;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@OneToMany(mappedBy = "acquiredNetworkId",fetch = FetchType.EAGER)
	private List<CmsCountryCode> countryCode;
	
	
	public void setCountryCode(List<CmsCountryCode> countryCode) {
		this.countryCode = countryCode;
	}
	
	public List<CmsCountryCode> getCountryCode() {
		return countryCode;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getNetworkName() {
		return networkName;
	}

	public void setNetworkName(String networkName) {
		this.networkName = networkName;
	}

	public String getNetworkDescription() {
		return networkDescription;
	}

	public void setNetworkDescription(String networkDescription) {
		this.networkDescription = networkDescription;
	}

	public String getNetworkGroupId() {
		return networkGroupId;
	}

	public void setNetworkGroupId(String networkGroupId) {
		this.networkGroupId = networkGroupId;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
