package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CMS_M_PRIVILEDGES")
public class CmsPreviliges {

	@Id
	@Column(name = "P_ID")
	private String permissionId;
	@Column(name = "P_NAME")
	private String permissionName;
	@Column(name = "P_DESCRIPTION")
	private String permissionDesc;
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;
	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "INSERTED_BY", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
	private CmsClientLogin insertedBy;
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "MODIFIED_BY", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
	private CmsClientLogin modifiedBy;

	public String getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(String permissionId) {
		this.permissionId = permissionId;
	}

	public String getPermissionDesc() {
		return permissionDesc;
	}

	public void setPermissionDesc(String permissionDesc) {
		this.permissionDesc = permissionDesc;
	}

	public String getPermissionName() {
		return permissionName;
	}

	public void setPermissionName(String permissionName) {
		this.permissionName = permissionName;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public CmsClientLogin getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(CmsClientLogin insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CmsClientLogin getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(CmsClientLogin modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
