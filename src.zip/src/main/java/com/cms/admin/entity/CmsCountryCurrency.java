package com.cms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="CMS_M_COUNTRY")
public class CmsCountryCurrency {
	
	@Id
	@Column(name="COUNTRY_CURRENCY")
	private String countryCurrency;
	@Column(name="COUNTRY_CURRENCY_DESC")
	private String countryCurrencyDesc;
	@Column(name="COUTRY_NAME")
	private String countryName;
	@Column(name="INSERTED_DATE")
	private String insertedDate;
	@Column(name="INSERTED_BY")
	private String insertedBy;
	@Column(name="MODIFIED_DATE")
	private String modifiedDate;
	@Column(name="MODIFIED_BY")
	private String modifiedBy;
	
	public String getCountryCurrency() {
		return countryCurrency;
	}
	public void setCountryCurrency(String countryCurrency) {
		this.countryCurrency = countryCurrency;
	}
	public String getCountryCurrencyDesc() {
		return countryCurrencyDesc;
	}
	public void setCountryCurrencyDesc(String countryCurrencyDesc) {
		this.countryCurrencyDesc = countryCurrencyDesc;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public String getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}
	public String getInsertedBy() {
		return insertedBy;
	}
	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	

}
