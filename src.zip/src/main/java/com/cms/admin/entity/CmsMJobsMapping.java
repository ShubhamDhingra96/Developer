/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanket.more
 */
@Entity
@Table(name = "CMS_M_JOBS_MAPPING")
public class CmsMJobsMapping  {
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "JOB_MAPPING_ID")
    private String jobMappingId;
    @Size(max = 20)
    @Column(name = "INSERTED_BY")
    private String insertedBy;
    @Size(max = 20)
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "INSERTED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertedDate;
    @Column(name = "MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    //@JoinColumn(name = "FUNCTION_ID", referencedColumnName = "CMS_M_FUNCTION_ID")
   // @ManyToOne   
    @Column(name = "FUNCTION_ID")
    //private CmsMFunctions cmsMFunctions;
    private String cmsMFunctions;
    @JoinColumn(name = "JOB_ID", referencedColumnName = "JOB_ID")   
    @ManyToOne
    private CmsMJobs cmsMJobs;
    
    private String JOB_URL;
    
    public void setJOB_URL(String jOB_URL) {
		JOB_URL = jOB_URL;
	}
    
    public String getJOB_URL() {
		return JOB_URL;
	}

    public CmsMJobsMapping() {
    }

    public CmsMJobsMapping(String jobMappingId) {
        this.jobMappingId = jobMappingId;
    }

    public String getJobMappingId() {
        return jobMappingId;
    }

    public void setJobMappingId(String jobMappingId) {
        this.jobMappingId = jobMappingId;
    }

    public String getInsertedBy() {
        return insertedBy;
    }

    public void setInsertedBy(String insertedBy) {
        this.insertedBy = insertedBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    
    public String getCmsMFunctions() {
		return cmsMFunctions;
	}

	public void setCmsMFunctions(String cmsMFunctions) {
		this.cmsMFunctions = cmsMFunctions;
	}

	public CmsMJobs getCmsMJobs() {
        return cmsMJobs;
    }

    public void setCmsMJobs(CmsMJobs cmsMJobs) {
        this.cmsMJobs = cmsMJobs;
    }

    
	@Override
	public String toString() {
		return "CmsMJobsMapping [jobMappingId=" + jobMappingId + ", insertedBy=" + insertedBy + ", modifiedBy="
				+ modifiedBy + ", insertedDate=" + insertedDate + ", modifiedDate=" + modifiedDate + ", cmsMFunctions="
				+ cmsMFunctions + ", cmsMJobs=" + cmsMJobs + "]";
	}

   
    
}
