package com.cms.admin.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_ACQUIRED_NETWORK_TYPE")
public class CmsNetworkType {

	@Id
	@Column(name = "ACUIRED_NETWORK_GROUP_ID")
	private String acquiredNetworkGroupId;
	@Column(name = "ACQUIRED_NETWORK_NAME")
	private String acquiredNetworkGroupName;
	@Column(name = "ACQUIRED_NETWORK_DESCRIPTION")
	private String acquiredNetworkGroupDescription;
	@Column(name = "INSERTED_DATE")
	private String insertedDate;
	@Column(name = "INSERTED_BY")
	private String insertedBy;
	@Column(name = "MODIFIED_DATE")
	private String modifiedDate;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@OneToMany(mappedBy = "networkGroupId", fetch = FetchType.EAGER)
	private List<CmsAcquiredNetworkId> networkId;

	public void setNetworkId(List<CmsAcquiredNetworkId> networkId) {
		this.networkId = networkId;
	}

	public List<CmsAcquiredNetworkId> getNetworkId() {
		return networkId;
	}

	public String getAcquiredNetworkGroupId() {
		return acquiredNetworkGroupId;
	}

	public void setAcquiredNetworkGroupId(String acquiredNetworkGroupId) {
		this.acquiredNetworkGroupId = acquiredNetworkGroupId;
	}

	public String getAcquiredNetworkGroupName() {
		return acquiredNetworkGroupName;
	}

	public void setAcquiredNetworkGroupName(String acquiredNetworkGroupName) {
		this.acquiredNetworkGroupName = acquiredNetworkGroupName;
	}

	public String getAcquiredNetworkGroupDescription() {
		return acquiredNetworkGroupDescription;
	}

	public void setAcquiredNetworkGroupDescription(String acquiredNetworkGroupDescription) {
		this.acquiredNetworkGroupDescription = acquiredNetworkGroupDescription;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
