package com.cms.admin.entity;

import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_MERCHANT_MCC_GROUP")
public class CmsMerchantMccGroup {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "MCC_GROUP_ID")
	@Basic(optional = false)
	private Integer groupId;

	@Column(name = "MCC_CODE_NAME")
	private String mccCodeName;


	@Column(name = "MCC_CODE_DESCRIPTION")
	private String mccCodeDescription;

	@Column(name = "INSERTED_DATE")
	private String insertedDate;
	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_DATE")
	private String modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;
	
	@OneToMany(mappedBy = "mccGroupCodeId", fetch = FetchType.EAGER)
	private List<CmsMccGroupCode> groupCode;
	
	
	public void setGroupCode(List<CmsMccGroupCode> groupCode) {
		this.groupCode = groupCode;
	}
	
	public List<CmsMccGroupCode> getGroupCode() {
		return groupCode;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getMccCodeName() {
		return mccCodeName;
	}

	public void setMccCodeName(String mccCodeName) {
		this.mccCodeName = mccCodeName;
	}

	public String getMccCodeDescription() {
		return mccCodeDescription;
	}

	public void setMccCodeDescription(String mccCodeDescription) {
		this.mccCodeDescription = mccCodeDescription;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	

}
