package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_M_DEL_CHNL_GROUP")
@SequenceGenerator(sequenceName = "CMS_DELIVERY_GROUP_SEQ", name = "CMS_DELIVERY_GROUP_SEQ", allocationSize = 1)
public class CmsDeliveryChannelGroup {

	@Id
	@Column(name = "GROUP_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_DELIVERY_GROUP_SEQ")
	private Integer groupId;

	@Column(name = "GROUP_CODE")
	private String groupCode;
	
	@Column(name = "GROUP_NAME")
	private String groupName;

	@Column(name = "GROUP_DESCRIPTION")
	private String groupDescription;

	@Column(name = "DELIVERY_CHANNEL")
	private String deliveryChannel;

	@Column(name = "TRANSATION_CHANNEL")
	private String transactionChannel;
	
	@Column(name="INSERTED_BY")
	private String insertedBy;
	
	@Column(name="MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name="INSERTED_DATE")
	private Date insertedDate;
	
	@Column(name="MODIFIED_DATE")
	private Date modifiedDate;
	
	
	

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}

	public String getDeliveryChannel() {
		return deliveryChannel;
	}

	public void setDeliveryChannel(String deliveryChannel) {
		this.deliveryChannel = deliveryChannel;
	}

	public String getTransactionChannel() {
		return transactionChannel;
	}

	public void setTransactionChannel(String transactionChannel) {
		this.transactionChannel = transactionChannel;
	}
	
	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}
	
	public String getGroupCode() {
		return groupCode;
	}

}
