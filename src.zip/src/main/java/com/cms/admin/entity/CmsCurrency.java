package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_M_CURRENCY")
public class CmsCurrency {

	
	@Id
	@Column(name = "CURRENCY_ID")
	private Long currencyId;
	
	@Column(name = "COUNTRY")
	private String countryName;

	@Column(name = "CURRENCY")
	private String currencyName;
	
	@Column(name = "CODE")
	private String code;
	
	@Column(name = "CURRENCY_NUMBER")
	private String currencyNumber;
	
	@Column(name = "CURRENCY_CODE")
	private String currencyCode;
	
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;
	
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCurrencyName() {
		return currencyName;
	}

	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCurrencyNumber() {
		return currencyNumber;
	}

	public void setCurrencyNumber(String currencyNumber) {
		this.currencyNumber = currencyNumber;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	
}
