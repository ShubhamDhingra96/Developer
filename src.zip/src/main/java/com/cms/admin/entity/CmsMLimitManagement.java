package com.cms.admin.entity;


import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sahadeo.naik
 */
@Entity
@Table(name = "CMS_M_LIMIT_MANAGEMENT")
@NamedQueries({
    @NamedQuery(name = "CmsMLimitManagement.findAll", query = "SELECT c FROM CmsMLimitManagement c")})
public class CmsMLimitManagement implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "LIMIT_CODE")
    private String limitCode;
    @Size(max = 100)
    @Column(name = "LIMIT_NAME")
    private String limitName;
    @Size(max = 100)
    @Column(name = "COUNTRY_CODE")
    private String countryCode;
    @Size(max = 100)
    @Column(name = "ACQUIRING_NETWORK")
    private String acquiringNetwork;
    @Size(max = 100)
    @Column(name = "DELIVERY_CHANNELS")
    private String deliveryChannels;
    @Size(max = 100)
    @Column(name = "TRANSACTION")
    private String transaction;
    @Size(max = 100)
    @Column(name = "FREQUENCY")
    private String frequency;
    @Size(max = 100)
    @Column(name = "LEVEL_CHECK")
    private String levelCheck;
    @Size(max = 100)
    @Column(name = "MAX_COUNT")
    private String maxCount;
    @Size(max = 100)
    @Column(name = "CURRENCY")
    private String currency;
    @Size(max = 100)
    @Column(name = "MIN_AMOUNT")
    private String minAmount;
    @Size(max = 100)
    @Column(name = "MAX_AMOUNT")
    private String maxAmount;
    @Size(max = 100)
    @Column(name = "CREATEDBY")
    private String createdby;
    @Column(name = "CREATEDON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdon;
    @Size(max = 100)
    @Column(name = "MODIFIEDBY")
    private String modifiedby;
    @Column(name = "MODIFIEDON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedon;
    @Basic(optional = false)
    @NotNull
    @Column(name = "LIMIT_TYPE")
    private short limitType;

    public CmsMLimitManagement() {
    }

    public CmsMLimitManagement(String limitCode) {
        this.limitCode = limitCode;
    }

    public CmsMLimitManagement(String limitCode, short limitType) {
        this.limitCode = limitCode;
        this.limitType = limitType;
    }

    public String getLimitCode() {
        return limitCode;
    }

    public void setLimitCode(String limitCode) {
        this.limitCode = limitCode;
    }

    public String getLimitName() {
        return limitName;
    }

    public void setLimitName(String limitName) {
        this.limitName = limitName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getAcquiringNetwork() {
        return acquiringNetwork;
    }

    public void setAcquiringNetwork(String acquiringNetwork) {
        this.acquiringNetwork = acquiringNetwork;
    }

    public String getDeliveryChannels() {
        return deliveryChannels;
    }

    public void setDeliveryChannels(String deliveryChannels) {
        this.deliveryChannels = deliveryChannels;
    }

    public String getTransaction() {
        return transaction;
    }

    public void setTransaction(String transaction) {
        this.transaction = transaction;
    }

    public String getFrequency() {
        return frequency;
    }

    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    public String getLevelCheck() {
        return levelCheck;
    }

    public void setLevelCheck(String levelCheck) {
        this.levelCheck = levelCheck;
    }

    public String getMaxCount() {
        return maxCount;
    }

    public void setMaxCount(String maxCount) {
        this.maxCount = maxCount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(String minAmount) {
        this.minAmount = minAmount;
    }

    public String getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(String maxAmount) {
        this.maxAmount = maxAmount;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public Date getCreatedon() {
        return createdon;
    }

    public void setCreatedon(Date createdon) {
        this.createdon = createdon;
    }

    public String getModifiedby() {
        return modifiedby;
    }

    public void setModifiedby(String modifiedby) {
        this.modifiedby = modifiedby;
    }

    public Date getModifiedon() {
        return modifiedon;
    }

    public void setModifiedon(Date modifiedon) {
        this.modifiedon = modifiedon;
    }

    public short getLimitType() {
        return limitType;
    }

    public void setLimitType(short limitType) {
        this.limitType = limitType;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (limitCode != null ? limitCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CmsMLimitManagement)) {
            return false;
        }
        CmsMLimitManagement other = (CmsMLimitManagement) object;
        if ((this.limitCode == null && other.limitCode != null) || (this.limitCode != null && !this.limitCode.equals(other.limitCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.cms.entity.CmsMLimitManagement[ limitCode=" + limitCode + " ]";
    }
    
}
