package com.cms.admin.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "COUNTRIES")
public class CmsCountries implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1913399117267489867L;

	@Id
	@Column(name = "COUNTRY_ID")
	private Long countryId;

	@Column(name = "SHORT_COUNTRY_NAME")
	private String shortCountryName;

	@Column(name = "COUNTRY_NAME")
	private String countryName;

	@Column(name = "PHONE_CODE")
	private Long phoneCode;
	
	@OneToMany(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
	@JoinColumn(name="COUNTRY_ID",referencedColumnName = "COUNTRY_ID")
	@ForeignKey(name="none")
	private List<CmsStates> states;
	
	
	

	public List<CmsStates> getStates() {
		return states;
	}

	public void setStates(List<CmsStates> states) {
		this.states = states;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getShortCountryName() {
		return shortCountryName;
	}

	public void setShortCountryName(String shortCountryName) {
		this.shortCountryName = shortCountryName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Long getPhoneCode() {
		return phoneCode;
	}

	public void setPhoneCode(Long phoneCode) {
		this.phoneCode = phoneCode;
	}

}
