package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_M_USAGES_TRANSCTION")
public class CmsUsageTransaction {

	@Id
	@Column(name = "TRANS_ID")
	private Long transId;

	@Column(name = "TRANS_GROUP_CODE")
	private String transGroupCode;

	@Column(name = "TRANS_GROUP_NAME")
	private String transGroupName;

	@Column(name = "TRANS_GROUP_DESC")
	private String transGroupDesc;

	@Column(name = "TRANS_DELIVERY_CHANNEL")
	private String transDeliveryChannel;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "STATUS")
	private char status;

	public Long getTransId() {
		return transId;
	}

	public void setTransId(Long transId) {
		this.transId = transId;
	}

	public String getTransGroupCode() {
		return transGroupCode;
	}

	public void setTransGroupCode(String transGroupCode) {
		this.transGroupCode = transGroupCode;
	}

	public String getTransGroupName() {
		return transGroupName;
	}

	public void setTransGroupName(String transGroupName) {
		this.transGroupName = transGroupName;
	}

	public String getTransGroupDesc() {
		return transGroupDesc;
	}

	public void setTransGroupDesc(String transGroupDesc) {
		this.transGroupDesc = transGroupDesc;
	}

	public String getTransDeliveryChannel() {
		return transDeliveryChannel;
	}

	public void setTransDeliveryChannel(String transDeliveryChannel) {
		this.transDeliveryChannel = transDeliveryChannel;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

}
