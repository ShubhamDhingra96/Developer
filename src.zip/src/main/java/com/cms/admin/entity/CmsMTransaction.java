package com.cms.admin.entity;

	import java.io.Serializable;
	import java.math.BigDecimal;
	import java.math.BigInteger;
	import javax.persistence.Basic;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.NamedQueries;
	import javax.persistence.NamedQuery;
	import javax.persistence.Table;
	import javax.validation.constraints.NotNull;
	import javax.validation.constraints.Size;

	/**
	 *
	 * @author sahadeo.naik
	 */
	@Entity
	@Table(name = "CMS_M_TRANSACTION")
	public class CmsMTransaction implements Serializable {

	    private static final long serialVersionUID = 1L;
	    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
	    @Id
	    @Basic(optional = false)
	    @NotNull
	    @Column(name = "TXN_ID")
	    private String txnId;
	    @Size(max = 100)
	    @Column(name = "TXN_DESCRIPTION")
	    private String txnDescription;
	    @Column(name = "STATUS")
	    private Long status;

	    public CmsMTransaction() {
	    }

	    public CmsMTransaction(String txnId) {
	        this.txnId = txnId;
	    }

	    public String getTxnId() {
	        return txnId;
	    }

	    public void setTxnId(String txnId) {
	        this.txnId = txnId;
	    }

	    public String getTxnDescription() {
	        return txnDescription;
	    }

	    public void setTxnDescription(String txnDescription) {
	        this.txnDescription = txnDescription;
	    }

	    public Long getStatus() {
	        return status;
	    }

	    public void setStatus(Long status) {
	        this.status = status;
	    }

	    @Override
	    public String toString() {
	        return "com.cms.entity.CmsMTransaction[ txnId=" + txnId + " ]";
	    }

}
