package com.cms.admin.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "STATES")
public class CmsStates {
	@Id
	@Column(name = "STATE_ID")
	private Long stateId;

	@Column(name = "STATE_NAME")
	private String stateName;

//	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
//	@JoinColumn(name = "COUNTRY_ID", referencedColumnName = "COUNTRY_ID")
//	@ForeignKey(name = "none")
	@Column(name="COUNTRY_ID")
	private Long  countryId;

	@OneToMany(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "STATE_ID", referencedColumnName = "STATE_ID")
	@ForeignKey(name = "none")
	private List<CmsCities> cities;

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public List<CmsCities> getCities() {
		return cities;
	}

	public void setCities(List<CmsCities> cities) {
		this.cities = cities;
	}

}
