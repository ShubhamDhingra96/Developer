package com.cms.admin.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;


@Table(name="CMS_M_BIN_CLIENT")
public class CmsBinClient {

	@ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
	@JoinColumn(name="CLIENT_ID",referencedColumnName = "CLIENT_ID")
	@ForeignKey(name = "none")
	private CmsClient clientId;
	
	@ManyToOne(fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
	@JoinColumn(name="BIN_ID",referencedColumnName = "BIN_ID")
	@ForeignKey(name = "none")
	private CmsBin binId;
	
	@Column(name="BIN_STATUS")
	private String binStatus;
	
	@Column(name="BIN_START_RANGE")
	private String binStartRange;
	
	@Column(name="BIN_END_RANGE")
	private String  binEndRange;

	public CmsClient getClientId() {
		return clientId;
	}

	public void setClientId(CmsClient clientId) {
		this.clientId = clientId;
	}

	public CmsBin getBinId() {
		return binId;
	}

	public void setBinId(CmsBin binId) {
		this.binId = binId;
	}

	public String getBinStatus() {
		return binStatus;
	}

	public void setBinStatus(String binStatus) {
		this.binStatus = binStatus;
	}

	public String getBinStartRange() {
		return binStartRange;
	}

	public void setBinStartRange(String binStartRange) {
		this.binStartRange = binStartRange;
	}

	public String getBinEndRange() {
		return binEndRange;
	}

	public void setBinEndRange(String binEndRange) {
		this.binEndRange = binEndRange;
	}

	
}
