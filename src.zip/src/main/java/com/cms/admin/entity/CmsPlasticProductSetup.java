package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_M_PLASTICSETUP")
public class CmsPlasticProductSetup {

	@Id
	@SequenceGenerator(name = "cms_cms_group_gen", sequenceName = "CMS_M_PLASTICSETUP_SEQ",allocationSize = 1)
	@GeneratedValue(generator = "cms_cms_group_gen",strategy = GenerationType.SEQUENCE)
	@Column(name="PLASTIC_SETUP_ID")
	private Integer plasticSetupId;

	@Column(name = "PLASTIC_CODE")
	private String plasticCode;

	@Column(name = "SERVICE_CODE")
	private Integer serviceCode;

	@Column(name = "PLASTIC_DESCRIPTION")
	private String plasticDescription;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	
	@Column(name = "CMS_CLIENT_ID")
	private String clientID;
	
	public Integer getPlasticSetupId() {
		return plasticSetupId;
	}

	public String getPlasticCode() {
		return plasticCode;
	}

	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public void setPlasticSetupId(Integer plasticSetupId) {
		this.plasticSetupId = plasticSetupId;
	}

	public Integer getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(Integer serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getPlasticDescription() {
		return plasticDescription;
	}

	public void setPlasticDescription(String plasticDescription) {
		this.plasticDescription = plasticDescription;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
}
