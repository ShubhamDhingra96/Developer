package com.cms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_PRODUCT_TYPE_DEFINATION")
@SequenceGenerator(sequenceName = "CMS_PRODUCT_GROUP", name = "CMS_PRODUCT_GROUP", allocationSize = 1)
public class ProductTypeDefinition {

	@Id
	@Column(name = "PRODUCT_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_PRODUCT_GROUP")
	private Long productId;
	@Column(name = "PRODUCT_CODE")
	private String productCode;
	@Column(name = "PRODUCT_NAME")
	private String productName;
	@Column(name = "PRODUCT_DESCRIPTION")
	private String productDescription;
	@Column(name = "PRODUCT_PAIRCARDS")
	private String productPairCards;
	@Column(name = "APPLICATION_TYPE")
	private String applicationType;
	@Column(name = "PRODUCT_PROGRAM_ID")
	private String productProgram;
	@Column(name = "PROGRAM_CODE")
	private String programCode;
	@Column(name = "PROGRAM_DESCRIPTION")
	private String productProgramDescription;
	@Column(name = "PRODUCT_CURRENCY")
	private String productCurrency;
	@Column(name = "CURRENCY_DESCRIPTION")
	private String productCurrencyDescription;
	@Column(name = "SERVICE_CODE")
	private String serviceCode;
	@Column(name = "PINTRY_LIMIT")
	private String pintryLimit;
	@Column(name = "CARDGENERATION_METHOD")
	private String cardGenerationMethod;
	@Column(name = "CARDEMBOSSING_ENCODING")
	private String cardEmbossingEncode;
	@Column(name = "PINDELIVERY_METHOD")
	private String pinDeliveryMethod;
	@Column(name = "CARDEXPIRY_METHOD")
	private String cardExpiryMethod;
	@Column(name = "EXPIRY_PERIOD")
	private String expiryPeriod;
	@Column(name = "EXPIRY_PERIODMONTHS")
	private String expiryPeriodMonths;
	@Column(name = "EMBOSSING_TEMPLATEID")
	private String embossingTemplate;
	@Column(name = "REPLACEMENT_TEMPLATEID")
	private String replacementTemplate;
	@Column(name = "WELCOME_PACK_TEMPLATE")
	private String welcomeTemplate;
	@Column(name = "DELIVERY_METHOD")
	private String deliveryMethod;
	@Column(name = "ISSUING_CURRENCY_COUNTRY")
	private String issuingCurrency;
	@Column(name = "CARD_ACTIVATION_GROUP")
	private String cardActivationGroup;
	@Column(name = "BIN_GROUP")
	private String binGroup;
	@Column(name = "BINGROUP_DESCRIPTION")
	private String binGroupDescription;
	@Column(name = "BIN_CURRENCY")
	private String binCurrency;
	@Column(name = "BIN_RANGE_FROM")
	private String binRangeFrom;
	@Column(name = "BIN_RANGE_TO")
	private String binRangeTo;
	@Column(name = "PLASTIC_CODE")
	private String plasticCode;
	@Column(name = "INSERTED_DATE")
	private String inertedDate;
	@Column(name = "INSERTED_BY")
	private String insertedBy;
	@Column(name = "MODIFIED_DATE")
	private String modifiedDate;
	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	
	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getBinGroupDescription() {
		return binGroupDescription;
	}

	public void setBinGroupDescription(String binGroupDescription) {
		this.binGroupDescription = binGroupDescription;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductPairCards() {
		return productPairCards;
	}

	public void setProductPairCards(String productPairCards) {
		this.productPairCards = productPairCards;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getProductProgram() {
		return productProgram;
	}

	public void setProductProgram(String productProgram) {
		this.productProgram = productProgram;
	}

	public String getProductProgramDescription() {
		return productProgramDescription;
	}

	public void setProductProgramDescription(String productProgramDescription) {
		this.productProgramDescription = productProgramDescription;
	}

	public String getProductCurrency() {
		return productCurrency;
	}

	public void setProductCurrency(String productCurrency) {
		this.productCurrency = productCurrency;
	}

	public String getProductCurrencyDescription() {
		return productCurrencyDescription;
	}

	public void setProductCurrencyDescription(String productCurrencyDescription) {
		this.productCurrencyDescription = productCurrencyDescription;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getPintryLimit() {
		return pintryLimit;
	}

	public void setPintryLimit(String pintryLimit) {
		this.pintryLimit = pintryLimit;
	}

	public String getCardGenerationMethod() {
		return cardGenerationMethod;
	}

	public void setCardGenerationMethod(String cardGenerationMethod) {
		this.cardGenerationMethod = cardGenerationMethod;
	}

	public String getCardEmbossingEncode() {
		return cardEmbossingEncode;
	}

	public void setCardEmbossingEncode(String cardEmbossingEncode) {
		this.cardEmbossingEncode = cardEmbossingEncode;
	}

	public String getPinDeliveryMethod() {
		return pinDeliveryMethod;
	}

	public void setPinDeliveryMethod(String pinDeliveryMethod) {
		this.pinDeliveryMethod = pinDeliveryMethod;
	}

	public String getCardExpiryMethod() {
		return cardExpiryMethod;
	}

	public void setCardExpiryMethod(String cardExpiryMethod) {
		this.cardExpiryMethod = cardExpiryMethod;
	}

	public String getExpiryPeriod() {
		return expiryPeriod;
	}

	public void setExpiryPeriod(String expiryPeriod) {
		this.expiryPeriod = expiryPeriod;
	}

	public String getExpiryPeriodMonths() {
		return expiryPeriodMonths;
	}

	public void setExpiryPeriodMonths(String expiryPeriodMonths) {
		this.expiryPeriodMonths = expiryPeriodMonths;
	}

	public String getEmbossingTemplate() {
		return embossingTemplate;
	}

	public void setEmbossingTemplate(String embossingTemplate) {
		this.embossingTemplate = embossingTemplate;
	}

	public String getReplacementTemplate() {
		return replacementTemplate;
	}

	public void setReplacementTemplate(String replacementTemplate) {
		this.replacementTemplate = replacementTemplate;
	}

	public String getWelcomeTemplate() {
		return welcomeTemplate;
	}

	public void setWelcomeTemplate(String welcomeTemplate) {
		this.welcomeTemplate = welcomeTemplate;
	}

	public String getDeliveryMethod() {
		return deliveryMethod;
	}

	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}

	public String getIssuingCurrency() {
		return issuingCurrency;
	}

	public void setIssuingCurrency(String issuingCurrency) {
		this.issuingCurrency = issuingCurrency;
	}

	public String getCardActivationGroup() {
		return cardActivationGroup;
	}

	public void setCardActivationGroup(String cardActivationGroup) {
		this.cardActivationGroup = cardActivationGroup;
	}

	public String getBinGroup() {
		return binGroup;
	}

	public void setBinGroup(String binGroup) {
		this.binGroup = binGroup;
	}

	public String getBinCurrency() {
		return binCurrency;
	}

	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}

	public String getBinRangeFrom() {
		return binRangeFrom;
	}

	public void setBinRangeFrom(String binRangeFrom) {
		this.binRangeFrom = binRangeFrom;
	}

	public String getBinRangeTo() {
		return binRangeTo;
	}

	public void setBinRangeTo(String binRangeTo) {
		this.binRangeTo = binRangeTo;
	}

	public String getPlasticCode() {
		return plasticCode;
	}

	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public String getInertedDate() {
		return inertedDate;
	}

	public void setInertedDate(String inertedDate) {
		this.inertedDate = inertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
