/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanket.more
 */
@Entity
@Table(name = "CMS_M_CUSTOMER")
@SequenceGenerator(sequenceName = "cms_customer_seq", name = "cms_customer_seq", allocationSize = 1)
public class CmsMCustomer implements Serializable {

	@Id
	@Basic(optional = false)
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cms_customer_seq")
	@Column(name="ID")
	private Integer id;
	
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "CUSTOMER_ID")
    private String customerId;
    @Size(max = 20)
    @Column(name = "FIRST_NAME")
    private String firstName;
    @Size(max = 20)
    @Column(name = "MIDDLE_NAME")
    private String middleName;
    @Size(max = 20)
    @Column(name = "LAST_NAME")
    private String lastName;
    @Size(max = 20)
    @Column(name = "DATE_OF_BIRTH")
    private String dateOfBirth;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "MOTHER_NAME")
    private String motherName;
    @Size(max = 20)
    @Column(name = "GENDER")
    private String gender;
    @Size(max = 20)
    @Column(name = "NATIONALITY")
    private String nationality;
    @Size(max = 20)
    @Column(name = "MARITAL_STATUS")
    private String maritalStatus;
    @Size(max = 20)
    @Column(name = "RESIDENTAL_ADDRESS1")
    private String residentalAddress1;
    @Size(max = 20)
    @Column(name = "RESIDENTAL_ADDRESS2")
    private String residentalAddress2;
    @Size(max = 20)
    @Column(name = "RESIDENTAL_ADDRESS3")
    private String residentalAddress3;
    @Size(max = 20)
    @Column(name = "RESIDENTAL_ADDRESS4")
    private String residentalAddress4;
    @Size(max = 20)
    @Column(name = "CITY")
    private String city;
    @Size(max = 20)
    @Column(name = "STATE")
    private String state;
    @Size(max = 20)
    @Column(name = "COUNTRY")
    private String country;
    @Size(max = 20)
    @Column(name = "PIN_CODE")
    private String pinCode;
    @Size(max = 20)
    @Column(name = "PHONE_NUMBER")
    private String phoneNumber;
    @Size(max = 20)
    @Column(name = "OFFICIAL_ADDRESS1")
    private String officialAddress1;
    @Size(max = 20)
    @Column(name = "OFFICIAL_ADDRESS2")
    private String officialAddress2;
    @Size(max = 20)
    @Column(name = "OFFICIAL_ADDRESS3")
    private String officialAddress3;
    @Size(max = 20)
    @Column(name = "OFFICIAL_ADDRESS4")
    private String officialAddress4;
    @Size(max = 20)
    @Column(name = "OFFICIAL_CITY")
    private String officialCity;
    @Size(max = 20)
    @Column(name = "OFFICIAL_STATE")
    private String officialState;
    @Size(max = 20)
    @Column(name = "OFFICIAL_COUNTRY")
    private String officialCountry;
    @Size(max = 20)
    @Column(name = "OFFICIAL_PINCODE")
    private String officialPincode;
    @Size(max = 20)
    @Column(name = "OFFICIAL_PHONE_NUMBER")
    private String officialPhoneNumber;
    @Size(max = 20)
    @Column(name = "OFFICIAL_EXTENSION_NUMBER")
    private String officialExtensionNumber;
    @Size(max = 20)
    @Column(name = "MOBILE_NUMBER")
    private String mobileNumber;
    @Size(max = 20)
    @Column(name = "MAIL_TO")
    private String mailTo;
    @Size(max = 50)
    @Column(name = "EMAIL_ADDRESS")
    private String emailAddress;
    @Size(max = 50)
    @Column(name = "ALTERNATIVE_EMAIL_ADDRESS")
    private String alternativeEmailAddress;
    @Size(max = 20)
    @Column(name = "APPLICATION_DATE")
    private String applicationDate;
    @Size(max = 20)
    @Column(name = "PASSPORT_NUMBER")
    private String passportNumber;
    @Size(max = 20)
    @Column(name = "PASSPORT_ISSUE_DATE")
    private String passportIssueDate;
    @Size(max = 20)
    @Column(name = "PASSPORT_EXPIRY_DATE")
    private String passportExpiryDate;
    @Size(max = 20)
    @Column(name = "PAN_OR_FORM")
    private String panOrForm;
    @Size(max = 20)
    @Column(name = "CMS_PROXY_NUMBER")
    private String cmsProxyNumber;
    @Size(max = 20)
    @Column(name = "CMS_TXNREF_NUMBER")
    private String cmsTxnrefNumber;
    @Size(max = 20)
    @Column(name = "PAN_NUMBER")
    private String panNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @OneToMany(mappedBy = "custId")
    private List<CmsMIdentificationType> cmsMIdentificationTypeList;
    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getResidentalAddress1() {
        return residentalAddress1;
    }

    public void setResidentalAddress1(String residentalAddress1) {
        this.residentalAddress1 = residentalAddress1;
    }

    public String getResidentalAddress2() {
        return residentalAddress2;
    }

    public void setResidentalAddress2(String residentalAddress2) {
        this.residentalAddress2 = residentalAddress2;
    }

    public String getResidentalAddress3() {
        return residentalAddress3;
    }

    public void setResidentalAddress3(String residentalAddress3) {
        this.residentalAddress3 = residentalAddress3;
    }

    public String getResidentalAddress4() {
        return residentalAddress4;
    }

    public void setResidentalAddress4(String residentalAddress4) {
        this.residentalAddress4 = residentalAddress4;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getOfficialAddress1() {
        return officialAddress1;
    }

    public void setOfficialAddress1(String officialAddress1) {
        this.officialAddress1 = officialAddress1;
    }

    public String getOfficialAddress2() {
        return officialAddress2;
    }

    public void setOfficialAddress2(String officialAddress2) {
        this.officialAddress2 = officialAddress2;
    }

    public String getOfficialAddress3() {
        return officialAddress3;
    }

    public void setOfficialAddress3(String officialAddress3) {
        this.officialAddress3 = officialAddress3;
    }

    public String getOfficialAddress4() {
        return officialAddress4;
    }

    public void setOfficialAddress4(String officialAddress4) {
        this.officialAddress4 = officialAddress4;
    }

    public String getOfficialCity() {
        return officialCity;
    }

    public void setOfficialCity(String officialCity) {
        this.officialCity = officialCity;
    }

    public String getOfficialState() {
        return officialState;
    }

    public void setOfficialState(String officialState) {
        this.officialState = officialState;
    }

    public String getOfficialCountry() {
        return officialCountry;
    }

    public void setOfficialCountry(String officialCountry) {
        this.officialCountry = officialCountry;
    }

    public String getOfficialPincode() {
        return officialPincode;
    }

    public void setOfficialPincode(String officialPincode) {
        this.officialPincode = officialPincode;
    }

    public String getOfficialPhoneNumber() {
        return officialPhoneNumber;
    }

    public void setOfficialPhoneNumber(String officialPhoneNumber) {
        this.officialPhoneNumber = officialPhoneNumber;
    }

    public String getOfficialExtensionNumber() {
        return officialExtensionNumber;
    }

    public void setOfficialExtensionNumber(String officialExtensionNumber) {
        this.officialExtensionNumber = officialExtensionNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getMailTo() {
        return mailTo;
    }

    public void setMailTo(String mailTo) {
        this.mailTo = mailTo;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getAlternativeEmailAddress() {
        return alternativeEmailAddress;
    }

    public void setAlternativeEmailAddress(String alternativeEmailAddress) {
        this.alternativeEmailAddress = alternativeEmailAddress;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(String passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getPassportIssueDate() {
        return passportIssueDate;
    }

    public void setPassportIssueDate(String passportIssueDate) {
        this.passportIssueDate = passportIssueDate;
    }

    public String getPassportExpiryDate() {
        return passportExpiryDate;
    }

    public void setPassportExpiryDate(String passportExpiryDate) {
        this.passportExpiryDate = passportExpiryDate;
    }

    public String getPanOrForm() {
        return panOrForm;
    }

    public void setPanOrForm(String panOrForm) {
        this.panOrForm = panOrForm;
    }


	public List<CmsMIdentificationType> getCmsMIdentificationTypeList() {
		return cmsMIdentificationTypeList;
	}


	public void setCmsMIdentificationTypeList(List<CmsMIdentificationType> cmsMIdentificationTypeList) {
		this.cmsMIdentificationTypeList = cmsMIdentificationTypeList;
	}

	public String getCmsProxyNumber() {
		return cmsProxyNumber;
	}

	public void setCmsProxyNumber(String cmsProxyNumber) {
		this.cmsProxyNumber = cmsProxyNumber;
	}

	public String getCmsTxnrefNumber() {
		return cmsTxnrefNumber;
	}

	public void setCmsTxnrefNumber(String cmsTxnrefNumber) {
		this.cmsTxnrefNumber = cmsTxnrefNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
    
    
}
