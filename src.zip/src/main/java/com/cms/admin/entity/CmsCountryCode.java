package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_COUNTRY_CODE")
public class CmsCountryCode {

	@Id
	@Column(name = "COUNTRY_CODE_ID")
	private Long countryCodeId;

	@Column(name = "COUNTRY_CODE_NAME")
	private String countryCodeName;

	@Column(name = "COUNTRY_CODE_DESC")
	private String countryCodeDesc;

	@Column(name = "ACQUIRED_NETWORK_ID")
	private String acquiredNetworkId;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "STATUS")
	private String status;

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getCountryCodeName() {
		return countryCodeName;
	}

	public void setCountryCodeName(String countryCodeName) {
		this.countryCodeName = countryCodeName;
	}

	public String getCountryCodeDesc() {
		return countryCodeDesc;
	}

	public void setCountryCodeDesc(String countryCodeDesc) {
		this.countryCodeDesc = countryCodeDesc;
	}

	public String getAcquiredNetworkId() {
		return acquiredNetworkId;
	}

	public void setAcquiredNetworkId(String acquiredNetworkId) {
		this.acquiredNetworkId = acquiredNetworkId;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
