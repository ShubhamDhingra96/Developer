package com.cms.admin.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CMS_M_CLIENT_LOGIN")
public class CmsClientLogin {

	@Id
	@Column(name = "USERNAME")
	private String username;
	@Column(name = "PASSWORD")
	private String password;

	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "CMS_CLIENT_ID", referencedColumnName = "CMS_CLIENT_ID")
	@ForeignKey(name = "none")
	private CmsClient cmsClientId;

	@Column(name = "PASSWORDSTATUS")
	private String passwordStatus;
	@Column(name = "ISADMIN")
	private String isAdmin;
	@Column(name = "ISUSER")
	private String isUser;
	@Column(name = "ISCLIENT")
	private String isClient;

	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "PERMISSION_ID", referencedColumnName = "P_ID")
	@ForeignKey(name = "none")
	private CmsPreviliges permissionId;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;
	@Column(name = "INSERTEDBY")
	private String insertedBy;
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	@Column(name = "MODIFIEDBY")
	private String modifiedBy;

	@Size(max = 50)
	@Column(name = "TOKEN_KEY")
	private String tokenKey;
	@Column(name = "TOKEN_EXPIRY_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date tokenExpiryDate;
	@Column(name = "RESET_PASSWORD_STATUS")
	private Character resetPasswordStatus;

	@Column(name = "LOGIN_APPEMPTS")
	private Integer loginAttempts;

	@Column(name = "ACCOUNTLOCK_FLAG")
	private Integer accountLockFlag;

	@Column(name = "PASSWORD_MODIFIED_DATE")
	private Date passwordModifiedDate;

	@Column(name = "LAST_LOGIN_TIME")
	private Date lastLoginTime;

	@Column(name = "CITY", length = 20)
	private String city;
	@Column(name = "COUNTRY", length = 20)
	private String country;
	@Column(name = "CURRENCY_AGENT", length = 20)
	private String currencyAgent;
	@Column(name = "DESIGNATION", length = 20)
	private String designation;
	@Column(name = "EMAIL", length = 20)
	private String email;
	@Column(name = "EMPLOYEE_CODE", length = 20)
	private String employeeNo;
	@Column(name = "EXPIRY_DATE", length = 20)
	private String expiryDate;
	@Column(name = "FAX", length = 20)
	private String faxno;
	@Column(name = "FIRST_NAME", length = 20)
	private String firstName;
	@Column(name = "LAST_NAME", length = 20)
	private String lastName;
	@Column(name = "MOBILE", length = 20)
	private String mobile;
	@Column(name = "PASSPORT", length = 20)
	private String passportNo;
	@Column(name = "POST_CODE", length = 20)
	private String postCode;
	@Column(name = "REGION", length = 20)
	private String region;
	@Column(name = "STATE", length = 20)
	private String state;
	@Column(name = "TELE_OFF", length = 20)
	private String telephoneOff;
	@Column(name = "TELE_RES", length = 20)
	private String telephoneRes;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCurrencyAgent() {
		return currencyAgent;
	}

	public void setCurrencyAgent(String currencyAgent) {
		this.currencyAgent = currencyAgent;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(String employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getFaxno() {
		return faxno;
	}

	public void setFaxno(String faxno) {
		this.faxno = faxno;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTelephoneOff() {
		return telephoneOff;
	}

	public void setTelephoneOff(String telephoneOff) {
		this.telephoneOff = telephoneOff;
	}

	public String getTelephoneRes() {
		return telephoneRes;
	}

	public void setTelephoneRes(String telephoneRes) {
		this.telephoneRes = telephoneRes;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "username")
	private Set<CmsMClientLoginHistory> passwordHistories;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public CmsClient getCmsClientId() {
		return cmsClientId;
	}

	public void setCmsClientId(CmsClient cmsClientId) {
		this.cmsClientId = cmsClientId;
	}

	public String getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getIsUser() {
		return isUser;
	}

	public void setIsUser(String isUser) {
		this.isUser = isUser;
	}

	public String getIsClient() {
		return isClient;
	}

	public void setIsClient(String isClient) {
		this.isClient = isClient;
	}

	public CmsPreviliges getPermissionId() {
		return permissionId;
	}

	public void setPermissionId(CmsPreviliges permissionId) {
		this.permissionId = permissionId;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	public Date getTokenExpiryDate() {
		return tokenExpiryDate;
	}

	public void setTokenExpiryDate(Date tokenExpiryDate) {
		this.tokenExpiryDate = tokenExpiryDate;
	}

	public Character getResetPasswordStatus() {
		return resetPasswordStatus;
	}

	public void setResetPasswordStatus(Character resetPasswordStatus) {
		this.resetPasswordStatus = resetPasswordStatus;
	}

	public Integer getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Integer getAccountLockFlag() {
		return accountLockFlag;
	}

	public void setAccountLockFlag(Integer accountLockFlag) {
		this.accountLockFlag = accountLockFlag;
	}

	public Date getPasswordModifiedDate() {
		return passwordModifiedDate;
	}

	public void setPasswordModifiedDate(Date passwordModifiedDate) {
		this.passwordModifiedDate = passwordModifiedDate;
	}

	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "employee")
	public Set<CmsMClientLoginHistory> getPasswordHistories() {
		return passwordHistories;
	}

	public void setPasswordHistories(Set<CmsMClientLoginHistory> passwordHistories) {
		this.passwordHistories = passwordHistories;
	}

	public String getPasswordStatus() {
		return passwordStatus;
	}

	public void setPasswordStatus(String passwordStatus) {
		this.passwordStatus = passwordStatus;
	}

}
