package com.cms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_M_COUNTRY_GROUP")
@SequenceGenerator(sequenceName = "CMS_COUNTRY_GROUP_SEQ", name = "CMS_COUNTRY_GROUP_SEQ", allocationSize = 1)
public class CmsCountryGroup {

	@Id
	@Column(name = "GROUP_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_COUNTRY_GROUP_SEQ")
	private Integer groupId;

	@Column(name = "GROUP_CODE")
	private String groupCode;

	@Column(name = "GROUP_NAME")
	private String groupName;

	@Column(name = "GROUP_DESCRIPION")
	private String groupDescription;

	@Column(name = "GROUP_CONTRIES_LIST")
	private String groupCompanyList;
	
	@Column(name="INSERTEDBY")
	private String insertedBy;

	@Column(name="MODIFIEDBY")
	private String modifiedBy;

	@Column(name="INSERTEDDATE")
	private String insertedDate;

	@Column(name="MODIFIEDDATE")
	private String modifiedDate;
	
	

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}

	public String getGroupCompanyList() {
		return groupCompanyList;
	}

	public void setGroupCompanyList(String groupCompanyList) {
		this.groupCompanyList = groupCompanyList;
	}

}
