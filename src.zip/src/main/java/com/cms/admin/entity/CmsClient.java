package com.cms.admin.entity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "CMS_M_CLIENT")
public class CmsClient implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3281383410757081306L;
	@Id
	@GeneratedValue(generator = "custom_gen", strategy = GenerationType.SEQUENCE)
	@GenericGenerator(name = "custom_gen", strategy = "com.cms.admin.utility.CmsClientCustomizeKey")
	@Column(name = "TXNREFNUMBER")
	private String txnRefNumber;
	@Column(name = "CMS_CLIENT_ID")
	private String cmsClientId;
	@Column(name = "CMS_COMPANY_NAME")
	private String cmsCompanyName;
	@Column(name = "CMS_COMPANY_ADDRESS1")
	private String cmsCompanyAddress1;
	@Column(name = "CMS_COMPANY_ADDRESS2")
	private String cmsCompanyAddress2;
	@Column(name = "CMS_COMPANY_CITY")
	private String cmsCompanyCity;
	@Column(name = "CMS_COMPANY_STATE")
	private String cmsCompanystate;
	@Column(name = "CMS_COMPANY_COUNTRY")
	private String cmsCompanyCountry;
	@Column(name = "CMS_COMPANY_STATUS")
	private String cmsCompanyStatus;
	@Column(name = "REF1")
	private String ref1;
	@Column(name = "REF2")
	private String ref2;
	@Column(name = "REF3")
	private String ref3;
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "CMS_COMPANY_POSTALCODE")
	private String cmsCompanyPinCode;

	@Column(name = "CMS_COMPANY_CURRENCY_AGENT")
	private String cmsCompanyCurrencyAgent;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "INSERTED_BY", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
	private CmsClientLogin insertedBy;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.ALL })
	@JoinColumn(name = "MODIFIED_BY", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
	private CmsClientLogin modifiedBy;
	
	 @Column(name = "CORPORATE_TYPE")
	  private String corporateType;
	
	 @Column(name = "USER_CREATED")
	  private String userCreated;
	
	
	
	


	public void setCmsCompanyCurrencyAgent(String cmsCompanyCurrencyAgent) {
		this.cmsCompanyCurrencyAgent = cmsCompanyCurrencyAgent;
	}

	public void setCmsCompanyPinCode(String cmsCompanyPinCode) {
		this.cmsCompanyPinCode = cmsCompanyPinCode;
	}

	public String getCmsCompanyCurrencyAgent() {
		return cmsCompanyCurrencyAgent;
	}

	public String getCmsCompanyPinCode() {
		return cmsCompanyPinCode;
	}

	public String getTxnRefNumber() {
		return txnRefNumber;
	}

	public void setTxnRefNumber(String txnRefNumber) {
		this.txnRefNumber = txnRefNumber;
	}

	public String getCmsClientId() {
		return cmsClientId;
	}

	public void setCmsClientId(String cmsClientId) {
		this.cmsClientId = cmsClientId;
	}

	public String getCmsCompanyName() {
		return cmsCompanyName;
	}

	public void setCmsCompanyName(String cmsCompanyName) {
		this.cmsCompanyName = cmsCompanyName;
	}

	public String getCmsCompanyAddress1() {
		return cmsCompanyAddress1;
	}

	public void setCmsCompanyAddress1(String cmsCompanyAddress1) {
		this.cmsCompanyAddress1 = cmsCompanyAddress1;
	}

	public String getCmsCompanyAddress2() {
		return cmsCompanyAddress2;
	}

	public void setCmsCompanyAddress2(String cmsCompanyAddress2) {
		this.cmsCompanyAddress2 = cmsCompanyAddress2;
	}

	public String getCmsCompanyCity() {
		return cmsCompanyCity;
	}

	public void setCmsCompanyCity(String cmsCompanyCity) {
		this.cmsCompanyCity = cmsCompanyCity;
	}

	public String getCmsCompanystate() {
		return cmsCompanystate;
	}

	public void setCmsCompanystate(String cmsCompanystate) {
		this.cmsCompanystate = cmsCompanystate;
	}

	public String getCmsCompanyCountry() {
		return cmsCompanyCountry;
	}

	public void setCmsCompanyCountry(String cmsCompanyCountry) {
		this.cmsCompanyCountry = cmsCompanyCountry;
	}

	public String getCmsCompanyStatus() {
		return cmsCompanyStatus;
	}

	public void setCmsCompanyStatus(String cmsCompanyStatus) {
		this.cmsCompanyStatus = cmsCompanyStatus;
	}

	public String getRef1() {
		return ref1;
	}

	public void setRef1(String ref1) {
		this.ref1 = ref1;
	}

	public String getRef2() {
		return ref2;
	}

	public void setRef2(String ref2) {
		this.ref2 = ref2;
	}

	public String getRef3() {
		return ref3;
	}

	public void setRef3(String ref3) {
		this.ref3 = ref3;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CmsClientLogin getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(CmsClientLogin insertedBy) {
		this.insertedBy = insertedBy;
	}

	public CmsClientLogin getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(CmsClientLogin modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCorporateType() {
		return corporateType;
	}

	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

	public String getUserCreated() {
		return userCreated;
	}

	public void setUserCreated(String userCreated) {
		this.userCreated = userCreated;
	}
	
	

}
