/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanket.more
 */
@Entity
@Table(name = "CMS_M_MODULES")
public class CmsMModules implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "CMS_MODULE_ID")
    private String cmsModuleId;
    @Size(max = 30)
    @Column(name = "CMS_MODULE_NAME")
    private String cmsModuleName;
    @Column(name = "INSERTED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertedDate;
    @Column(name = "MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Size(max = 20)
    @Column(name = "INSERTED_BY")
    private String insertedBy;
    @Size(max = 20)
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "STATUS")
    private Character status;
    @OneToMany(mappedBy = "cmsMModules",fetch=FetchType.EAGER)
    private List<CmsMFunctions> cmsMFunctionsList;

    public CmsMModules() {
    }

    public CmsMModules(String cmsModuleId) {
        this.cmsModuleId = cmsModuleId;
    }

    public String getCmsModuleId() {
        return cmsModuleId;
    }

    public void setCmsModuleId(String cmsModuleId) {
        this.cmsModuleId = cmsModuleId;
    }

    public String getCmsModuleName() {
        return cmsModuleName;
    }

    public void setCmsModuleName(String cmsModuleName) {
        this.cmsModuleName = cmsModuleName;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getInsertedBy() {
        return insertedBy;
    }

    public void setInsertedBy(String insertedBy) {
        this.insertedBy = insertedBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }

    public List<CmsMFunctions> getCmsMFunctionsList() {
        return cmsMFunctionsList;
    }

    public void setCmsMFunctionsList(List<CmsMFunctions> cmsMFunctionsList) {
        this.cmsMFunctionsList = cmsMFunctionsList;
    }

   

	

    
    
}
