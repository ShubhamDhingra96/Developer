package com.cms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_ACQUIRING_NETWORK")
public class CmsAcquiringNetworkGroup {

	@Id
	@Column(name = "GROUP_CODE")
	private String groupCode;
	
	@Column(name ="GROUP_NAME")
	private String groupName;
	
	@Column(name ="GROUP_DESCRIPTION")
	private String groupDescription;
	
	@Column(name ="NETWORK_TYPE")
	private String networkType;
	
	@Column(name ="NETWORK_ID")
	private String networkId;
	
	@Column(name ="COUNTRY_CODE")
	private String countryCode;
	
	@Column(name ="DELIVERY_CHANNEL")
	private String deliveryChannel;
	
	@Column(name ="DELIVERY_CHANNEL_NAME")
	private String deliveryChannelName;
	
	@Column(name ="LOCATION")
	private String location;
	
	@Column(name ="TERMINAL_ID")
	private String terminalId;
	
	@Column(name ="MERCHANT_ID")
	private String merchantId;
	
	@Column(name ="INSERTED_DATE")
	private String insertedDate;
	
	@Column(name ="INSERTED_BY")
	private String insertedBy;
	
	@Column(name ="MODIFIED_DATE")
	private String modifiedDate;
	
	@Column(name ="MODIFIED_BY")
	private String modifiedBy;
	

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}

	public String getNetworkType() {
		return networkType;
	}

	public void setNetworkType(String networkType) {
		this.networkType = networkType;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getDeliveryChannel() {
		return deliveryChannel;
	}

	public void setDeliveryChannel(String deliveryChannel) {
		this.deliveryChannel = deliveryChannel;
	}

	public String getDeliveryChannelName() {
		return deliveryChannelName;
	}

	public void setDeliveryChannelName(String deliveryChannelName) {
		this.deliveryChannelName = deliveryChannelName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(String insertedDate) {
		this.insertedDate = insertedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
