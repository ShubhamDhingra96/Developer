package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CMS_LOGIN_PRIVLEDGES")
public class CmsLoginPrivledges {

	@Id
	@SequenceGenerator(name = "cms_login_prev_seq_gen", sequenceName = "CMS_LOGIN_PRIVLEDGES_SEQ",allocationSize = 1)
	@GeneratedValue(generator = "cms_login_prev_seq_gen",strategy = GenerationType.SEQUENCE)
	@Column(name = "SR_NO")
	private Number srNo;

	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "USERNAME", referencedColumnName = "USERNAME")
	@ForeignKey(name = "none")
	private CmsClientLogin userName;

	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
	@JoinColumn(name = "P_NAME", referencedColumnName = "P_ID")
	@ForeignKey(name = "none")
	private CmsPreviliges pName;

	@Column(name = "INSEERTED_DATE")
	private Date insertedDate;
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	public Number getSrNo() {
		return srNo;
	}

	public void setSrNo(Number srNo) {
		this.srNo = srNo;
	}

	public CmsClientLogin getUserName() {
		return userName;
	}

	public void setUserName(CmsClientLogin userName) {
		this.userName = userName;
	}

	public CmsPreviliges getpName() {
		return pName;
	}

	public void setpName(CmsPreviliges pName) {
		this.pName = pName;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
