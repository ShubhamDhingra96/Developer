/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanket.more
 */
@Entity
@Table(name = "CMS_M_FUNCTIONS")
public class CmsMFunctions  {

  
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "CMS_M_FUNCTION_ID")
    private String cmsMFunctionId;
    @Size(max = 70)
    @Column(name = "CMS_M_FUNCTION_NAME")
    private String cmsMFunctionName;
    @Column(name = "INSERTED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertedDate;
    @Column(name = "MODIFIED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date modifiedDate;
    @Size(max = 20)
    @Column(name = "INSERTED_BY")
    private String insertedBy;
    @Size(max = 20)
    @Column(name = "MODIFIED_BY")
    private String modifiedBy;
    @Column(name = "STATUS")
    private Character status;
    //@JoinColumn(name = "CMS_M_ID", referencedColumnName = "CMS_MODULE_ID")
    //@ManyToOne
    @Column(name = "CMS_M_ID")
    private String cmsMModules;
   //private CmsMModules cmsMModules;
    @OneToMany(mappedBy = "cmsMFunctions",fetch=FetchType.EAGER)
    private List<CmsMJobsMapping> cmsMJobsMappingList;

    public CmsMFunctions() {
    }

    public CmsMFunctions(String cmsMFunctionId) {
        this.cmsMFunctionId = cmsMFunctionId;
    }

    public String getCmsMFunctionId() {
        return cmsMFunctionId;
    }

    public void setCmsMFunctionId(String cmsMFunctionId) {
        this.cmsMFunctionId = cmsMFunctionId;
    }

    public String getCmsMFunctionName() {
        return cmsMFunctionName;
    }

    public void setCmsMFunctionName(String cmsMFunctionName) {
        this.cmsMFunctionName = cmsMFunctionName;
    }

    public Date getInsertedDate() {
        return insertedDate;
    }

    public void setInsertedDate(Date insertedDate) {
        this.insertedDate = insertedDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getInsertedBy() {
        return insertedBy;
    }

    public void setInsertedBy(String insertedBy) {
        this.insertedBy = insertedBy;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Character getStatus() {
        return status;
    }

    public void setStatus(Character status) {
        this.status = status;
    }
    
    

public String getCmsMModules() {
		return cmsMModules;
	}

	public void setCmsMModules(String cmsMModules) {
		this.cmsMModules = cmsMModules;
	}

	/*    public CmsMModules getCmsMModules() {
        return cmsMModules;
    }

    public void setCmsMModules(CmsMModules cmsMModules) {
        this.cmsMModules = cmsMModules;
    }
*/
    public List<CmsMJobsMapping> getCmsMJobsMappingList() {
        return cmsMJobsMappingList;
    }

    public void setCmsMJobsMappingList(List<CmsMJobsMapping> cmsMJobsMappingList) {
        this.cmsMJobsMappingList = cmsMJobsMappingList;
    }

    
	
   
    
}
