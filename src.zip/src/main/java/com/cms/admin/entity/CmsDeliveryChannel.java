package com.cms.admin.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CMS_M_DEL_CHNL")
public class CmsDeliveryChannel {

	@Id
	@Column(name = "DEL_ID")
	private String delId;

	@Column(name = "DEL_CODE")
	private String delCode;

	@Column(name = "DEL_DESCRIPTION")
	private String delDescription;
	@Temporal(TemporalType.DATE)
	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@OneToMany(mappedBy = "transDeliveryChannel",fetch = FetchType.EAGER)
	private List<CmsUsageTransaction> transactions;

	public void setTransactions(List<CmsUsageTransaction> transactions) {
		this.transactions = transactions;
	}

	public List<CmsUsageTransaction> getTransactions() {
		return transactions;
	}

	public String getDelId() {
		return delId;
	}

	public void setDelId(String delId) {
		this.delId = delId;
	}

	public String getDelCode() {
		return delCode;
	}

	public void setDelCode(String delCode) {
		this.delCode = delCode;
	}

	public String getDelDescription() {
		return delDescription;
	}

	public void setDelDescription(String delDescription) {
		this.delDescription = delDescription;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
