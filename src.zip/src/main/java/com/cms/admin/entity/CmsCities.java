package com.cms.admin.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CITIES")
public class CmsCities {

	@Id
	@Column(name = "CITY_ID")
	private Long cityId;
	@Column(name = "CITY_NAME")
	private String cityName;

//	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
//	@JoinColumn(name = "STATE_ID", referencedColumnName = "STATE_ID")
//	@ForeignKey(name = "none")
	@Column(name="STATE_ID")
	private Long stateId;

	public Long getCityId() {
		return cityId;
	}

	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

}
