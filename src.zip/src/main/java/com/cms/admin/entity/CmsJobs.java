package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_C_JOBS")
@SequenceGenerator(sequenceName = "CMS_JOBS_", name = "CMS_JOBS", allocationSize = 1)
public class CmsJobs {

	@Id
	@Column(name = "J_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_JOBS")
	private Long jId;

	@Column(name = "F_ID")
	private Long fId;

	@Column(name = "JOB_ID")
	private String jobId;

	@Column(name = "JOB_NAME")
	private String jobName;

	@Column(name = "JOB_URL")
	private String jobUrl;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;
	
	@Column(name = "ISCHECKED")
	private char isChecked;
	
	
	public void setIsChecked(char isChecked) {
		this.isChecked = isChecked;
	}
	
	public char getIsChecked() {
		return isChecked;
	}

	public Long getjId() {
		return jId;
	}

	public void setjId(Long jId) {
		this.jId = jId;
	}

	public Long getfId() {
		return fId;
	}

	public void setfId(Long fId) {
		this.fId = fId;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobUrl() {
		return jobUrl;
	}

	public void setJobUrl(String jobUrl) {
		this.jobUrl = jobUrl;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
