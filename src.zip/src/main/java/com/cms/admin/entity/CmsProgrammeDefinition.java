package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CMS_M_PROGRAM_DEFINITION")
public class CmsProgrammeDefinition {

	
	@Id
	@SequenceGenerator(name = "cms_cms_group_gen", sequenceName = "CMS_M_PLASTICSETUP_SEQ",allocationSize = 1)
	@GeneratedValue(generator = "cms_cms_group_gen",strategy = GenerationType.SEQUENCE)
	@Column(name="PROGRAM_DEFINITION_ID")
	private Integer programDefinitionid;
	
	@Column(name="APPLICATION_TYPE")
	   private String applicationType;
	   
	   @Column(name="AUTHORIZATION_RULE")
		private String authrizationRule;
	   
	   @Column(name="PROGRAM_CODE")
		private String programCode;
	   
	   @Column(name="PROGRAM_DESCRIPTION")
	   private String programDescription;
	   
	   @Column(name="SHORT_DESCRIPTION")
		private String shortDescription;
		
	   @Column(name="INSERTED_DATE")
	   private Date insertedDate;
		
	   @Column(name="MODIFIED_DATE")
	   private Date modifiedDate; 
	   
	   @Column(name="MODIFIED_BY")
		private String modifiedBy;
	   
	   @Column(name="INSERTED_BY")
		private String insertedBy;
	   
	   @Column(name="MULTIPLE_PROD_ACCOUNT")
		private String multiprodAccount;

	public Integer getProgramDefinitionid() {
		return programDefinitionid;
	}

	public void setProgramDefinitionid(Integer programDefinitionid) {
		this.programDefinitionid = programDefinitionid;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getAuthrizationRule() {
		return authrizationRule;
	}

	public void setAuthrizationRule(String authrizationRule) {
		this.authrizationRule = authrizationRule;
	}

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getProgramDescription() {
		return programDescription;
	}

	public void setProgramDescription(String programDescription) {
		this.programDescription = programDescription;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getMultiprodAccount() {
		return multiprodAccount;
	}

	public void setMultiprodAccount(String multiprodAccount) {
		this.multiprodAccount = multiprodAccount;
	} 
	   
	   
}
