package com.cms.admin.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "CMS_FUNCTION")
@SequenceGenerator(sequenceName = "CMS_FUNCTIONS_", name = "CMS_FUNCTIONS", allocationSize = 1)
public class CmsFunctions {

	@Id
	@Column(name = "F_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_FUNCTIONS")
	private Long fId;

	@Column(name = "FUNCTION_ID")
	private String functionId;

	@Column(name = "FUNCTION_NAME")
	private String functionName;

	@Column(name = "M_ID")
	private Long mId;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "STATUS")
	private char status;
	
	@Column(name = "ISCHECKED")
	private char isChecked;
	
	
	public void setIsChecked(char isChecked) {
		this.isChecked = isChecked;
	}
	
	public char getIsChecked() {
		return isChecked;
	}

	@OneToMany(mappedBy = "fId", fetch = FetchType.EAGER)
	private List<CmsJobs> cmsJobsList;

	public void setCmsJobsList(List<CmsJobs> cmsJobsList) {
		this.cmsJobsList = cmsJobsList;
	}

	public List<CmsJobs> getCmsJobsList() {
		return cmsJobsList;
	}

	public Long getfId() {
		return fId;
	}

	public void setfId(Long fId) {
		this.fId = fId;
	}

	public String getFunctionId() {
		return functionId;
	}

	public void setFunctionId(String functionId) {
		this.functionId = functionId;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public Long getmId() {
		return mId;
	}

	public void setmId(Long mId) {
		this.mId = mId;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

}
