package com.cms.admin.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;

@Entity
@Table(name = "CMS_BINGROUP_SETUP")
public class CmsBinGroup {

	@Id
	@SequenceGenerator(name = "cms_cms_group_gen", sequenceName = "CMS_BINGROUP_SETUP_SEQ", allocationSize = 1)
	@GeneratedValue(generator = "cms_cms_group_gen", strategy = GenerationType.SEQUENCE)
	@Column(name = "BINGROUP_ID")
	private Integer binGroupId;
	
	@Column(name = "BINGROUP_CODE")
	private String binGroupCode;

	@Column(name = "BINGROUP_NAME")
	private String binGroupName;
	
	@Column(name = "BINGROUP_DESC")
	private String binGroupDesc;
	
	@Column(name = "BIN_CURRENCY")
	private String binCurrency;

	@Column(name = "BIN_SETTLEMENT_CURRENCY")
	private String binSettlementCurrency;

	@Column(name = "BIN_SETTLEMENT_TYPE")
	private String binSettlementType;

	@Column(name = "BIN_RANGE_FROM")
	private String binRnangeFrom;

	@Column(name = "BIN_RANGE_TO")
	private String binRangeTo;

	@Column(name = "TOTAL_NUMBER_OF_CARDS")
	private String totalNumber;

	@Column(name = "TRASACTION_SETTLEMENT_CURRENCY")
	private String transactionSettlementCurrency;
	
    @Column(name = "PLASTIC_CODE")
	private String plasticCode;

	@Column(name = "INSERTED_DATE")
	private Date insertedDate;

	@Column(name = "MODIFIED_DATE")
	private Date modifiedDate;

	@Column(name = "INSERTED_BY")
	private String insertedBy;

	@Column(name = "MODIFIED_BY")
	private String modifiedBy;

	@Column(name = "CMS_CLIENT_ID")
	private String clientID;

//	@ManyToOne(fetch = FetchType.EAGER, cascade = { CascadeType.ALL })
//	@JoinColumn(name = "BIN_ID", referencedColumnName = "BIN_ID")
//	@ForeignKey(name = "none")
//	private CmsBin binId;
	
	@Column(name = "BIN_ID")
	private Long binId;
	
    @Column(name = "BIN_DESC")
	private String binDesc;

	public Integer getBinGroupId() {
		return binGroupId;
	}

	public void setBinGroupId(Integer binGroupId) {
		this.binGroupId = binGroupId;
	}

	public String getBinGroupCode() {
		return binGroupCode;
	}

	public void setBinGroupCode(String binGroupCode) {
		this.binGroupCode = binGroupCode;
	}

	public String getBinGroupDesc() {
		return binGroupDesc;
	}

	public void setBinGroupDesc(String binGroupDesc) {
		this.binGroupDesc = binGroupDesc;
	}

	

	public Long getBinId() {
		return binId;
	}

	public void setBinId(Long binId) {
		this.binId = binId;
	}

	public String getBinDesc() {
		return binDesc;
	}

	public void setBinDesc(String binDesc) {
		this.binDesc = binDesc;
	}

	
	public String getPlasticCode() {
		return plasticCode;
	}

	public void setPlasticCode(String plasticCode) {
		this.plasticCode = plasticCode;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getInsertedBy() {
		return insertedBy;
	}

	public void setInsertedBy(String insertedBy) {
		this.insertedBy = insertedBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	
	public String getBinCurrency() {
		return binCurrency;
	}

	public void setBinCurrency(String binCurrency) {
		this.binCurrency = binCurrency;
	}

	public String getBinSettlementCurrency() {
		return binSettlementCurrency;
	}

	public void setBinSettlementCurrency(String binSettlementCurrency) {
		this.binSettlementCurrency = binSettlementCurrency;
	}

	public String getBinSettlementType() {
		return binSettlementType;
	}

	public void setBinSettlementType(String binSettlementType) {
		this.binSettlementType = binSettlementType;
	}

	public String getBinRnangeFrom() {
		return binRnangeFrom;
	}

	public void setBinRnangeFrom(String binRnangeFrom) {
		this.binRnangeFrom = binRnangeFrom;
	}

	public String getBinRangeTo() {
		return binRangeTo;
	}

	public void setBinRangeTo(String binRangeTo) {
		this.binRangeTo = binRangeTo;
	}

	public String getTotalNumber() {
		return totalNumber;
	}

	public void setTotalNumber(String totalNumber) {
		this.totalNumber = totalNumber;
	}

	public String getTransactionSettlementCurrency() {
		return transactionSettlementCurrency;
	}

	public void setTransactionSettlementCurrency(String transactionSettlementCurrency) {
		this.transactionSettlementCurrency = transactionSettlementCurrency;
	}

	public String getBinGroupName() {
		return binGroupName;
	}

	public void setBinGroupName(String binGroupName) {
		this.binGroupName = binGroupName;
	}

	public String getClientID() {
		return clientID;
	}

	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	
	
}
