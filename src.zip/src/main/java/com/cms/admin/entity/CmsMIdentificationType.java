/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sanket.more
 */
@Entity
@Table(name = "CMS_M_IDENTIFICATION_TYPE")
@SequenceGenerator(sequenceName = "cms_customers_identification", name = "cms_customers_identification", allocationSize = 1)
public class CmsMIdentificationType implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Basic(optional = false)
	@NotNull
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cms_customers_identification")
	@Column(name = "IDENTIFICATION_ID")
	private Integer identificationId;
	@Basic(optional = false)
	@NotNull
	@Size(min = 1, max = 20)
	@Column(name = "DOCUMENT_TYPE")
	private String documentType;
	@Size(max = 30)
	@Column(name = "ID_NUMBER")
	private String idNumber;
	@Size(max = 20)
	@Column(name = "EXPIRY_DATE")
	private String expiryDate;
	@Size(max = 20)
	@Column(name = "VALID_FROM_DATE")
	private String validFromDate;
	@Column(name = "INSERTED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date insertedDate;
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date modifiedDate;
	@JoinColumn(name = "CUST_ID", referencedColumnName = "ID")
	@ManyToOne
	private CmsMCustomer custId;

	public CmsMIdentificationType() {
	}

	public Integer getIdentificationId() {
		return identificationId;
	}

	public void setIdentificationId(Integer identificationId) {
		this.identificationId = identificationId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getValidFromDate() {
		return validFromDate;
	}

	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}

	public Date getInsertedDate() {
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CmsMCustomer getCustId() {
		return custId;
	}

	public void setCustId(CmsMCustomer custId) {
		this.custId = custId;
	}

	@Override
	public int hashCode() {
		int hash = 0;
		hash += (identificationId != null ? identificationId.hashCode() : 0);
		return hash;
	}

	@Override
	public boolean equals(Object object) {
		// TODO: Warning - this method won't work in the case the id fields are not set
		if (!(object instanceof CmsMIdentificationType)) {
			return false;
		}
		CmsMIdentificationType other = (CmsMIdentificationType) object;
		if ((this.identificationId == null && other.identificationId != null)
				|| (this.identificationId != null && !this.identificationId.equals(other.identificationId))) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "com.controller.CmsMIdentificationType[ identificationId=" + identificationId + " ]";
	}

}
