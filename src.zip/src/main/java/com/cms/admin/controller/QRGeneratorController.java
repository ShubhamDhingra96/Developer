package com.cms.admin.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.utility.QRCodeGenerator;

@RequestMapping("qrcode")
@RestController
public class QRGeneratorController {
	
	@Autowired
	private QRCodeGenerator QRgenerator;
	
	
	@CrossOrigin("*")
	@RequestMapping(value= {"qrcode/{user}"},consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> orCode(@PathVariable("user") String user){
		
		Map<String, String> codeTextTable = new HashMap<String, String>();
		codeTextTable.put("name", user);
		GenericResponse<String> response = new  GenericResponse<String>();
		response.setData(QRgenerator.generateCode(codeTextTable));
		return new ResponseEntity<Object>(response,HttpStatus.OK);
	}
	

}
