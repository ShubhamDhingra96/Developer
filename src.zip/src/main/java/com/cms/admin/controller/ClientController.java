package com.cms.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsClientRegisterRequest;
import com.cms.admin.bean.CmsCompanyPersonDetail;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsContactPersonDetail;
import com.cms.admin.service.CmsClientLoginService;
import com.cms.admin.service.CmsClientService;

@RequestMapping(value = { "client" })
@RestController
public class ClientController {

	@Autowired
	private CmsClientService clientService;

	@Autowired
	private CmsClientLoginService clientLoginService;

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getAll" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAll() {
		return new ResponseEntity<Object>(clientService.getAllClients(), HttpStatus.OK);
	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"save" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(@RequestBody CmsClientRegisterRequest request) {
		GenericResponse<CmsClientLogin> response = new GenericResponse<>();
		try {
			CmsClient client = clientService.setClient(request);
			client = clientService.save(client);			
			//GenericResponse<CmsClientLogin> response = new GenericResponse<>();
			CmsCompanyPersonDetail[] personDetails = request.getContactPersons();
			CmsContactPersonDetail[] persons = new CmsContactPersonDetail[personDetails.length];
			Integer x = 0;
			for (CmsCompanyPersonDetail personDetail : personDetails) {
				CmsContactPersonDetail persn = new CmsContactPersonDetail();
				persn.setClientId(client);
				persn.setPersonCity(personDetail.getCmsCompanyCity());
				persn.setPersonCountry(personDetail.getCmsCompanyCountry());
				persn.setPersonEmail(personDetail.getCmsCompanyCPEmail());
				persn.setPersonFax(personDetail.getCmsCompanyCPfax());
				persn.setPersonLocation(personDetail.getCmsCompanyCPlocation());
				persn.setPersonMailingAddress(personDetail.getCmsCompanyCPMailingAddress());
				persn.setPersonMobile(personDetail.getCmsCompanyCPMobile());
				persn.setPersonName(personDetail.getCmsCompanyCPfullName());
				persn.setPersonPostalCode(personDetail.getCmsCompanyCPPincode());
				persn.setPersonState(personDetail.getCmsCompanyState());
				persn.setPersonTelOff(personDetail.getCmsCompanyCPTelOff());
				persn.setPersonTelRes(personDetail.getCmsCompanyCPTelRes());
				if (personDetail.isSelected()) {
					persons[x] = persn;
				}
				x++;
			}
			clientService.save(persons);

			response.setData(null);
			response.setMessage("Company is successfully created.");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error occured while register Client.");
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = { "view/{clientid}" })
	public ResponseEntity<Object> get(@PathVariable("clientid") String clientId) {
		try {
			return new ResponseEntity<Object>(clientService.get(clientId), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Object>(null, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "has/{company}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> checkUser(@PathVariable("company") String company) {
		try {
			Boolean flag = clientService.hasCompany(company);
			GenericResponse<Boolean> response = new GenericResponse<Boolean>();

			response.setData(flag);
			return new ResponseEntity<Object>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			GenericResponse<Boolean> response = new GenericResponse<Boolean>();

			response.setData(false);
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"getAllCorporate" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllCorporate() {
		return new ResponseEntity<Object>(clientService.getAllCorporates(), HttpStatus.OK);
	}


}
