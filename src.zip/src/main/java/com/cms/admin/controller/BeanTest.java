package com.cms.admin.controller;

import java.util.List;

import javax.validation.Valid;

import com.cms.admin.bean.PlasticProductSetupBean;

public class BeanTest {
	
	@Valid
	private List<PlasticProductSetupBean> bean;
	
	
	public void setBean(List<PlasticProductSetupBean> bean) {
		this.bean = bean;
	}
	
	public List<PlasticProductSetupBean> getBean() {
		return bean;
	}

}
