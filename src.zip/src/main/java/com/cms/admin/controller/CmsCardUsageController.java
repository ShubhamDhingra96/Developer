package com.cms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.service.CmsCardUsageService;

@RequestMapping(value = { "cardusageDetails" })
@RestController
public class CmsCardUsageController {

	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);

	@Autowired
	CmsCardUsageService cmscardusageservice;

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = {
			"save" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveBinDetails(@RequestBody CmsCardUsageBean[] cmscardusagebean) throws Exception {
		logger.info("In Save or Update Start.");
		GenericResponse<String> response = new GenericResponse<String>();
		try {
			CmsCardUsageBean cardusage = null;
			for (CmsCardUsageBean cms : cmscardusagebean) {
				cardusage = cmscardusageservice.saveCmsCardUsageBean(cms);

			}
			logger.info("In Save or Update status : " + cardusage);
			response.setMessage("Card Details saved successfully.");
			return new ResponseEntity<Object>(response, HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error while saving Card Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = {"getAll" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> getCardUsageDetails() throws Exception {
		logger.info("In Get CardUsage Details.");
		GenericResponse genericResponse = new GenericResponse();
		List<CmsCardUsageBean> cardusagedetails = cmscardusageservice.getCmsCardUsageDetails();
		// genericResponse = cmscardusageservice.getCmsCardUsageDetails();
		logger.info("In Get Limit Details :: " + genericResponse);
		return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.CREATED);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = {
			"getAll/{user}/{groupCode}" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> checkCardUsageDetails(@PathVariable("user") String user,@PathVariable("groupCode") String groupCode) throws Exception {
		GenericResponse<CmsCardUsage> genericResponse = new GenericResponse<>();
		try {
			genericResponse.setData(cmscardusageservice.getCardUsageDetailsByCode(user, groupCode));
			return new ResponseEntity<Object>(genericResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			genericResponse.setMessage("No records available.");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@PutMapping(value = {"update" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<CmsCardUsageBean> updateBinDetails(@RequestBody CmsCardUsageBean cmscardusagebean)
			throws Exception {
		CmsCardUsageBean result = cmscardusageservice.updateCardUsageDetails(cmscardusagebean);
		return new ResponseEntity<CmsCardUsageBean>(cmscardusagebean, HttpStatus.CREATED);
	}

	@CrossOrigin("*")
	@RequestMapping(value = { "view/{groupcode}" })
	public ResponseEntity<CmsCardUsageBean> getBinDetails(@PathVariable String groupcode) throws Exception {
		logger.info("In Get Limit Details By Limit code: " + groupcode);
		CmsCardUsageBean cardUsageDetails = cmscardusageservice.getCardUsageDetailsByCode(groupcode);
		logger.info("In Get Limit Details By Limit Code: " + cardUsageDetails.toString());
		return new ResponseEntity<CmsCardUsageBean>(cardUsageDetails, HttpStatus.CREATED);
	}
}