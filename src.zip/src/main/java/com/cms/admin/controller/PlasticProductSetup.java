package com.cms.admin.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.entity.CmsPlasticProductSetup;
import com.cms.admin.service.PlasticProductService;

@RequestMapping("/PlasticSetup")
@RestController
public class PlasticProductSetup {

	@Autowired
	PlasticProductService plasticService;

	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/addPlasticProduct", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveUser(@RequestBody  List<PlasticProductSetupBean> bean) throws Exception {

//		Map<String, Set<String>> errors = new HashMap<>();
//		List<Map<String, String>> err = new ArrayList<>();
//
//		Pattern p = Pattern.compile("\\d+");
//		for (FieldError fieldError : result.getFieldErrors()) {
//			Map<String, String> resultError = new HashMap<String, String>();
//			String code = fieldError.getCode();
//			String field = fieldError.getField();
//			String l = field.substring(0, field.indexOf("."));
//            resultError.put(field.substring(field.indexOf(".")+1), fieldError.getDefaultMessage());
//			Matcher m = p.matcher(l);
//			while (m.find()) {				
//				err.add(Integer.parseInt(m.group()), resultError);
//
//			}
//
//			errors.computeIfAbsent(field, key -> new HashSet<>()).add(fieldError.getDefaultMessage());
//		}
//		if (!errors.isEmpty()) {
//			return new ResponseEntity<Object>(err, HttpStatus.BAD_REQUEST);
//		}

		GenericResponse response = new GenericResponse();
		PlasticProductSetupBean plasicDetails = null;
		try {
			for (PlasticProductSetupBean details : bean) {
				plasicDetails = plasticService.savePlasticSetUp(details);
			}
			logger.info("In Save or Update status : " + plasicDetails);
			response.setMessage("Plastic Code Details saved successfully.");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			response.setMessage("Error while saving Plastic Code Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
		//return null;
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getPlasticDetails", method = RequestMethod.POST)
	public ResponseEntity<Object> getPlasticProductList(@RequestBody PlasticProductSetupBean bean) {
		GenericResponse response = new GenericResponse();
		try {
			response = plasticService.getPlasticProductList(bean);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSpecificPlasticDetails/{clientId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getSpecificPlasticProductList(@PathVariable String clientId) {
		GenericResponse response = new GenericResponse();
		try {
			response = plasticService.getSpecificPlasticCodeList(clientId);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "check/{clientId}/{groupCode}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getSpecificPlasticProductList(@PathVariable("clientId") String clientId,
			@PathVariable("groupCode") String groupCode) {
		GenericResponse<CmsPlasticProductSetup> response = new GenericResponse<>();
		try {
			response.setData(plasticService.getSpecificPlasticProductList(clientId, groupCode));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin("*")
	@PostMapping(value = "validate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, Set<String>> register(@Validated @RequestBody PlasticProductSetupBean plasticBean,
			BindingResult result) {

		Map<String, Set<String>> errors = new HashMap<>();

//	    if (this.existingUsernames.contains(registration.getUsername())) {
//	      errors.computeIfAbsent("username", key -> new HashSet<>()).add("usernameTaken");
//	    }

		for (FieldError fieldError : result.getFieldErrors()) {
			String code = fieldError.getCode();
			String field = fieldError.getField();
//	      if (code.equals("NotBlank") || code.equals("NotNull")) {
//	        errors.computeIfAbsent(field, key -> new HashSet<>()).add("required");
//	      }
//	      else if (code.equals("Email") && field.equals("email")) {
//	        errors.computeIfAbsent(field, key -> new HashSet<>()).add("pattern");
//	      }
//	      else if (code.equals("Min") && field.equals("age")) {
//	        errors.computeIfAbsent(field, key -> new HashSet<>()).add("notOldEnough");
//	      }
			// else

			System.out.println(code + "      " + field);
			if (code.equals("Size") && field.equals("plasticCode")) {
				if (plasticBean.getPlasticCode().length() < 10) {
					errors.computeIfAbsent(field, key -> new HashSet<>()).add("minlength");
				} else {
					errors.computeIfAbsent(field, key -> new HashSet<>()).add("maxlength");
				}
			}
		}

		if (errors.isEmpty()) {
			System.out.println(plasticBean);
		}

		return errors;
	}

}
