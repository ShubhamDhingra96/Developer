package com.cms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.entity.CmsCountryCurrency;
import com.cms.admin.service.CmsCountryCurrencyDetail;

@RequestMapping("/CountryCurrency")
@RestController
public class CountryCurrencyController {
	
	@Autowired
	CmsCountryCurrencyDetail cmsCountryCurrencyDetail;
	
	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"getCountryCurrency" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getCountryCurrency() {
		GenericResponse<List<CmsCountryCurrency>> response = new GenericResponse<List<CmsCountryCurrency>>();
		try {
			response.setData(cmsCountryCurrencyDetail.getAll());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

}
