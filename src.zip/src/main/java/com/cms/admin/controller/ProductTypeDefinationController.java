package com.cms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsProductDefinationRequest;
import com.cms.admin.entity.ProductTypeDefinition;
import com.cms.admin.service.ProductDefinationGroup;

@RequestMapping("/ProgramGroupTypeDefinition")
@RestController
public class ProductTypeDefinationController {
	
	@Autowired
	ProductDefinationGroup productDefination;

	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);

	@CrossOrigin("*")
	@RequestMapping(value = { "products/{user}" })
	public ResponseEntity<Object> allProductsByUser(@PathVariable("user") String user) {
		return null;
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = "saveProductTypeDefination", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> saveProductTypeDefination(@RequestBody CmsProductDefinationRequest[] products) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {

			for(CmsProductDefinationRequest product:products)
			productDefination.saveDetail(product);
			response.setMessage("Product Defination created successfully.!");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("You have saved invalid data");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getProductGroup/{user}" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getProductGroup(@PathVariable("user") String username) {
		GenericResponse<List<ProductTypeDefinition>> response = new GenericResponse<List<ProductTypeDefinition>>();
		try {
			response.setData(productDefination.getAll(username));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}
	
}
