package com.cms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.FeeManagement;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.service.FeeManagementSevice;


@RestController
public class FeeManagementController {

	@Autowired
	FeeManagementSevice feemanageservice;
	
	@CrossOrigin("*")
	@RequestMapping(value = "/saveFeeDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> saveFeedetails(@RequestBody FeeManagement[] feemanagement) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {

			feemanageservice.saveFeeDetails(feemanagement);
			response.setMessage("Fee Details save successfully.!");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("You have saved invalid Fee Details");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	

	@CrossOrigin("*")
	@GetMapping(value = "/getFeeDetails", produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<List<FeeManagement>>getFeeDetail() throws Exception {

		List<FeeManagement> feemanagement = feemanageservice.getFeeDetails();
		System.out.println("****in feee controller****");
		return new ResponseEntity<List<FeeManagement>>(feemanagement, HttpStatus.CREATED);
	}

	@CrossOrigin("*")
	@PutMapping(value = "/updateFeeDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<FeeManagement> updateDetails(@RequestBody FeeManagement feeManagement) throws Exception {

		FeeManagement result = feemanageservice.updateFeeDetails(feeManagement);
		return new ResponseEntity<FeeManagement>(feeManagement, HttpStatus.CREATED);
	}

	@GetMapping(value = "/getFeeDetails/{feeCode}", produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<FeeManagement> getDetails(@PathVariable String feeCode) throws Exception {

		FeeManagement details = feemanageservice.getFeeDetailsByCode(feeCode);
		return new ResponseEntity<FeeManagement>(details, HttpStatus.CREATED);
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = "/cmsFeeDetails/{user}/{feeCode}",produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getCmsFeeManagement(@PathVariable("user") String user,
			@PathVariable("feeCode") String feeCode) {
		GenericResponse<CmsFeeManagement> response = new GenericResponse<CmsFeeManagement>();
		try {
			CmsFeeManagement cmsfeemanagement=feemanageservice.getFeeDetails(user,feeCode);
			response.setData(cmsfeemanagement);
			return new ResponseEntity<Object>(response,HttpStatus.OK);
			
		}catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Fee code already exist.");
			return new ResponseEntity<Object>(response,HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getGroupTransactionData", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinCurrencyList() {
		GenericResponse response = new GenericResponse();
		try {
			response = feemanageservice.geTransactionType();
			System.out.println("Response.." + response);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

}













