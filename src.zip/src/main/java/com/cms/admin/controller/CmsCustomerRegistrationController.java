package com.cms.admin.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CustomerRegistration;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsPreviliges;
import com.cms.admin.service.CmsClientService;
import com.cms.admin.service.CmsCustomerRegistrationService;
import com.cms.admin.utility.Password_Generator;
import com.cms.admin.utility.Utility;

@RequestMapping("/customerRegister")
@RestController
public class CmsCustomerRegistrationController {

	@Autowired
	CmsCustomerRegistrationService registrationService;
	
	@Autowired
	CmsClientService clientService;
	
	@Autowired
	Utility utility;
	
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/saveRegisterCustomer", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> saveRegisterCustomer(@RequestBody CustomerRegistration registration)
			throws Exception {
		GenericResponse response = new GenericResponse();
		CmsPreviliges previliges = new CmsPreviliges();
		previliges.setPermissionId("P0000");
		previliges.setPermissionName("GRANTALL");
		previliges.setPermissionDesc("GRANT ALL");
		
		CmsClientLogin cmsClient = new CmsClientLogin();
		CmsClient client=clientService.get("TXN00083");
		
		String firstname=registration.getFirstName();
		String lastname=registration.getLastName();
		cmsClient.setUsername(firstname.substring(0, 2).concat(lastname.substring(0, 2)).concat(utility.customerId()));
		cmsClient.setPassword(Password_Generator.getInitialPassword(12));
		cmsClient.setIsAdmin("N");
		cmsClient.setIsClient("N");
		cmsClient.setIsUser("Y");
		cmsClient.setInsertedBy("sanket");
		cmsClient.setInsertedDate(new Date());
		cmsClient.setPasswordStatus("-1");
		cmsClient.setCmsClientId(client);
		cmsClient.setPermissionId(previliges);
		cmsClient.setAccountLockFlag(1);
		response = registrationService.saveCustomerRegister(registration);
		CmsClientLogin cmsClientLogin=registrationService.save(cmsClient);
		System.out.println("user..."+cmsClientLogin.getIsUser());
		return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
	}

}
