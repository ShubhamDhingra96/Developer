package com.cms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsAcquiredNetworkRequest;
import com.cms.admin.bean.CmsCountryGroupRequest;
import com.cms.admin.bean.CmsDeliveryChannelRequest;
import com.cms.admin.bean.CmsMerchantGroupRequest;
import com.cms.admin.entity.CmsAcquiredNetworkId;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsCountryGroup;
import com.cms.admin.entity.CmsDeliveryChannel;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMerchantDetails;
import com.cms.admin.entity.CmsMerchantMccGroup;
import com.cms.admin.entity.CmsNetworkType;
import com.cms.admin.service.AcquiredNetworkDetail;
import com.cms.admin.service.MerchantCategoryDetail;
import com.cms.admin.service.UsageService;

@RestController
@RequestMapping("usages")
public class UsageController {

	@Autowired
	private UsageService usageService;

	@Autowired
	private MerchantCategoryDetail merchantCategoryDetail;

	@Autowired
	private AcquiredNetworkDetail acquiredNetworkDetail;

	@CrossOrigin("*")
	@RequestMapping(value = "saveCountryGroup", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> saveCountryGroup(@RequestBody CmsCountryGroupRequest group) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {

			usageService.save(group);
			response.setMessage("Group created successfully.!");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("You have saved invalid data");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "saveDeliveryChannelGroup", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> saveDeliveryChannelGroup(
			@RequestBody CmsDeliveryChannelRequest[] cmsDeliveryChannelRequest) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {
			usageService.save(cmsDeliveryChannelRequest);
			response.setMessage("Group created successfully.!");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("You have saved invalid data");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "countryGroup/{parameter}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getCountryGroup(@PathVariable String parameter) {
		GenericResponse<CmsCountryGroup> response = new GenericResponse<CmsCountryGroup>();
		try {
			CmsCountryGroup cmsCountryGroup = null;
			if (parameter.matches("[0-9]+")) {
				cmsCountryGroup = usageService.getCountryGroup(Integer.parseInt(parameter));
			} else {

			}
			response.setData(cmsCountryGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "countryGroup/{user}/{parameter}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkCountryGroup(@PathVariable("user") String user,
			@PathVariable("parameter") String parameter) {
		GenericResponse<CmsCountryGroup> response = new GenericResponse<CmsCountryGroup>();
		try {
			CmsCountryGroup cmsCountryGroup = null;

			cmsCountryGroup = usageService.getCountryGroup(user, parameter);

			response.setData(cmsCountryGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("No records available.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = "countryGroups/{user}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkCountryGroup(@PathVariable("user") String user) {
		GenericResponse<List<CmsCountryGroup>> response = new GenericResponse<>();
		try {		 

			List<CmsCountryGroup> cmsCountryGroup = usageService.getCountryGroup(user);

			response.setData(cmsCountryGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("No records available.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "countryGroup", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getCountryGroup() {
		GenericResponse<List<CmsCountryGroup>> response = new GenericResponse<List<CmsCountryGroup>>();
		try {
			List<CmsCountryGroup> cmsCountryGroup = null;

			cmsCountryGroup = usageService.getAllCountryGroup();

			response.setData(cmsCountryGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "deliveryChannelGroup/{parameter}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getDeliveryChannelGroup(@PathVariable String parameter) {
		GenericResponse<CmsDeliveryChannelGroup> response = new GenericResponse<CmsDeliveryChannelGroup>();
		try {
			CmsDeliveryChannelGroup cmsDeliveryChannelGroup = null;
			if (parameter.matches("[0-9]+")) {
				cmsDeliveryChannelGroup = usageService.getDeliveryChannelGroup(Integer.parseInt(parameter));
			} else {

			}
			response.setData(cmsDeliveryChannelGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "deliveryChannelGroup/{user}/{parameter}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkDeliveryChannelGroup(@PathVariable("user") String user,
			@PathVariable("parameter") String parameter) {
		GenericResponse<CmsDeliveryChannelGroup> response = new GenericResponse<CmsDeliveryChannelGroup>();
		try {
			CmsDeliveryChannelGroup cmsDeliveryChannelGroup = null;

			cmsDeliveryChannelGroup = usageService.getDeliveryChannelGroup(user,parameter);

			response.setData(cmsDeliveryChannelGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = "deliveryChannelGroups/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkDeliveryChannelGroup(@PathVariable("user") String user) {
		GenericResponse<List<CmsDeliveryChannelGroup>> response = new GenericResponse<>();
		try {			 
			 List<CmsDeliveryChannelGroup> cmsDeliveryChannelGroup = usageService.getDeliveryChannelGroup(user);
			response.setData(cmsDeliveryChannelGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "deliveryChannelGroup", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getDeliveryChannelGroup() {
		GenericResponse<List<CmsDeliveryChannelGroup>> response = new GenericResponse<List<CmsDeliveryChannelGroup>>();
		try {
			List<CmsDeliveryChannelGroup> cmsDeliveryChannelGroup = null;
			cmsDeliveryChannelGroup = usageService.getAllDeliveryChannelGroup();
			response.setData(cmsDeliveryChannelGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"merchantCategory" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> merchantDetails(@RequestBody CmsMerchantGroupRequest[] cmsMerchantDetails) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {
			merchantCategoryDetail.save(cmsMerchantDetails);
			if (cmsMerchantDetails.length == 1) {
				response.setMessage("Merchant Category has been saved.");
			} else if (cmsMerchantDetails.length > 1) {
				response.setMessage("Merchant Categories have been saved.");
			}
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("Data has not been saved.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"merchantCategory/{user}/{groupCode}" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkMerchant(@PathVariable("user") String user, @PathVariable("groupCode") String groupCode) {
		GenericResponse<CmsMerchantDetails> response = new GenericResponse<CmsMerchantDetails>();
		try {
			response.setData(merchantCategoryDetail.getMerchant(user, groupCode));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("no record found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"acquiredNetwork" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> acquiredNetworkDetails(
			@RequestBody CmsAcquiredNetworkRequest[] cmsAcquiredNetworkRequest) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {
			acquiredNetworkDetail.save(cmsAcquiredNetworkRequest);
			response.setMessage("Acquired network is sucessfully saved.");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("Error occured while saving Acquired network.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getallacquiredNetwork" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getAcquiredNetworkDetails() {
		GenericResponse<List<CmsAcquiringNetworkGroup>> response = new GenericResponse<List<CmsAcquiringNetworkGroup>>();
		try {
			response.setData(acquiredNetworkDetail.getAllCmsAcquiredNetwork());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"getallacquiredNetwork/{user}/{parameter}" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkAcquiredNetworkDetails(@PathVariable("user") String user,@PathVariable("parameter") String parameter) {
		GenericResponse<CmsAcquiringNetworkGroup> response = new GenericResponse<CmsAcquiringNetworkGroup>();
		try {
			response.setData(acquiredNetworkDetail.checkAllCmsAcquiredNetwork(user, parameter));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getMerchantMCCGroup" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getMerchantMCCGroup() {
		GenericResponse<List<CmsMerchantMccGroup>> response = new GenericResponse<List<CmsMerchantMccGroup>>();
		try {
			response.setData(merchantCategoryDetail.getAll());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getDeliveryChannel" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getDeliveryChannel() {
		GenericResponse<List<CmsDeliveryChannel>> response = new GenericResponse<List<CmsDeliveryChannel>>();
		try {
			response.setData(usageService.getAll());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getAcquiredNetworkType" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getAcquiredNetworkType() {
		GenericResponse<List<CmsNetworkType>> response = new GenericResponse<List<CmsNetworkType>>();
		try {
			response.setData(acquiredNetworkDetail.getAll());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = {
			"getAcquiredNetworkId" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getAcquiredNetworkId() {
		GenericResponse<List<CmsAcquiredNetworkId>> response = new GenericResponse<List<CmsAcquiredNetworkId>>();
		try {
			response.setData(acquiredNetworkDetail.getAllDetail());
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}
	@CrossOrigin("*")
	@RequestMapping(value = "viewAcquiringNetwork/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> chekAcquiringNetwork(@PathVariable("user") String user) {
		GenericResponse<List<CmsAcquiringNetworkGroup>> response = new GenericResponse<>();
		try {			 
			 List<CmsAcquiringNetworkGroup> cmsAcquiringNetworkGroup = usageService.getAcquiredNetworkGroup(user);
			response.setData(cmsAcquiringNetworkGroup);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "viewCardUsageSetting/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> viewCardUsageSetting(@PathVariable("user") String user) {
		GenericResponse<List<CmsCardUsage>> response = new GenericResponse<>();
		try {			 
			 List<CmsCardUsage> cmsCardUsage = usageService.viewCardUsageSetting(user);
			response.setData(cmsCardUsage);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	@CrossOrigin("*")
	@RequestMapping(value = "viewMerchantCategory/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> viewMerchantCategory(@PathVariable("user") String user) {
		GenericResponse<List<CmsMerchantDetails>> response = new GenericResponse<>();
		try {			 
			 List<CmsMerchantDetails> cmsMerchantDetails = usageService.viewMerchantCategory(user);
			response.setData(cmsMerchantDetails);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	@CrossOrigin("*")
	@RequestMapping(value = "viewLimitManagement/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> viewLimitManagement(@PathVariable("user") String user) {
		GenericResponse<List<CmsMLimitManagement>> response = new GenericResponse<>();
		try {			 
			 List<CmsMLimitManagement> cmslimitManagementDetails = usageService.viewLimitManagementDetails(user);
			response.setData(cmslimitManagementDetails);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = "viewFeeManagement/{user}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> viewFeeManagement(@PathVariable("user") String user) {
		GenericResponse<List<CmsFeeManagement>> response = new GenericResponse<>();
		try {			 
			 List<CmsFeeManagement> cmsFeeManagementDetails = usageService.viewFeeManagementDetails(user);
			response.setData(cmsFeeManagementDetails);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
}
