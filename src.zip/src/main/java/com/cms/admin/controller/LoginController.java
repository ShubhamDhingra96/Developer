package com.cms.admin.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.AESUtil;
import com.cms.admin.api.DES_Encryption_Decryption;
import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CMS_Message;
import com.cms.admin.bean.CmsClientLoginRequest;
import com.cms.admin.bean.DashboardFunction;
import com.cms.admin.bean.DashboardMenu;
import com.cms.admin.bean.DashboardSubMenu;
import com.cms.admin.bean.DashboardSubmenuSubmenu;
import com.cms.admin.bean.DashbordFunctionJobs;
import com.cms.admin.bean.LoginBean;
import com.cms.admin.bean.OAuthResponse;
import com.cms.admin.bean.ResetPassword;
import com.cms.admin.email.EmailInsert;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsMJobsMapping;
import com.cms.admin.entity.CmsMModules;
import com.cms.admin.entity.CmsPreviliges;
import com.cms.admin.service.CmsClientLoginService;
import com.cms.admin.service.CmsClientService;
import com.cms.admin.utility.Bcrypt;
import com.cms.admin.utility.Password_Generator;
import com.cms.admin.utility.Utility;
import com.google.gson.Gson;

import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@RestController
@RequestMapping(value = "default")
public class LoginController {

	@Value("${encryption.key}")
	private String ENCRYPTION_KEY;

	@Autowired
	private com.cms.admin.api.AES_Encryption_Descryption aes_encryption;

	@Autowired
	private CmsClientLoginService loginService;

	@Autowired
	private CmsClientService cmsClientService;

	@Autowired
	private EmailInsert emailInsert;

	@Value("${server.auth.url}")
	private String OAUTHURL;

	@Value("${server.auth.token}")
	private String OAUTHCREDENTIALS;

	@Value("${server.auth.granttype}")
	private String GRANT_TYPE;

	@Autowired
	private Utility utility;

	@Autowired
	private AESUtil aesUtil;

	@Autowired
	DES_Encryption_Decryption aes;

	@CrossOrigin("*")
	@RequestMapping(value = "login", method = RequestMethod.POST, consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> login(@org.springframework.web.bind.annotation.RequestBody String jsonlogin) {
		Gson g = new Gson();

		LoginBean login = g.fromJson(aes_encryption.decrypt(jsonlogin.toString(), ENCRYPTION_KEY), LoginBean.class);

		OkHttpClient client = new OkHttpClient();
		String response = null;
		Integer code = null;
		OAuthResponse authResponse = new OAuthResponse();
		System.out.println(OAUTHURL);
		System.out.println(OAUTHCREDENTIALS);
		System.out.println(GRANT_TYPE);
		System.out.println(login.getUsername());
		System.out.println(login.getPassword());
		System.out.println(client);
		System.out.println("_________");
		try {
			response = post(OAUTHURL, OAUTHCREDENTIALS, GRANT_TYPE, login.getUsername(), login.getPassword(), client);
			try {
				System.out.println("Response >>>>>>>>>>>>" + response);
				Object jsonParse = new JSONParser().parse(response);
				JSONObject jsonObject = (JSONObject) jsonParse;

				Map message = ((Map) jsonObject.get("message"));
				Iterator<Map.Entry> keys = message.entrySet().iterator();

				while (keys.hasNext()) {
					Map.Entry pair = keys.next();
					switch (pair.getKey().toString()) {
					case "access_token":
						authResponse.setAccess_token(pair.getValue().toString());
						break;
					case "token_type":
						authResponse.setToken_type(pair.getValue().toString());
						break;
					case "refresh_token":
						authResponse.setRefresh_token(pair.getValue().toString());
						break;
					case "expires_in":
						authResponse.setExpires_in(Integer.parseInt(pair.getValue().toString()));
						break;
					case "scope":
						authResponse.setScope(pair.getValue().toString());
						break;
					case "jti":
						authResponse.setJti(pair.getValue().toString());
						break;
					case "error":
						authResponse.setError(pair.getValue().toString());
						break;
					case "error_description":
						authResponse.setError_description(pair.getValue().toString());
						break;
					default:
						break;
					}
				}
				code = Integer.parseInt(jsonObject.get("code").toString());

			} catch (ParseException e) {
				e.printStackTrace();
				CMS_Message error = new CMS_Message("SERVER ERROR  Unable to process request.", 500, null, null, null);
				return new ResponseEntity<>(error, HttpStatus.valueOf(500));
			}
		} catch (Exception e) {
			e.printStackTrace();
			response = null;
			CMS_Message error = new CMS_Message("SERVER ERROR  Unable to process request.", 500, null, null, null);
			return new ResponseEntity<Object>(error, HttpStatus.valueOf(500));
		}

		if (null == code || code != 200) {
			CMS_Message error = new CMS_Message("Invalid Credentials", code, null, null, null);
			return new ResponseEntity<>(error, HttpStatus.valueOf(code));
		} else {
			CMS_Message success = new CMS_Message(login.getUsername(), code, authResponse.getAccess_token(),
					authResponse.getRefresh_token(), null);
			List<Object> loginuserList = new ArrayList<>();
			loginuserList.add(loginService.setLoginUser(loginService.get(login.getUsername())));
			success.setLoginUser(loginuserList);
			return new ResponseEntity<>(success, HttpStatus.valueOf(code));

		}

	}

	private String post(String oauthurl, String auth, String grant_type, String username, String password,
			OkHttpClient client) throws IOException {

		HttpUrl.Builder urlBuilder = HttpUrl.parse(oauthurl).newBuilder();
		urlBuilder.addQueryParameter("grant_type", grant_type);
		urlBuilder.addQueryParameter("username", username);
		urlBuilder.addQueryParameter("password", password);
		String url = urlBuilder.build().toString();

		RequestBody body = new FormBody.Builder().build();
		Request request = new Request.Builder().url(url).post(body).addHeader("Authorization", auth).build();
		Response response = null;
		try {

			System.out.println("C URL : " + request.url().toString());

			response = client.newCall(request).execute();
			return "{\"message\":" + response.body().string() + ",\"code\":\"" + response.code() + "\"}";
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/sendResetPasswordLink", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<Object> sendResetPasswordLink(
			@org.springframework.web.bind.annotation.RequestBody ResetPassword resetpassword,
			HttpServletRequest request) throws Exception {
		GenericResponse genericResponse = new GenericResponse();
		CmsClientLogin cmsClientLogin = null;
		if (resetpassword.getUsername() != null) {
			cmsClientLogin = loginService.getClientDetailsByUsername(resetpassword.getUsername());
		} else {
			genericResponse.setMessage("User id does not exist.");
		}
		if (cmsClientLogin != null) {

			CmsClient clientId = cmsClientLogin.getCmsClientId();
			String tokenKey = utility.randomTokenKeyGenerator();
			Date tokenExpiry = utility.getLinkExpiryDate();

			cmsClientLogin.setTokenExpiryDate(tokenExpiry);
			cmsClientLogin.setTokenKey(tokenKey);
			cmsClientLogin.setResetPasswordStatus('0');
			loginService.update(cmsClientLogin);

			try {
				String link = "http://localhost:4200/forget?key=" + tokenKey;
				CmsClient cmsClientdetails = cmsClientService.getClientDetailsbyClientId(clientId.getCmsClientId());

				emailInsert.resetPasswordEmail(link, resetpassword, cmsClientLogin);
				genericResponse.setMessage("Email Sent to registered Email.");
			} catch (Exception e) {
				e.printStackTrace();
				if (e instanceof NullPointerException) {
					genericResponse.setMessage("No email address provided for User : " + resetpassword.getUsername());
					EmailErrorCode emailError = new EmailErrorCode("EmailNull",409);					
					genericResponse.setData(emailError);
					return new ResponseEntity<Object>(genericResponse, HttpStatus.CONFLICT);
				}

			}
		} else {
			genericResponse.setMessage("User id does not exist.");
			genericResponse.setFlag(1);
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Object>(genericResponse, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/validateResetPasswordLink/{key}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> validateResetPasswordLink(@PathVariable("key") String tokenKey,
			HttpServletRequest request) {
		GenericResponse genericResponse = new GenericResponse();
		Date dnow = new Date();
		CmsClientLogin cmsClientLogin = loginService.getClientDetailsByTokenKey(tokenKey);
		Date expirydate = cmsClientLogin.getTokenExpiryDate();
		if (cmsClientLogin != null) {
			if (cmsClientLogin.getResetPasswordStatus().equals('1')) {
				genericResponse.setMessage("Password Already Reset!");
			} else {

				if (expirydate.getTime() >= dnow.getTime()) {
					genericResponse.setMessage(tokenKey);
					genericResponse.setFlag(1);

				} else {
					genericResponse.setMessage("Reset Password Link is Expired!");
					genericResponse.setFlag(0);

				}
			}
		}
		return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.CREATED);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/resetPassword", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> resetPassword(
			@org.springframework.web.bind.annotation.RequestBody ResetPassword resetPassword) {
		GenericResponse genericResponse = new GenericResponse();

		if (resetPassword.getNewPassword() != null && resetPassword.getConfirmPassword() != null) {
			if (resetPassword.getNewPassword().equals(resetPassword.getConfirmPassword())) {
				CmsClientLogin cmsClientLogin = loginService.getClientDetailsByTokenKey(resetPassword.getTokenKey());
				cmsClientLogin.setResetPasswordStatus('1');
				Bcrypt bcrypt = new Bcrypt(resetPassword.getConfirmPassword());
				cmsClientLogin.setPassword("{bcrypt}" + bcrypt.getEncryptPassword());
				loginService.update(cmsClientLogin);
				genericResponse.setMessage("Password reset successfully.");

			} else {
				genericResponse.setMessage("New Password and new password does not match.");
			}
		} else {
			genericResponse.setMessage("New Password or Confirm password are empty");
		}
		return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.CREATED);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/getDashboradMenu", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> getDashboradMenu(
			@org.springframework.web.bind.annotation.RequestBody ResetPassword resetPassword) {
		GenericResponse genericResponse = new GenericResponse();
		try {
			List<CmsMModules> modulelist = loginService.getModules();
			// System.out.println(modulelist.toString());

			List<DashboardMenu> modulesName = new ArrayList<>();

//			for (CmsMModules modules : modulelist) {
//				Dashboard dashbord = new Dashboard();
//				dashbord.setModuleId(modules.getCmsModuleId());
//				dashbord.setModuleName(modules.getCmsModuleName());
//				dashbord.setFunctions(modules.getCmsMFunctionsList());
//				modulesName.add(dashbord);
//
//			}
			for (CmsMModules modules : modulelist) {

				DashboardMenu dashbord = new DashboardMenu();
				dashbord.setmId(null);
				dashbord.setModuleId(modules.getCmsModuleId());
				dashbord.setModuleName(modules.getCmsModuleName());
				dashbord.setClientId(null);
				dashbord.setClientUser(null);
				dashbord.setInsertedBy(null);
				dashbord.setInsertedDate(modules.getInsertedDate());
				dashbord.setModifiedBy(modules.getModifiedBy());
				dashbord.setModifiedDate(modules.getModifiedDate());
				dashbord.setStatus(modules.getStatus());

				List<DashboardSubMenu> cmsmfuctions = new ArrayList<DashboardSubMenu>();
				for (CmsMFunctions func : modules.getCmsMFunctionsList()) {

					DashboardSubMenu cmsMFunctions = new DashboardSubMenu();
					cmsMFunctions.setFunctionId(func.getCmsMFunctionId());
					cmsMFunctions.setFunctionName(func.getCmsMFunctionName());
					cmsMFunctions.setfId(null);
					cmsMFunctions.setInsertedBy(func.getInsertedBy());
					cmsMFunctions.setInsertedDate(func.getInsertedDate());
					cmsMFunctions.setmId(null);
					cmsMFunctions.setModifiedBy(func.getModifiedBy());
					cmsMFunctions.setModifiedDate(func.getModifiedDate());
					cmsMFunctions.setStatus((null == func.getStatus()) ? Character.MIN_VALUE : func.getStatus());

					List<DashboardSubmenuSubmenu> cmsJobs = new ArrayList<>();
					for (CmsMJobsMapping job : func.getCmsMJobsMappingList()) {

						DashboardSubmenuSubmenu cmsjob = new DashboardSubmenuSubmenu();
						cmsjob.setJobUrl(job.getJOB_URL());
						cmsjob.setfId(null);
						cmsjob.setInsertedBy(job.getInsertedBy());
						cmsjob.setInsertedDate(job.getInsertedDate());
						cmsjob.setjId(null);
						cmsjob.setJobId(job.getCmsMJobs().getJobId());
						cmsjob.setJobName(job.getCmsMJobs().getJobName());
						cmsjob.setModifiedBy(job.getModifiedBy());
						cmsjob.setModifiedDate(job.getModifiedDate());
						cmsJobs.add(cmsjob);
					}
					cmsMFunctions.setCmsJobsList(cmsJobs);
					cmsmfuctions.add(cmsMFunctions);
				}
				dashbord.setCmsFunctionsList(cmsmfuctions);
				modulesName.add(dashbord);

			}

			genericResponse.setList(modulesName);
			return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(value = "/getDashboradFunctions/{moduleId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> getDashboradFunctions(@PathVariable(name = "moduleId") String moduleId) {
		GenericResponse genericResponse = new GenericResponse();

		List<CmsMFunctions> functionlist = loginService.getModuleFunctions(moduleId);

		List<DashboardFunction> functionsName = new ArrayList<>();

		for (CmsMFunctions modules : functionlist) {
			DashboardFunction dashboardFunction = new DashboardFunction();
			dashboardFunction.setFunctionId(modules.getCmsMFunctionId());
			dashboardFunction.setFunctionName(modules.getCmsMFunctionName());

			List<CmsMJobsMapping> cmsMJobsMappings = loginService.getJobMappingDetails(modules.getCmsMFunctionId());

			List<DashbordFunctionJobs> dashbordFunctionJobs = new ArrayList<>();

			for (CmsMJobsMapping jobsMapping : cmsMJobsMappings) {
				DashbordFunctionJobs functionJobs = new DashbordFunctionJobs();
				functionJobs.setJobId(jobsMapping.getJobMappingId());
				functionJobs.setJobName(jobsMapping.getCmsMJobs().getJobName());
				dashbordFunctionJobs.add(functionJobs);
			}
			dashboardFunction.setJobs(dashbordFunctionJobs);
			functionsName.add(dashboardFunction);

		}
		genericResponse.setList(functionsName);
		return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.CREATED);

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")

	@PostMapping(value = "/getFunctionsJobMapping/{functionId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> getFunctionsJobMapping(

			@PathVariable(name = "functionId") String functionId) {
		GenericResponse genericResponse = new GenericResponse();

		List<CmsMJobsMapping> functionlist = loginService.getJobMappingDetails(functionId);

		List<String> list = new ArrayList<String>();

		for (CmsMJobsMapping modules : functionlist) {

			list.add(modules.getCmsMJobs().getJobName());

		}
		genericResponse.setList(list);
		return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.CREATED);

	}

	@CrossOrigin("*")
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> save(
			@org.springframework.web.bind.annotation.RequestBody CmsClientLoginRequest request) {
		GenericResponse<CmsClientLogin> genericResponse = new GenericResponse<>();

		try {
			CmsClientLogin cmsClient = new CmsClientLogin();
			CmsPreviliges previliges = new CmsPreviliges();
			previliges.setPermissionId("P0000");
			previliges.setPermissionName("GRANTALL");
			previliges.setPermissionDesc("GRANT ALL");
			cmsClient.setCmsClientId(request.getCmsClient());
			cmsClient.setInsertedBy(request.getUser());
			cmsClient.setInsertedDate(null);
			cmsClient.setIsAdmin("Y");
			cmsClient.setIsClient("N");
			cmsClient.setIsUser("N");
			cmsClient.setModifiedBy(null);
			cmsClient.setModifiedDate(null);
			cmsClient.setPassword(Password_Generator.getInitialPassword(12));
			cmsClient.setPasswordStatus("-1");
			cmsClient.setPermissionId(previliges);
			cmsClient.setUsername(request.getUserID());
			cmsClient.setCity(request.getCity());
			cmsClient.setCountry(request.getCountry());
			cmsClient.setCurrencyAgent(request.getCurrencyAgent());
			cmsClient.setDesignation(request.getDesignation());
			cmsClient.setEmail(request.getEmail());
			cmsClient.setEmployeeNo(request.getEmployeeNo());
			cmsClient.setExpiryDate(request.getExpiryDate());
			cmsClient.setFaxno(request.getFaxno());
			cmsClient.setFirstName(request.getFirstName());
			cmsClient.setLastName(request.getLastName());
			cmsClient.setMobile(request.getMobile());
			cmsClient.setPostCode(request.getPostCode());
			cmsClient.setRegion(request.getRegion());
			cmsClient.setState(request.getState());
			cmsClient.setTelephoneOff(request.getTelephoneOff());
			cmsClient.setTelephoneRes(request.getTelephoneRes());
			cmsClient.setAccountLockFlag(1);
			loginService.save(cmsClient);

			genericResponse.setMessage("User is saved.");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.OK);
		} catch (Exception e) {
			genericResponse.setMessage("Error occured while saving User details.");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "getusersAll", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllUsers() {
		return new ResponseEntity<Object>(loginService.getAllSuperAdminUser(), HttpStatus.OK);
	}

	@CrossOrigin("*")
	@RequestMapping(value = "get", method = RequestMethod.POST, consumes = MediaType.TEXT_PLAIN_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getUser(@org.springframework.web.bind.annotation.RequestBody String username) {
		GenericResponse<String> response = new GenericResponse<String>();
		try {
			CmsClientLogin login = loginService.get(username);
			if (login == null) {
				response.setMessage("User does not exist.");
				return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
			}
			login.setPasswordHistories(null);

			return new ResponseEntity<Object>(login, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("User does not exist.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = "update", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getUser(@org.springframework.web.bind.annotation.RequestBody CmsClientLogin login) {
		try {
			String status = login.getPasswordStatus();
			login = loginService.get(login.getUsername());
			login.setPasswordStatus(status);
			loginService.update(login);
			GenericResponse<String> response = new GenericResponse<String>();
			response.setMessage("User is updated");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(new CmsClientLogin(), HttpStatus.OK);
		}

	}

	@CrossOrigin("*")
	@RequestMapping(value = "getAllUsers", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getAllUserss() {
		GenericResponse<CmsClientLogin> response = new GenericResponse<CmsClientLogin>();
		try {
			List<CmsClientLogin> login = new ArrayList<>();
			for (CmsClientLogin clientLogin : loginService.getAll()) {
				clientLogin.setPasswordHistories(null);
				login.add(clientLogin);
			}
			response.setList(login);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	class EmailErrorCode {
		private String errorName;
		private Integer errorCode;

		
		
		public EmailErrorCode(String errorName, Integer errorCode) {
			
			this.errorName = errorName;
			this.errorCode = errorCode;
		}

		public void setErrorCode(Integer errorCode) {
			this.errorCode = errorCode;
		}

		public void setErrorName(String errorName) {
			this.errorName = errorName;
		}

		public Integer getErrorCode() {
			return errorCode;
		}

		public String getErrorName() {
			return errorName;
		}
	}

}
