package com.cms.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsMBin;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.service.BinSetupService;

@RequestMapping("/binSetup")
@Controller
public class BinSetupController {

	@Autowired
	BinSetupService binService;

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/addBinData", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> saveUser(@RequestBody CmsMBin bean) {
		GenericResponse response = new GenericResponse();
		try {

			response = binService.addBinData(bean);
			response.setMessage("Bin Setup add successfully.");
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {
			exception.printStackTrace();
			response.setMessage("Error occured while saving Bin setup.");
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBinDataList", method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> getBinDataList(@RequestBody CmsBinRequest bean) {
		GenericResponse response = new GenericResponse();
		try {
			response = binService.getBinDataList(bean);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			response.setMessage("No records found.");
			return new ResponseEntity<GenericResponse>(response, HttpStatus.BAD_REQUEST);
		}

	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "check/{user}/{groupCode}", method = RequestMethod.GET,
	consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getBinDataList(
			@PathVariable("user") String user, @PathVariable("groupCode") String groupCode) {
		GenericResponse<CmsBin> response = new GenericResponse<>();
		try {
	        response.setData(binService.getBin(user, groupCode));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getCurrencyData", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinCurrencyList() {

		GenericResponse response = new GenericResponse();
		try {
			response = binService.getBinCurrency();
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {

			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSpecificBinSetupDetails/{clientId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getSpecificPlasticProductList(@PathVariable String clientId) {
		GenericResponse response = new GenericResponse();
		try {
			response = binService.getBinsetupByClientId(clientId);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}
}
