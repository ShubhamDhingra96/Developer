package com.cms.admin.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.DashboardMenu;
import com.cms.admin.bean.DashboardSubMenu;
import com.cms.admin.bean.DashboardSubmenuSubmenu;
import com.cms.admin.bean.RolesBean;
import com.cms.admin.entity.CmsFunctions;
import com.cms.admin.entity.CmsJobs;
import com.cms.admin.entity.CmsModules;
import com.cms.admin.service.AccessRightsService;
import com.cms.admin.utility.IsChecked;

@RestController
@RequestMapping("accessrights")
public class AccessRightController {
	
	@Autowired
	private AccessRightsService service;

	@CrossOrigin("*")
	@RequestMapping(value = "/save", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public ResponseEntity<Object> save(@RequestBody RolesBean beans) {
		GenericResponse<List<DashboardMenu>> response = new GenericResponse<List<DashboardMenu>>();
		try {
			
			response.setData(this.service.saveAccessRights(beans));
			response.setMessage("Data saved successfully");
			response.setFlag(0);
			return new ResponseEntity<Object>(response,HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			response.setFlag(1);
			response.setMessage("Error while saving data.");
			return new ResponseEntity<Object>(response,HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping(value = "/menu/{username}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> menu(@PathVariable("username") String username) {
		GenericResponse genericResponse = new GenericResponse();
		try {
			List<CmsModules> modulelist = service.getMenu(username);
			List<DashboardMenu> modulesName = new ArrayList<>();
			
			for (CmsModules modules : modulelist) {
			
				DashboardMenu dashbord = new DashboardMenu();
				dashbord.setmId(modules.getmId());
				dashbord.setModuleId(modules.getModuleId());
				dashbord.setModuleName(modules.getModuleName());
				dashbord.setClientId(modules.getClientId());
				dashbord.setClientUser(modules.getClientUser());
				dashbord.setInsertedBy(modules.getInsertedBy());
				dashbord.setInsertedDate(modules.getInsertedDate());
				dashbord.setModifiedBy(modules.getModifiedBy());
				dashbord.setModifiedDate(modules.getModifiedDate());
				dashbord.setStatus(modules.getStatus());
				dashbord.setIsChecked((modules.getIsChecked()==IsChecked.TRUE)?true:false);
				
				List<DashboardSubMenu> cmsmfuctions = new ArrayList<DashboardSubMenu>();
				for(CmsFunctions func :modules.getCmsFunctionsList()) {
					
					DashboardSubMenu cmsMFunctions = new DashboardSubMenu();
					cmsMFunctions.setFunctionId(func.getFunctionId());
					cmsMFunctions.setFunctionName(func.getFunctionName());
					cmsMFunctions.setfId(func.getfId());
					cmsMFunctions.setInsertedBy(func.getInsertedBy());
					cmsMFunctions.setInsertedDate(func.getInsertedDate());
					cmsMFunctions.setmId(func.getmId());
					cmsMFunctions.setModifiedBy(func.getModifiedBy());
					cmsMFunctions.setModifiedDate(func.getModifiedDate());
					cmsMFunctions.setStatus(func.getStatus());
					cmsMFunctions.setIsChecked((func.getIsChecked()==IsChecked.TRUE)?true:false);
					List<DashboardSubmenuSubmenu> cmsJobs = new ArrayList<>();
					for(CmsJobs job:func.getCmsJobsList()) {
						
						DashboardSubmenuSubmenu cmsjob = new DashboardSubmenuSubmenu();
						cmsjob.setJobUrl(job.getJobUrl());
						cmsjob.setfId(job.getfId());
						cmsjob.setInsertedBy(job.getInsertedBy());
						cmsjob.setInsertedDate(job.getInsertedDate());
						cmsjob.setjId(job.getjId());
						cmsjob.setJobId(job.getJobId());
						cmsjob.setJobName(job.getJobName());
						cmsjob.setModifiedBy(job.getModifiedBy());
						cmsjob.setModifiedDate(job.getModifiedDate());
						cmsjob.setIsChecked((job.getIsChecked()==IsChecked.TRUE)?true:false);
						cmsJobs.add(cmsjob);
					}
					cmsMFunctions.setCmsJobsList(cmsJobs);
					cmsmfuctions.add(cmsMFunctions);
				}
				dashbord.setCmsFunctionsList(cmsmfuctions);
				modulesName.add(dashbord);

			}

			genericResponse.setList(modulesName);
			return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.OK);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new ResponseEntity<GenericResponse>(genericResponse, HttpStatus.BAD_REQUEST);
		}
	}

}
