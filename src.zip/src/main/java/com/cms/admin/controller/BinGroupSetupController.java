package com.cms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.service.BinGroupService;

@RequestMapping("/binGroupSetup")
@RestController
public class BinGroupSetupController {

	@Autowired
	BinGroupService binGroupService;

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/addBinGroupSetup", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> saveBinGroup(@RequestBody BinGroupSetupBin bean) {
		GenericResponse response = new GenericResponse();
		try {
			response = binGroupService.addBinGroupData(bean);			
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			exception.printStackTrace();
			return new ResponseEntity<GenericResponse>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getPlasticProductList", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getPlasticProductList() {
		GenericResponse response = new GenericResponse();
		try {
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getCmsBinList/{binNumber}", method = RequestMethod.POST)
	public ResponseEntity<GenericResponse> getCmsBinList(@PathVariable("binNumber") String binNumber) {
		GenericResponse response = new GenericResponse();
		try {
			System.out.println("bin number in controller..." + binNumber);
			if (binNumber != null) {
				response = binGroupService.getCmsBinDetails(binNumber);
			} else {
				response.setMessage("Bin number is Null");
			}
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {

			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "check/{user}/{binGroupCode}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> checkCmsBinGroup(@PathVariable("user") String user,
			@PathVariable("binGroupCode") String binGroupCode) {
		GenericResponse<CmsBinGroup> response = new GenericResponse<>();
		try {
			response.setData(binGroupService.getCmsBinGroupDetails(user, binGroupCode));
			return new ResponseEntity<Object>(response, HttpStatus.CREATED);

		} catch (Exception exception) {
			response.setMessage("No records available.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getPlasticCodelist", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getPlasticCodelist() {
		GenericResponse response = new GenericResponse();
		try {
			System.out.println("getPlasticCodelist...");
			response = binGroupService.getPlasticCodelist();
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {

			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBinGroupSetUpDetails", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinGroupSetUpDetails() {
		GenericResponse response = new GenericResponse();
		try {
			System.out.println("getBinGroupSetUpDetails...");
			response = binGroupService.getBinGroupSetUpDetails();
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {

			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/addBinGroupData", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<GenericResponse> addBinGroupData(@RequestBody BinGroupSetupBin bean) {
		GenericResponse response = new GenericResponse();

		try {
			
			response = binGroupService.addBinGroupData(bean);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {

			exception.printStackTrace();
			return new ResponseEntity<GenericResponse>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getBinGroupcodeDetails/{groupCode}", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinGroupcodeDetails(@PathVariable("groupCode") String groupCode) {
		GenericResponse response = new GenericResponse();
		try {
			System.out.println("bin group code in controller..." + groupCode);
			response = binGroupService.getCmsBinGroupDetails(groupCode);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);

		} catch (Exception exception) {

			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}

	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSpecificBinGroupDetails/{clientId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getSpecificPlasticProductList(@PathVariable String clientId) {
		GenericResponse response = new GenericResponse();
		try {
			response = binGroupService.getBinGroupByClientId(clientId);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"getBinGroup/{user}" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getBinGroup(@PathVariable("user") String user) {
		GenericResponse<List<CmsBinGroup>> response = new GenericResponse<List<CmsBinGroup>>();
		try {
			response.setData(binGroupService.getAll(user));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

}
