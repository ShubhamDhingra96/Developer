package com.cms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsLimitManagement;
import com.cms.admin.service.CmsLimitManagementService;

@RequestMapping(value = { "limit" })
@RestController
public class LimitManagementController {

	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);

	@Autowired
	CmsLimitManagementService cmsLimitManagementService;

	@CrossOrigin("*")
	@PostMapping(value = "/saveLimitDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<Object> saveLimitDetails(@RequestBody CmsLimitManagement[] limitManagement)
			throws Exception {
		GenericResponse<String> response = new GenericResponse<>();
		try {

		CmsLimitManagement limit = null;
		for (CmsLimitManagement management : limitManagement) {
			String limitCode = cmsLimitManagementService.saveLimitDetails(management);
			
		}
		response.setMessage("Limit Details saved sucessfully.");
		return new ResponseEntity<Object>(response, HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error occured while saving  Limit Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getLimitDetails", produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<List<CmsLimitManagement>> getLimitDetails() throws Exception {
		logger.info("In Get Limit Details.");
		List<CmsLimitManagement> limitManagements = cmsLimitManagementService.getLimitDetails();
		logger.info("In Get Limit Details :: " + limitManagements.size());
		return new ResponseEntity<List<CmsLimitManagement>>(limitManagements, HttpStatus.CREATED);
	}

	@CrossOrigin("*")
	@GetMapping(value = "getLimitDetails/{user}/{limitcode}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<Object> checkLimitCode(@PathVariable("user") String user,
			@PathVariable("limitcode") String limitCode) throws Exception {
		GenericResponse<Object> response = new GenericResponse<>();
		try {
			response.setData(cmsLimitManagementService.getLmitDetailByCode(user, limitCode));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}

	@CrossOrigin("*")
	@PutMapping(value = "/updateLimitDetails", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<CmsLimitManagement> updateBinDetails(@RequestBody CmsLimitManagement limitManagement)
			throws Exception {
		CmsLimitManagement result = cmsLimitManagementService.updateLimitDetails(limitManagement);
		return new ResponseEntity<CmsLimitManagement>(limitManagement, HttpStatus.CREATED);
	}

	@CrossOrigin("*")
	@GetMapping(value = "/getLimitDetails/{limitCode}", produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<CmsLimitManagement> getBinDetails(@PathVariable String limitCode) throws Exception {
		logger.info("In Get Limit Details By Limit code: " + limitCode);
		CmsLimitManagement details = cmsLimitManagementService.getLmitDetailByCode(limitCode);
		logger.info("In Get Limit Details By Limit Code: " + details.toString());
		return new ResponseEntity<CmsLimitManagement>(details, HttpStatus.CREATED);
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getTransactionData", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinCurrencyList() {
		GenericResponse response = new GenericResponse();
		try {
			response = cmsLimitManagementService.geTransactionType();
			System.out.println("Response.." + response);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

}
