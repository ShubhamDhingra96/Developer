package com.cms.admin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.TransactionGroup;
import com.cms.admin.entity.CmsTransactionGrouping;
import com.cms.admin.service.TransactionGroupService;

@RequestMapping(value = { "transaction" })
@RestController
public class TransactionGroupController {

	@Autowired
	TransactionGroupService transactionGroupService;

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getTransaction", method = RequestMethod.GET)
	public ResponseEntity<GenericResponse> getBinCurrencyList() {
		GenericResponse response = new GenericResponse();
		try {
			response = transactionGroupService.geTransactionType();
			System.out.println("Response.." + response);
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		} catch (Exception exception) {
			return new ResponseEntity<GenericResponse>(response, HttpStatus.CREATED);
		}
	}

	@CrossOrigin("*")
	@PostMapping(value = "/saveTransactionGroup", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<Object> saveTransactionGroup(@RequestBody TransactionGroup[] transactionGroup) throws Exception {
		GenericResponse<String> response = new GenericResponse<>();
		try {
			System.out.println("Transaction group details..." + transactionGroup);
			TransactionGroup limit = null;
			for (TransactionGroup transaction : transactionGroup) {
				String transactioncode = transactionGroupService.saveTransactionGrouping(transaction);
			}
			response.setMessage("Transaction Details saved sucessfully.");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error occured while saving transaction Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin("*")
	@RequestMapping(value = "/getTransactionGrouping", method = RequestMethod.GET)
	//@GetMapping(value = "/getTransactionGrouping", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, headers = "Accept=application/json;charset=UTF-8")
	public ResponseEntity<Object> getTransactionGroupingDeatils() throws Exception {
		GenericResponse response = new GenericResponse();
		try {

			response = transactionGroupService.getTransactionGroupDetails();
			response.setMessage("Getting transaction details sucessfully.");
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error occured while saving transaction Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "checkTransactionCode/{user}/{groupCode}", method = RequestMethod.GET,
	consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getBinDataList(
			@PathVariable("user") String user, @PathVariable("groupCode") String groupCode) {
		GenericResponse<CmsTransactionGrouping> response = new GenericResponse<>();
		try {
	        response.setData(transactionGroupService.getTransactionCode(user, groupCode));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/getSpecificTransactionGroupDetails/{clientId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getSpecificPlasticProductList(@PathVariable String clientId) {
		GenericResponse response = new GenericResponse();
		try {
			response = transactionGroupService.getTransactionCodeByClientId(clientId);
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception exception) {
			exception.getStackTrace();
			response.setMessage("No records found.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}

	}
	
}
