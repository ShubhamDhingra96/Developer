package com.cms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.bean.CmsCountriesStatesCitiesResponse;
import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;
import com.cms.admin.service.CountriesStatesCitiesService;

@RestController
@RequestMapping("location")
public class CountriesStatesCitiesController {
	
	
	@Autowired
	private CountriesStatesCitiesService service;
	
	@CrossOrigin("*")
	@RequestMapping(value= {"yourLocation/{countryid}"},consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
	public ResponseEntity<Object> getLocation(@PathVariable("countryid") Long countryid){
		try {
			CmsCountriesStatesCitiesResponse response = new CmsCountriesStatesCitiesResponse();
			List<CmsStates> states=service.getStatesByCountryid(countryid);
			response.setStates(states);
			return new ResponseEntity<Object>(response,HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(null,HttpStatus.BAD_REQUEST);
		}
		
	}
	@CrossOrigin("*")
	@RequestMapping(value= {"yourLocation"},consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE,method = RequestMethod.GET)
	public ResponseEntity<Object> getLocation(){
		try {
			CmsCountriesStatesCitiesResponse response = new CmsCountriesStatesCitiesResponse();
			List<CmsCountry> countries=service.getCountry();
			response.setCountries(countries);
			return new ResponseEntity<Object>(response,HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Object>(null,HttpStatus.BAD_REQUEST);
		}
		
	}

}
