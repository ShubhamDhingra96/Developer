package com.cms.admin.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.ProgrammeDefinitionBean;
import com.cms.admin.entity.CmsProgrammeDefinition;
import com.cms.admin.service.ProgrameDefinitionService;

@RequestMapping("/ProgramDefinition")
@RestController
public class ProgrammeDefinitionController {

	
	@Autowired
	ProgrameDefinitionService programService;

	private static Logger logger = LoggerFactory.getLogger(LimitManagementController.class);

	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = "/save", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> saveUser(@RequestBody ProgrammeDefinitionBean[] bean) throws Exception {
		GenericResponse response = new GenericResponse();
		ProgrammeDefinitionBean programcDetails = null;
		try {
			for (ProgrammeDefinitionBean details : bean) {
				programcDetails = programService.saveProductDefinition(details);
			}
			logger.info("In Save or Update status : " + programcDetails);
			response.setMessage("Program Definition Details saved successfully.");
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			response.setMessage("Error while saving Plastic Code Details.");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = {"getAll" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getProgramDefinitionDetails() throws Exception {
		
		  logger.info("In Get CardUsage Details."); 
		  
		  GenericResponse<List<ProgrammeDefinitionBean>> genericResponse =new GenericResponse<>();
		 
		try {
			List<ProgrammeDefinitionBean> programdefinitiondetails = programService.getProgramDefinitionDetails();
			
			logger.info("In Get Limit Details :: " + programdefinitiondetails);
			genericResponse.setData(programdefinitiondetails);
			return new ResponseEntity<Object>(genericResponse, HttpStatus.CREATED);
			
		}catch(Exception exception) {
			logger.error("Error While fetching program definition details");
			genericResponse.setMessage("Error while fetching the Data from database");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}
	}
	@CrossOrigin("*")
	@RequestMapping(value = { "isExist/{programmecode}" })
	public ResponseEntity<Object> isExistDefinitiondetails(@PathVariable("programmecode") String programcode) throws Exception {
		logger.info("in is Exist methos for checking the Data  By Limit code: " + programcode);
		GenericResponse<CmsProgrammeDefinition> genericResponse =new GenericResponse();
		try {

			ProgrammeDefinitionBean programDefinitionDetails = programService.isExistProgramCode(programcode);
	
		logger.info("In is Exist method: " + programDefinitionDetails.toString());
		
		return new ResponseEntity<Object>(genericResponse, HttpStatus.CREATED);
		
		}catch(Exception exception) {
			
			exception.printStackTrace();
			genericResponse.setMessage("No records Available");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}

	}
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@RequestMapping(value = {"getAll/{user}/{programmeCode}" }, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> checkCardUsageDetails(@PathVariable("user") String user,@PathVariable("programmeCode") String programCode) throws Exception {
		GenericResponse<CmsProgrammeDefinition> genericResponse = new GenericResponse<>();
		try {
			genericResponse.setData(programService.getCardUsageDetailsByCode(user, programCode));
			return new ResponseEntity<Object>(genericResponse, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			genericResponse.setMessage("No records available.");
			return new ResponseEntity<Object>(genericResponse, HttpStatus.BAD_REQUEST);
		}
	}
	
	@CrossOrigin("*")
	@RequestMapping(value = {
			"getProgramType/{user}" }, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public ResponseEntity<Object> getProgramType(@PathVariable("user") String username) {
		GenericResponse<List<CmsProgrammeDefinition>> response = new GenericResponse<List<CmsProgrammeDefinition>>();
		try {
			response.setData(programService.getAll(username));
			return new ResponseEntity<Object>(response, HttpStatus.OK);
		} catch (Exception e) {
			response.setMessage("No recored found");
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);

		}

	}

}
