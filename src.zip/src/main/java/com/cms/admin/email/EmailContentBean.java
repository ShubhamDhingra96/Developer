package com.cms.admin.email;


import com.cms.admin.constant.ConfigurationValues;
import com.cms.email.prop.MasterFilePath;
import com.cms.email.prop.PropertyHandler;
import com.cms.admin.service.LoggingService;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class EmailContentBean {

    final static Logger logger =  LoggerFactory.getLogger(EmailContentBean.class);

    private String emailaddress;
    private String pwd;
    
    @Autowired
	private LoggingService loggingService;

    @Autowired
    private ConfigurationValues configurationValues;

    @Value("${mail.host}")
    private String host;

    @Value("${mail.smtp.port}")
    private String port;

    @Value("${mail.smtp.starttls.enable}")
    private String tlsEnable;

    @Value("${mail.smtp.auth}")
    private String auth;

    @Value("${mail.smtp.socketFactory.class}")
    private String socketFactoryClass;

    @Value("${mail.smtp.socketFactory.fallback}")
    private String socketFactoryfallback;

    @Value("${mail.smtp.quitwait}")
    private String quitwait;

    @Value("${mail.debug}")
    private String debug;

    @Value("${mail.store.protocol}")
    private String storeProtocol;

    @Value("${mail.transport.protocol}")
    private String transportProtocol;

    private String timeout;

    private Session mailSession;
    private ArrayList<String> ccEmailAddress;
    private ArrayList<String> bccEmailAddress;
    private String subject;
    private String emailBody;
    private ArrayList<File> listOfAttachements;
    private ArrayList<InlineImage> listOfInlineImages;

    private String fromEmailAddress;
    private ArrayList<String> toEmailAddress;

    public Session getMailSession() {
        return mailSession;
    }

    private void setMailSession(Session mailSession) {
        this.mailSession = mailSession;
    }

    public ArrayList<String> getToEmailAddress() {
        return toEmailAddress;
    }

    public void setToEmailAddress(ArrayList<String> toEmailAddress) {
        this.toEmailAddress = toEmailAddress;
    }

    public ArrayList<InlineImage> getListOfInlineImages() {
        return listOfInlineImages;
    }

    public void setListOfInlineImages(ArrayList<InlineImage> listOfInlineImages) {
        this.listOfInlineImages = listOfInlineImages;
    }

    public String getFromEmailAddress() {
        return fromEmailAddress;
    }

    public void setFromEmailAddress(String fromEmailAddress) {
        this.fromEmailAddress = fromEmailAddress;
    }

    public ArrayList<String> getCcEmailAddress() {
        return ccEmailAddress;
    }

    public void setCcEmailAddress(ArrayList<String> ccEmailAddress) {
        this.ccEmailAddress = ccEmailAddress;
    }

    public ArrayList<String> getBccEmailAddress() {
        return bccEmailAddress;
    }

    public void setBccEmailAddress(ArrayList<String> bccEmailAddress) {
        this.bccEmailAddress = bccEmailAddress;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getEmailBody() {
        return emailBody;
    }

    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    public ArrayList<File> getListOfAttachements() {
        return listOfAttachements;
    }

    public void setListOfAttachements(ArrayList<File> listOfAttachements) {
        this.listOfAttachements = listOfAttachements;
    }

    public void process() {
        ArrayList<File> attachments = new ArrayList<File>();
        setListOfAttachements(attachments);
    }

    //static BaseLogger log = BaseLogger.getInstance("org.apache.log4j");
    public void sendemail() {

        try {
            System.out.println("inside if current_env *********** ");
            PropertyHandler propertyHandler = new PropertyHandler(MasterFilePath.getMasterfilepath());

            String hostProp = propertyHandler.getProperty("CLOVER_TEST_mail.host");

            System.out.println("##############CLOVER_TEST_mail.host: " + hostProp);
            Properties properties = new Properties();

            properties.put("mail.smtp.auth", auth);
            properties.put("mail.smtp.host", host);
            properties.put("mail.smtp.port", port);
            properties.put("mail.transport.protocol", transportProtocol);
            properties.put("mail.smtp.socketFactory.class", socketFactoryClass);

            Authenticator auth = new EmailContentBean.SMTPAuthenticator();
            System.out.println("Authentication Status :: "+auth.toString());
            mailSession = Session.getInstance(properties, auth);
            mailSession.setDebug(true);

            setFromEmailAddress(getFromEmailAddress());
            setMailSession(mailSession);

            MimeMessage msg = new MimeMessage(getMailSession());

            msg.setContent(getEmailBody(), "text/html");
            //msg.setContent(getEmailBody(), "text/text");
            System.out.println("Body=" + getEmailBody());

            BodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setContent(getEmailBody(), "text/html");

            MimeMultipart multipart = new MimeMultipart("related");
            multipart.addBodyPart(messageBodyPart);

            //ArrayList<File> inlinimage=ge
            //see email attachement code is here....
            ArrayList<File> attachments = getListOfAttachements();
            if (attachments != null && attachments.size() != 0) {

                Iterator<File> itr = attachments.iterator();
                while (itr.hasNext()) {
                    File tempFile = itr.next();
                    if (tempFile.isFile()) {
                        MimeBodyPart fileAttachement = new MimeBodyPart();
                        FileDataSource fds = new FileDataSource(tempFile);
                        fileAttachement.setDataHandler(new DataHandler(fds));
                        fileAttachement.setFileName(fds.getName());
                        multipart.addBodyPart(fileAttachement);
                    }
                }
            }

            ////second part (the image)
            /*messageBodyPart = new MimeBodyPart();
             //DataSource fds = new FileDataSource("C:\\images\\avivalogo.gif");
			  
             DataSource fds = new FileDataSource("/AvivaImages/avivalogo.gif");
			  
             System.out.println("<<<----change the path as /images/avivalogo.gif------------------>>>>>>");
             messageBodyPart.setDataHandler(new DataHandler(fds));
             messageBodyPart.setHeader("Content-ID","<image>");

             // add it
             multipart.addBodyPart(messageBodyPart);*/
            // put everything together
            //seting body
            msg.setContent(multipart);

            //seting from email address
            msg.setFrom(new InternetAddress(getFromEmailAddress()));

            int i = 0;

            //new to
            
            String toEmails = getToEmailAddress().toString().replaceAll("[+^]","");
            System.out.println("$$$$$$$$$$" +toEmails);
            
            if (toEmails != null && !toEmails.isEmpty()) {
                toEmails=toEmails.replace("[", "");                
                toEmails=toEmails.replace("]", "");
                toEmails=toEmails.replace(" ", "");
                System.out.println("--------"+toEmails+"----------");
                msg.addRecipients(Message.RecipientType.TO, toEmails);         
            }
            
            i = 0;
            //cc
    /*        List<String> ccEmail = getCcEmailAddress();
            if (ccEmail != null && ccEmail.size() != 0) {

                InternetAddress[] Internetaddress = new InternetAddress[ccEmail.size()];
                Iterator<String> itr = ccEmail.iterator();
                while (itr.hasNext()) {
                    Internetaddress[i] = new InternetAddress(itr.next());
                    msg.setRecipient(Message.RecipientType.CC, Internetaddress[i++]);
                }

            } 
    */
           
            if(getCcEmailAddress() != null){
            System.out.println("_______++++++++++++++++"+getCcEmailAddress().toString());
            String ccEmails = getCcEmailAddress().toString().replaceAll("[+^]","");
            System.out.println("CCC ---- $$$$$$$$$$" +ccEmails);
            if (ccEmails != null && !ccEmails.isEmpty()) {
                ccEmails=ccEmails.replace("[", "");                
                ccEmails=ccEmails.replace("]", "");
                ccEmails=ccEmails.replace(" ", "");
                System.out.println("--------"+ccEmails+"----------");
                 msg.addRecipients(Message.RecipientType.CC, ccEmails);        
            }
            }else {
                System.out.println("No CC email address");
            }
            
            i = 0;
            //bcc
         /*   List<String> bccEmail = getBccEmailAddress();
            if (bccEmail != null && bccEmail.size() != 0) {

                InternetAddress[] Internetaddress = new InternetAddress[bccEmail.size()];
                Iterator<String> itr = bccEmail.iterator();
                while (itr.hasNext()) {
                    Internetaddress[i] = new InternetAddress(itr.next());
                    msg.setRecipient(Message.RecipientType.BCC, Internetaddress[i++]);
                }

            }*/
            
            if(getBccEmailAddress()!= null){
            System.out.println("_______++++++++++++++++"+getBccEmailAddress().toString());
            String bccEmails = getBccEmailAddress().toString().replaceAll("[+^]","");
            System.out.println("CCC ---- $$$$$$$$$$" +bccEmails);
            if (bccEmails != null && !bccEmails.isEmpty()) {
                bccEmails=bccEmails.replace("[", "");                
                bccEmails=bccEmails.replace("]", "");
                bccEmails=bccEmails.replace(" ", "");
                System.out.println("--------"+bccEmails+"----------");
                 msg.addRecipients(Message.RecipientType.BCC, bccEmails);        
            }
            }else {
                System.out.println("No BCC email address");
            }

            msg.setSubject(getSubject());
            msg.setSentDate(new Date());

            if (this.getListOfInlineImages() != null && this.getListOfInlineImages().size() != 0) {

                Iterator<InlineImage> itr = getListOfInlineImages().iterator();
                while (itr.hasNext()) {
                    InlineImage inlineImage = itr.next();
                    messageBodyPart = new MimeBodyPart();
                  
                    DataSource fds = new FileDataSource(inlineImage.getFileObject().getAbsolutePath());

                    messageBodyPart.setDataHandler(new DataHandler(fds));

                    messageBodyPart.setHeader("Content-ID", "<" + inlineImage.getTagName() + ">");

                    messageBodyPart.setHeader("Content-Disposition", "inline");
                    messageBodyPart.setDisposition(MimeBodyPart.INLINE);
                    // add it
                    multipart.addBodyPart(messageBodyPart);
                }

            }
            
            int emailenableflag=configurationValues.getIntegerValues("EMAIL", "EMAIL.ENABLE");
          //  int emailenableflag = 1;
            //  Boolean isEmailDisable=new Boolean(PropertyHandler.getInstance(MasterFilePath.getMasterfilepath()).getProperty("DisableEmailFlag"));
            if (emailenableflag == 1) {
                Transport.send(msg);
            } else if (emailenableflag == 1) {

            }

        } catch (MessagingException me) {
        	System.out.println("In Send mail exception Start");
    		loggingService.saveExceptionLog("sendmail", loggingService.stackTraceToString(me), "Error while sending email to customer.", "", "", "", "");
          //  me.printStackTrace(System.out);
    		System.out.println("In Send mail exception End");
        }

    }

    private class SMTPAuthenticator extends javax.mail.Authenticator {

        String accontEmailid = configurationValues.getStringValues("EMAIL", "EMAIL.SEND_EMAIL_ADDRESS");
       // String pwd = configurationValues.getEncryptedValues("EMAIL", "EMAIL.SEND_EMAIL_PWD");
        String pwd = configurationValues.getStringValues("EMAIL", "EMAIL.SEND_EMAIL_PWD");
     
        @Override
        public PasswordAuthentication getPasswordAuthentication() {
        	   System.out.println(accontEmailid+" >> "+pwd);
            return new PasswordAuthentication(accontEmailid, pwd); // password not displayed here, but gave the right password in my actual code.
        }

    }

}
