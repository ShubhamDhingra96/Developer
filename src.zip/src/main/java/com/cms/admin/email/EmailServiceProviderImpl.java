package com.cms.admin.email;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class EmailServiceProviderImpl  {
 
@Autowired    
EmailContentBean emailContentBean;
	/*
	 * ****************************************************************
	 *  PARAMETER STRUTURE TO BE FOLLOWED for ARRAYLIST to be passed in METHOD sendemail
	 * ******************************************************************
	 * input ArrayList
	 * 0 - eventId
	 * 1 - from email address
	 * 2 - Arraylist of TO email addresses
	 * 3 - Arraylist of CC email addresses
	 * 4 - Arraylist of BCC email addresses 
	 * 5 - String of Subject
	 * 6 - String of Body
	 * 7 - ArrayList of File attachements
	 * 8 - ArrayList of Inline Images
	 * ******************************************************************
	 */	
public void sendemail(ArrayList  input)
 {
	System.out.println("in EmailServiceProviderImpl");

	 emailContentBean.setFromEmailAddress((String)input.get(1));
	 emailContentBean.setToEmailAddress((ArrayList)input.get(2));
	 emailContentBean.setCcEmailAddress((ArrayList)input.get(3));
	 emailContentBean.setBccEmailAddress((ArrayList)input.get(4));
	 emailContentBean.setSubject((String)input.get(5));
	 emailContentBean.setEmailBody((String)input.get(6));
	 
	 
	 emailContentBean.setListOfAttachements((ArrayList)input.get(9));
   
	 System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
	 System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
	 
	emailContentBean.sendemail();
	 
 }
}
