/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.admin.email;

import com.cms.admin.bean.ResetPassword;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.EmailComponentMaster;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

/**
 *
 * @author Administrator
 */
@Component
public class EmailInsert {

    private static Logger logger = LoggerFactory.getLogger(EmailInsert.class);

    
    @Autowired
    EmailConfigurationDAOImpl emailConfigurationDAOImpl;
     
    @Autowired
    EmailProcessorImpl emailProcessorImpl;
    
    @Autowired
    EmailSend emailSend;
    
    
    
    public EmailConfigurationDAOImpl getEmailConfigurationDAOImpl() {
		return emailConfigurationDAOImpl;
	}


	public void setEmailConfigurationDAOImpl(EmailConfigurationDAOImpl emailConfigurationDAOImpl) {
		this.emailConfigurationDAOImpl = emailConfigurationDAOImpl;
	}


	public void sendOtpEmail(String toMail, String otp) {

        System.out.println("sendOtpEmail getEmailotp");
        EmailComponentMaster emailconfigurationBean = null;
        ArrayList details1 = null;
        try {

            emailconfigurationBean = emailConfigurationDAOImpl.findEventConfiguration("ECOLLECTION_EXC");
            System.out.println("emailconfigurationBean output" + emailconfigurationBean);
            Map<String, String> subject = new HashMap<String, String>();
            Map<String, String> body1 = new HashMap<String, String>();
            subject.put("Subject", "otp");

            ArrayList attachements = new ArrayList();
            body1.put("image", "<img height=\"100\" width=\"100\" src=\"cid:image1\">");
            body1.put("EmployeeName", "User");
            body1.put("OTP", otp);
            body1.put("timeout", "30");
            System.out.println("emailconfigurationBean.getEventid" + emailconfigurationBean.getEventId());

            /**
             *
             * input ArrayList 
             * 0 - eventId 
             * 1 - to email addresss 
             * 2 - Arraylist of parameters for subject 
             * 3 - Arraylist of parameters for body 
             * 4 - Arraylist of files for attachement
             *
             */
            
            ArrayList details = new ArrayList();
            details.add(emailconfigurationBean.getEventId());//0
            details.add(toMail);//1
            details.add(subject);//2
            details.add(body1);//3
            details.add(attachements);//4
            System.out.println("details" + details);
            emailProcessorImpl.saveEmail(details, emailconfigurationBean.getEventId());           
          
        } catch (Exception e) {

            System.out.println("Exception" + e);
            e.printStackTrace();
        }

    }

    
    public void resetPasswordEmail(String link, ResetPassword resetpassword,CmsClientLogin cmsClientLogin) throws Exception {
         
    	EmailComponentMaster emailconfigurationBean = null;
        ArrayList details1 = null;
//        try {
        	
            emailconfigurationBean = emailConfigurationDAOImpl.findEventConfiguration("ResetPassword");
            System.out.println("emailconfigurationBean output " + emailconfigurationBean);
            Map<String, String> subject = new HashMap<String, String>();
            Map<String, String> body1 = new HashMap<String, String>();
            subject.put("Subject" , emailconfigurationBean.getSubject());
            ArrayList attachements = new ArrayList();
            attachements.add(new File("D:\\BDO1.jpg"));
            body1.put("link", link);
            body1.put("username", resetpassword.getUsername());
           // String toMail = emailconfigurationBean.getEmailTo();
            //System.out.println("TO mail.."+toMail);
            String toMail = cmsClientLogin.getEmail();
           
            System.out.println("emailconfigurationBean.getEventid" + emailconfigurationBean.getEventId());

            /**
             *
             * input ArrayList 
             * 0 - eventId 
             * 1 - to email addresss 
             * 2 - Arraylist of parameters for subject 
             * 3 - Arraylist of parameters for body 
             * 4 - Arraylist of files for attachement
             *
             */
            
            
            ArrayList details = new ArrayList();
            details.add(emailconfigurationBean.getEventId());//0
            details.add(toMail);//1
            details.add(subject);//2
            details.add(body1);//3
            details.add(attachements);
            System.out.println("details" + details);
            emailProcessorImpl.saveEmail(details, emailconfigurationBean.getEventId());
            
            emailSend.getDetailsEmail();
            
        /*} catch (Exception e) {

            System.out.println("Exception" + e);
            e.printStackTrace();
        }*/

    }
    
}
