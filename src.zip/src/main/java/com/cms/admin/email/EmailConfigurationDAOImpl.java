package com.cms.admin.email;



import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.entity.EmailComponentMaster;

@Repository
@Transactional
public class EmailConfigurationDAOImpl {
	

    private static Logger logger =  LoggerFactory.getLogger(EmailConfigurationDAOImpl.class);

    @Autowired
    private SessionFactory sessionFactory;
     

    public EmailComponentMaster findEventConfiguration(String emailEventName) {
        
        System.out.println("In findEventConfiguration...."+emailEventName);
        EmailComponentMaster emailComponentmaster = new EmailComponentMaster();
        try {
            Query q = sessionFactory.getCurrentSession().createQuery("from EmailComponentMaster where emailEventMaster.emailEventName=:emailEventName");
            q.setString("emailEventName", emailEventName);
            emailComponentmaster = (EmailComponentMaster) q.uniqueResult();
            System.out.println("emailComponentmaster..."+emailComponentmaster.getEmailFrom());
        } catch (Exception e) {
            System.out.println("findEventConfiguration exception " + e);           
            e.printStackTrace();
        }
        return emailComponentmaster;
    }

    public EmailComponentMaster findByID(Long id) {

        EmailComponentMaster emailcomponentmaster = new EmailComponentMaster();
        try {
            Query q = sessionFactory.getCurrentSession().createQuery("from EmailComponentMaster where eventId=:eventId");
            q.setParameter("eventId", id.intValue());
            emailcomponentmaster = (EmailComponentMaster) q.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return emailcomponentmaster;
    }
    
    


}
