package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsMerchantGroupRequest;
import com.cms.admin.entity.CmsMccGroupCode;
import com.cms.admin.entity.CmsMerchantDetails;
import com.cms.admin.entity.CmsMerchantMccGroup;

public interface MerchantCategoryDetail {

	public CmsMerchantGroupRequest[] save(CmsMerchantGroupRequest[] cmsMerchantDetails);

	public CmsMerchantDetails update(CmsMerchantDetails cmsMerchantDetails);

	public CmsMerchantDetails delete(CmsMerchantDetails cmsMerchantDetails);

	public List<CmsMerchantMccGroup> getAll();

	public List<CmsMccGroupCode> getAllDetail();

	public CmsMerchantDetails getMerchant(String username, String groupCode);

}