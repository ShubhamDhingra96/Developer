package com.cms.admin.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.dao.CmsCardUsageDao;
import com.cms.admin.entity.CmsCardUsage;

@Service
@Transactional
public class CmsCardUsageServiceImpl implements CmsCardUsageService {

	@Autowired
	private CmsCardUsageDao cmscardusagedao;

	@Override
	public CmsCardUsageBean saveCmsCardUsageBean(CmsCardUsageBean cmscardusagebean) {
		try {
			CmsCardUsage cmscardusageentity = new CmsCardUsage();
			cmscardusageentity.setInsertedBy(cmscardusagebean.getInsertedBy());
			cmscardusageentity.setInsertedOn(Calendar.getInstance().getTime());
			cmscardusageentity.setGroupCode(cmscardusagebean.getCardUsageGroupCode());
            cmscardusageentity.setGroupName(cmscardusagebean.getCardUsageGroupName());
            cmscardusageentity.setStatus(1);
            cmscardusageentity.setGroupDesc(cmscardusagebean.getCardUsageGroupDesc());
            cmscardusageentity.setTransactionAmount(cmscardusagebean.getCardUsageGrouptransactionAmount());

			CmsCardUsage newcmscardusage = cmscardusagedao.saveCmsCardUsageDetails(cmscardusageentity);

			return cmscardusagebean;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<CmsCardUsageBean> getCmsCardUsageDetails() {
		try {
			List<CmsCardUsage> entitylist = cmscardusagedao.getCmsCardUsageDetails();
			List<CmsCardUsageBean> beanlist = new ArrayList<CmsCardUsageBean>();
			for (CmsCardUsage cardusagelist : entitylist) {
				CmsCardUsageBean usagebean = new CmsCardUsageBean();
				usagebean.setInsertedDate(cardusagelist.getInsertedOn());
				usagebean.setInsertedBy(cardusagelist.getInsertedBy());
				usagebean.setModifiedBy(cardusagelist.getModifyBy());
				usagebean.setModifiedDate(cardusagelist.getModifyOn());
				usagebean.setCardUsageGroupCode(cardusagelist.getGroupCode());
				usagebean.setCardUsageGroupName(cardusagelist.getGroupName());
				usagebean.setCardUsageGroupDesc(cardusagelist.getGroupDesc());
				usagebean.setStatus(cardusagelist.getStatus());
				usagebean.setCardUsageGrouptransactionAmount(cardusagelist.getTransactionAmount());
				beanlist.add(usagebean);
			}

			return beanlist;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsCardUsageBean updateCardUsageDetails(CmsCardUsageBean cmscardusagebean) {
		CmsCardUsage cmscardusageentity = new CmsCardUsage();

		cmscardusageentity.setInsertedBy(cmscardusagebean.getInsertedBy());
		cmscardusageentity.setInsertedOn(Calendar.getInstance().getTime());
		cmscardusageentity.setModifyBy(cmscardusagebean.getModifiedBy());
		cmscardusageentity.setModifyOn(Calendar.getInstance().getTime());
		cmscardusagebean.setCardUsageGroupCode(cmscardusagebean.getCardUsageGroupCode());
		cmscardusageentity.setGroupName(cmscardusagebean.getCardUsageGroupName());
		cmscardusageentity.setStatus(1);
		cmscardusageentity.setGroupDesc(cmscardusagebean.getCardUsageGroupDesc());
		cmscardusageentity.setTransactionAmount(cmscardusagebean.getCardUsageGrouptransactionAmount());

		CmsCardUsage newcmscardusage = cmscardusagedao.updateCardUsageDetails(cmscardusageentity);

		return cmscardusagebean;
	}

	@Override
	public CmsCardUsageBean getCardUsageDetailsByCode(String groupcode) {
		try {
			
			CmsCardUsage cmscardusage = cmscardusagedao.getCardUsageDetailsByCode(groupcode);
			CmsCardUsageBean cmscardusagebean = new CmsCardUsageBean();
			cmscardusagebean.setInsertedDate(cmscardusage.getInsertedOn());
			cmscardusagebean.setInsertedBy(cmscardusage.getInsertedBy());
			cmscardusagebean.setCardUsageGroupCode(cmscardusage.getGroupCode());
			cmscardusagebean.setCardUsageGroupDesc(cmscardusage.getGroupDesc());
			cmscardusagebean.setCardUsageGroupName(cmscardusage.getGroupName());
			cmscardusagebean.setModifiedBy(cmscardusage.getModifyBy());
			cmscardusagebean.setModifiedDate(cmscardusage.getModifyOn());
			cmscardusagebean.setCardUsageGrouptransactionAmount(cmscardusage.getTransactionAmount());

			return cmscardusagebean;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsCardUsage getCardUsageDetailsByCode(String username, String groupcode) {
		// TODO Auto-generated method stub
		return cmscardusagedao.getCardUsageDetailsByCode(username, groupcode);
	}
}