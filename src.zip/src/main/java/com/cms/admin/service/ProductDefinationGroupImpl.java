package com.cms.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.CmsProductDefinationRequest;
import com.cms.admin.dao.ProductDefinationGroupDao;
import com.cms.admin.entity.ProductTypeDefinition;

@Service
@Transactional
public class ProductDefinationGroupImpl implements ProductDefinationGroup {

	@Autowired
	ProductDefinationGroupDao groupDao;

	@Override
	public ProductTypeDefinition saveDetail(CmsProductDefinationRequest productTypeDefinition) {
		
		ProductTypeDefinition group = new ProductTypeDefinition();
		group.setApplicationType(productTypeDefinition.getApplicationType());
		group.setBinCurrency(productTypeDefinition.getBinCurrency());
		group.setBinGroup(productTypeDefinition.getBinGroup());
		group.setBinRangeFrom(productTypeDefinition.getBinRangeFrom());
		group.setBinRangeTo(productTypeDefinition.getBinrangeTo());
		group.setCardActivationGroup(productTypeDefinition.getCardActivationGroupAdd().toString());
		group.setCardEmbossingEncode(productTypeDefinition.getCardEmbossing());
		group.setCardExpiryMethod(productTypeDefinition.getCardExpiryMethod());
		group.setCardGenerationMethod(productTypeDefinition.getCardGenerationMethod());
		group.setDeliveryMethod(productTypeDefinition.getDeliverMethod());
		group.setEmbossingTemplate(productTypeDefinition.getEmbossingTemplateId());
		group.setExpiryPeriod(productTypeDefinition.getVariableExpiryPeriod());
		group.setExpiryPeriodMonths(productTypeDefinition.getExpiryMonth());
		group.setInertedDate(productTypeDefinition.getInsertedDate());
		group.setInsertedBy(productTypeDefinition.getInsertedBy());
		group.setIssuingCurrency(productTypeDefinition.getCountryCurrencyListDB().toString());
		group.setModifiedBy(productTypeDefinition.getModifiedBy());
		group.setModifiedDate(productTypeDefinition.getModifiedDate());
		group.setPinDeliveryMethod(productTypeDefinition.getPinDeliveryMethod());
		group.setPintryLimit(productTypeDefinition.getPinTryLimit().toString());
		group.setPlasticCode(productTypeDefinition.getPlasticCodeAdd().toString());
		group.setProductCode(productTypeDefinition.getProductCode());
		group.setProductCurrency(productTypeDefinition.getProductCurrency());
		group.setProductCurrencyDescription(productTypeDefinition.getCurrencyDescription());
		group.setProductDescription(productTypeDefinition.getProductDescription());
		group.setProductName(productTypeDefinition.getProductName());
		group.setProductPairCards(productTypeDefinition.getPairCards());
		group.setProductProgram(productTypeDefinition.getProgramType());
		group.setProductProgramDescription(productTypeDefinition.getProgramDescription());
		group.setReplacementTemplate(productTypeDefinition.getReplacementTemplateId());
		group.setServiceCode(productTypeDefinition.getServiceCode());
		group.setWelcomeTemplate(productTypeDefinition.getWelcomeTemplate());
		group.setBinGroupDescription(productTypeDefinition.getBinGroupDescription());
		group.setProgramCode(productTypeDefinition.getProgramCode());
		groupDao.saveDetail(group);
		return group;
	}

	@Override
	public List<ProductTypeDefinition> getAll(String username) {
		
		return groupDao.getAll(username);
	}

}
