package com.cms.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.dao.CountriesStatesCitiesDao;
import com.cms.admin.entity.CmsCities;
import com.cms.admin.entity.CmsCountries;
import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;

@Service
@Transactional
public class CountriesStatesCitiesServiceImpl implements CountriesStatesCitiesService {

	@Autowired
	private CountriesStatesCitiesDao dao;

	@Override
	public CmsCountries getCountries(Number countryid) {
		// TODO Auto-generated method stub
		return dao.getCountries(countryid);
	}

	@Override
	public CmsStates getStates(Long stateId) {
		// TODO Auto-generated method stub
		return dao.getStates(stateId);
	}

	@Override
	public CmsCities getCities(Long cityid) {
		// TODO Auto-generated method stub
		return dao.getCities(cityid);
	}

	@Override
	public List<CmsStates> getStatesByCountryid(Long countryid) {
		// TODO Auto-generated method stub
		return dao.getStatesByCountryid(countryid);
	}

	@Override
	public List<CmsCities> getCitiesByStateid(Long stateid) {
		// TODO Auto-generated method stub
		return dao.getCitiesByStateid(stateid);
	}

	@Override
	public List<CmsCountries> getCountries() {
		// TODO Auto-generated method stub
		return dao.getCountries();
	}

	@Override
	public List<CmsCountry> getCountry() {
		// TODO Auto-generated method stub
		return dao.getCountry();
	}

}
