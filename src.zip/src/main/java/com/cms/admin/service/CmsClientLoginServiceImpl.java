package com.cms.admin.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.UserDeniedAuthorizationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.bean.CmsClientLoginRequest;
import com.cms.admin.bean.CmsClientRegisterRequest;
import com.cms.admin.dao.CmsClientDao;
import com.cms.admin.dao.CmsClientLoginDao;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsLoginPrivledges;
import com.cms.admin.entity.CmsPreviliges;
import com.cms.admin.exception.AccountNotActivated;
import com.cms.admin.utility.Password_Generator;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsMJobs;
import com.cms.admin.entity.CmsMJobsMapping;
import com.cms.admin.entity.CmsMModules;
import com.cms.admin.entity.CmsPreviliges;
import com.cms.admin.utility.Password_Generator;

@Service
@Transactional
public class CmsClientLoginServiceImpl implements CmsClientLoginService, UserDetailsService {

	@Autowired
	private CmsClientLoginDao clientLoginDao;
	
	@Autowired
	private CmsClientDao clientDao;

	@Override
	public CmsClientLogin save(CmsClient client) throws ParseException {
		CmsClientLogin cmsClientLogin = new CmsClientLogin();
		cmsClientLogin.setUsername(client.getCmsClientId());
		cmsClientLogin.setCmsClientId(client);
		cmsClientLogin.setInsertedBy(client.getInsertedBy().getUsername());
		cmsClientLogin.setInsertedDate(getDate("yyyy-MM-dd"));
		cmsClientLogin.setIsAdmin("Y");
		cmsClientLogin.setIsClient("N");
		cmsClientLogin.setIsUser("N");
		cmsClientLogin.setModifiedBy(client.getInsertedBy().getUsername());
		cmsClientLogin.setModifiedDate(getDate("yyyy-MM-dd"));
		cmsClientLogin.setPassword(Password_Generator.getInitialPassword(12));
		cmsClientLogin.setPasswordStatus("-1");
		cmsClientLogin.setPermissionId(client.getModifiedBy().getPermissionId());
		return clientLoginDao.save(cmsClientLogin);
	}

	private Date getDate(String pattern) throws ParseException {
		return new SimpleDateFormat(pattern).parse(new SimpleDateFormat(pattern).format(new Date()));
	}

	@Override
	public CmsClientLogin update(CmsClientLogin cmsClientLogin) {
		return clientLoginDao.update(cmsClientLogin);
	}

	@Override
	public CmsClientLogin get(CmsClientLogin cmsClientLogin) {
		return clientLoginDao.get(cmsClientLogin);
	}

	@Override
	public CmsClientLogin get(String username) {
		return clientLoginDao.get(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// username=username.toLowerCase();
		// if (username.startsWith("CMSU".toLowerCase())) {
		CmsClientLogin user = clientLoginDao.get(username);
		if (user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
//		if (user.getCmsClientId().getCmsCompanyStatus().equals("-1")) {
//			throw new AccessDeniedException("You do'nt have access to login.");
//		}
//		if (user.getPasswordStatus().equals("-1")) {
//			throw new UserDeniedAuthorizationException("Change password");
//		}
		Collection<CmsPreviliges> role = new ArrayList<CmsPreviliges>();
		role.add(user.getPermissionId());
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), mapRolesToAuthorities(role));

		// }
		// else if (username.startsWith("CMSC".toLowerCase())) {
//			CmsCustomer customer = dao.get(username);
//			if (customer == null) {
//				throw new UsernameNotFoundException("Invalid username or password.");
//			}
//			Collection<CmsRolesEntity> role = new ArrayList<CmsRolesEntity>();
//			role.add(customer.getRoles());
//			return new org.springframework.security.core.userdetails.User(customer.getCmsUserName(),
//					customer.getPassword(), mapRolesToAuthorities(role));

		// }
//		else {
//			throw new UsernameNotFoundException("Invalid username or password.");
//		}

	}

	private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<CmsPreviliges> roles) {
		return roles.stream().map(role -> new SimpleGrantedAuthority(role.getPermissionId()))
				.collect(Collectors.toList());
	}

	@Override
	public CmsClientLoginRequest setLoginUser(CmsClientLogin loginUser) {
		CmsClientLoginRequest loginRequestUser = new CmsClientLoginRequest();
//		loginRequestUser.setPasswordStatus(loginUser.getPasswordStatus());
//		loginRequestUser.setCmsClientId(loginUser.getCmsClientId().getCmsClientId());
//		loginRequestUser.setInsertedBy(loginUser.getInsertedBy());
//		loginRequestUser.setInsertedDate(loginUser.getInsertedDate());
//		loginRequestUser.setIsAdmin(loginUser.getIsAdmin());
//		loginRequestUser.setIsClient(loginUser.getIsClient());
//		loginRequestUser.setIsUser(loginUser.getIsUser());
//		loginRequestUser.setModifiedBy(loginUser.getModifiedBy());
//		loginRequestUser.setModifiedDate(loginUser.getModifiedDate());
//		loginRequestUser.setPermissionId(loginUser.getPermissionId().getPermissionId());
//		loginRequestUser.setUsername(loginUser.getUsername());
		return loginRequestUser;
	}

	@Override
	public CmsClientLogin getClientDetailsByUsername(String username) {
		// TODO Auto-generated method stub
		return clientLoginDao.getClientDetailsByUsername(username);
	}

	@Override
	public CmsClientLogin getClientDetailsByTokenKey(String tokenKey) {
		// TODO Auto-generated method stub
		return clientLoginDao.getClientDetailsByTokenKey(tokenKey);
	}


	@Override
	public List<CmsMModules> getModules() {
		// TODO Auto-generated method stub
		return clientLoginDao.getModules();
	}

	@Override
	public List<CmsMFunctions> getModuleFunctions(String moduleId) {
		// TODO Auto-generated method stub
		return clientLoginDao.getModuleFunctions(moduleId);
	}

	@Override
	public List<CmsMJobsMapping> getJobMappingDetails(String functionId) {
		// TODO Auto-generated method stub
		return clientLoginDao.getJobMappingDetails(functionId);
	}

	@Override
	public List<CmsMJobs> getJobsName(List<CmsMJobs> jobId) {
		// TODO Auto-generated method stub
		return clientLoginDao.getJobsName(jobId);
	}

	@Override
	public CmsClientLogin save(CmsClientLogin client) {
		client=clientLoginDao.save(client);
				
		clientDao.update(client.getCmsClientId().getCmsClientId());
		return client;
	}

	@Override
	public List<CmsClientLogin> getAllSuperAdminUser() {
		// TODO Auto-generated method stub
		List<CmsClientLogin> logins=new ArrayList<>();
		for(CmsClientLogin login:clientLoginDao.getAllSuperAdminUser()) {
			login.setPasswordHistories(null);
			logins.add(login);
		}
		return logins;
	}

	@Override
	public List<CmsClientLogin> getAll() {
		// TODO Auto-generated method stub
		return clientLoginDao.getAll();
	}

}
