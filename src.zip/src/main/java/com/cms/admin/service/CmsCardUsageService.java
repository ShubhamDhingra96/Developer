package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.entity.CmsCardUsage;

public interface CmsCardUsageService {

	public CmsCardUsageBean saveCmsCardUsageBean(CmsCardUsageBean cmscardusagebean);
	
	public List<CmsCardUsageBean> getCmsCardUsageDetails();
	
	public CmsCardUsageBean updateCardUsageDetails(CmsCardUsageBean cmscardusagebean);
	
	public CmsCardUsageBean getCardUsageDetailsByCode(String groupcode); 
	
	public CmsCardUsage getCardUsageDetailsByCode(String username,String groupcode); 

	
}
