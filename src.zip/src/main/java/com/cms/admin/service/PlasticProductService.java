package com.cms.admin.service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.entity.CmsPlasticProductSetup;

public interface PlasticProductService {

	public PlasticProductSetupBean savePlasticSetUp(PlasticProductSetupBean plasticSetup);

	public GenericResponse getPlasticProductList(PlasticProductSetupBean bean) throws Exception;

	public GenericResponse getSpecificPlasticCodeList(String clientId) throws Exception;
	
	public CmsPlasticProductSetup getSpecificPlasticProductList(String clientId, String groupCode) throws Exception;

}
