package com.cms.admin.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinSetupBean;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsMBin;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.dao.BinSetupDao;
import com.cms.admin.dao.PlasticProductDao;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsCurrency;
import com.cms.admin.entity.CmsPlasticProductSetup;

@Service
@Transactional
public class BinSetupServiceImpl implements BinSetupService {

	@Autowired
	BinSetupDao binSetupDao;

	/*
	 * @Override public GenericResponse addBinData(CmsBinRequest bean) throws
	 * Exception {
	 * 
	 * GenericResponse response = new GenericResponse(); Integer i =
	 * binSetupDao.addBin(bean); if (i == 0) {
	 * response.setMessage("Updated Successfully."); } else {
	 * response.setMessage("Submitted Successfully."); } return response; }
	 */

	@Override
	public GenericResponse addBinData(CmsMBin bean) {

		GenericResponse response = new GenericResponse();
		Integer i = binSetupDao.addBin(bean);
		System.out.println("Id in service.." + i);
		if (i == 0) {
			response.setMessage("Updated Successfully.");
		} else {
			response.setMessage("Submitted Successfully.");
		}
		return response;
	}

	@Override
	public GenericResponse getBinDataList(CmsBinRequest bean) throws Exception {
		GenericResponse response = new GenericResponse();
		List<CmsBinRequest> listData = new ArrayList<CmsBinRequest>();
		List<CmsBin> productList = binSetupDao.getBinList(bean);

		if (!productList.isEmpty() && productList.size() > 0) {
			for (CmsBin cmsBin : productList) {
				CmsBinRequest finalResult = new CmsBinRequest();
				finalResult.setBinNumber(cmsBin.getBinNumber());
				finalResult.setCmsBinNumber(cmsBin.getBinNumber().concat("~").concat(cmsBin.getBinDiscription()));
				finalResult.setCmsBinDiscription(cmsBin.getBinDiscription());
				finalResult.setCmsBinCurrency(cmsBin.getBinCurrency());
				finalResult.setCmsSettlementCurrency(cmsBin.getSettlementCurrency());
				finalResult.setCmsBinType(cmsBin.getBinType());
				finalResult.setCmsBinDigit(cmsBin.getBinDigit());
				finalResult.setCmsBinIssuer(cmsBin.getBinIssuer());
				finalResult.setCmsCheckParity(cmsBin.getCheckParity());
				finalResult.setBinSetupId(cmsBin.getBinId().toString());

				listData.add(finalResult);
			}

		}
		response.setList(listData);

		return response;
	}

	@Override
	public GenericResponse getBinCurrency() throws Exception {
		// TODO Auto-generated method stub
		GenericResponse response = new GenericResponse();
		List<CmsBinRequest> binRequests = new ArrayList<>();
		List<CmsCurrency> currency = binSetupDao.getBinCurrency();
		System.out.println("currency list.." + currency);
		for (CmsCurrency binCurrency : currency) {
			CmsBinRequest cmsBinRequest = new CmsBinRequest();
			cmsBinRequest.setCmsBinCurrency(binCurrency.getCurrencyCode());
			binRequests.add(cmsBinRequest);
		}
		response.setList(binRequests);
		return response;
	}

	@Override
	public CmsBin getBin(String user, String groupCode) throws Exception {
		// TODO Auto-generated method stub
		return binSetupDao.getBin(user, groupCode);
	}

	@Override
	public GenericResponse getBinsetupByClientId(String clientId) throws Exception {
		GenericResponse response = new GenericResponse();

		List<CmsBinRequest> listData = new ArrayList<CmsBinRequest>();
		List<CmsBin> productList = binSetupDao.getBinsetupByClientId(clientId);

		if (!productList.isEmpty() && productList.size() > 0) {
			for (CmsBin cmsBin : productList) {

				CmsBinRequest finalResult = new CmsBinRequest();
				finalResult.setBinNumber(cmsBin.getBinNumber());
				finalResult.setCmsBinNumber(cmsBin.getBinNumber().concat("~").concat(cmsBin.getBinDiscription()));
				finalResult.setCmsBinDiscription(cmsBin.getBinDiscription());
				finalResult.setCmsBinCurrency(cmsBin.getBinCurrency());
				finalResult.setCmsSettlementCurrency(cmsBin.getSettlementCurrency());
				finalResult.setCmsBinType(cmsBin.getBinType());
				finalResult.setCmsBinDigit(cmsBin.getBinDigit());
				finalResult.setCmsBinIssuer(cmsBin.getBinIssuer());
				finalResult.setCmsCheckParity(cmsBin.getCheckParity());
				finalResult.setClientId(cmsBin.getClientID());

				listData.add(finalResult);
			}
		}
		response.setList(listData);
		return response;
	}
}
