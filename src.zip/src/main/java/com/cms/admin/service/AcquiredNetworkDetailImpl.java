package com.cms.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.CmsAcquiredNetworkRequest;
import com.cms.admin.dao.AcquiredNetworkDao;
import com.cms.admin.entity.CmsAcquiredNetworkId;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsNetworkType;


@Service
@Transactional
public class AcquiredNetworkDetailImpl implements AcquiredNetworkDetail{
	
    @Autowired
    AcquiredNetworkDao acquiredNetworkDao; 
	
	@Override
	public CmsAcquiredNetworkRequest[] save(CmsAcquiredNetworkRequest[] cmsAcquiredNetworkRequest) {
		for(CmsAcquiredNetworkRequest request : cmsAcquiredNetworkRequest) {
			
			CmsAcquiringNetworkGroup networkRequest = new CmsAcquiringNetworkGroup();
			networkRequest.setGroupCode(request.getGroupCode());
			networkRequest.setInsertedBy(request.getInsertedBy());
			networkRequest.setInsertedDate(request.getInsertedDate());
			networkRequest.setGroupName(request.getGroupName());
			networkRequest.setCountryCode(request.getCountryCode());
			networkRequest.setDeliveryChannel(request.getDeliveryChannel());
			networkRequest.setLocation(request.getLocation());
			networkRequest.setNetworkId(request.getNetworkId());
			networkRequest.setTerminalId(request.getTerminalId());
			networkRequest.setModifiedBy(request.getModifiedBy());
			networkRequest.setModifiedDate(request.getModifiedDate());
			networkRequest.setGroupDescription(request.getGroupDescription());
			networkRequest.setNetworkType(request.getNetworkType());
			networkRequest.setDeliveryChannelName(request.getDeliveryChannelName());
			networkRequest.setMerchantId(request.getMerchantId());
			 acquiredNetworkDao.saveDetail(networkRequest);
		}
		
		return cmsAcquiredNetworkRequest;
	}

	@Override
	public CmsAcquiredNetworkRequest update(CmsAcquiredNetworkRequest cmsAcquiredNetworkRequest) {
		
		return null;
	}

	@Override
	public CmsAcquiredNetworkRequest delete(CmsAcquiredNetworkRequest cmsAcquiredNetworkRequest) {
		
		return null;
	}

	@Override
	public List<CmsAcquiringNetworkGroup> getAllCmsAcquiredNetwork() {
		// TODO Auto-generated method stub
		return acquiredNetworkDao.getAllCmsAcquiredNetwork() ;
	}

	@Override
	public List<CmsNetworkType> getAll() {
		
		return acquiredNetworkDao.getAll() ;
	}

	@Override
	public List<CmsAcquiredNetworkId> getAllDetail() {
		return acquiredNetworkDao.getAllDetail();
	}

	@Override
	public CmsAcquiringNetworkGroup checkAllCmsAcquiredNetwork(String user, String groupCode) {
		// TODO Auto-generated method stub
		return acquiredNetworkDao.checkAllCmsAcquiredNetwork(user, groupCode);
	}

}
