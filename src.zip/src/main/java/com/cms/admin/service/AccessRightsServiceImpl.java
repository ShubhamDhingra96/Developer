package com.cms.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.bean.AccessRightsBean;
import com.cms.admin.bean.CmsFunctionsBean;
import com.cms.admin.bean.CmsJobsBean;
import com.cms.admin.bean.DashboardMenu;
import com.cms.admin.bean.DashboardSubMenu;
import com.cms.admin.bean.DashboardSubmenuSubmenu;
import com.cms.admin.bean.RolesBean;
import com.cms.admin.dao.AccessRightsDAO;
import com.cms.admin.entity.CmsFunctions;
import com.cms.admin.entity.CmsJobs;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsModules;
import com.cms.admin.utility.IsChecked;

@Service
@Transactional
public class AccessRightsServiceImpl implements AccessRightsService {

	@Autowired
	private AccessRightsDAO dao;

	@Override
	public List<DashboardMenu> saveAccessRights(RolesBean bean) {

		List<DashboardMenu> modulesName = new ArrayList<>();
		for (AccessRightsBean role : bean.getRoles()) {
			CmsModules modules = new CmsModules();
			modules.setClientId(role.getClientid());
			modules.setClientUser(role.getAssignuser());
			modules.setModuleId(role.getModuleId());
			modules.setModuleName(role.getModuleName());
			modules.setStatus('0');
			modules.setInsertedBy(role.getUser());
			if (null != role.getIsChecked())
				modules.setIsChecked((role.getIsChecked() == true) ? '0' : '1');
			else
				modules.setIsChecked('1');
			modules.setmId(role.getmId());
			modules.setInsertedDate(role.getInsertedDate());
			modules.setModifiedBy(role.getModifiedBy());
			modules.setModifiedDate(role.getModifiedDate());
			if (null != role.getIsChecked() && role.getIsChecked() && null == role.getmId()) {
				modules = dao.save(modules);
			}
			List<DashboardSubMenu> cmsmfuctions = new ArrayList<DashboardSubMenu>();

			for (CmsFunctionsBean function : role.getFunctions()) {

				CmsFunctions functions = new CmsFunctions();
				functions.setFunctionId(function.getCmsMFunctionId());
				functions.setFunctionName(function.getCmsMFunctionName());
				functions.setmId(modules.getmId());
				functions.setStatus('0');
				functions.setInsertedBy(role.getUser());
				if (null != function.getIsChecked())
					functions.setIsChecked((function.getIsChecked()== true) ? '0' : '1');
				else
					functions.setIsChecked('1');
				functions.setfId(function.getfId());
				functions.setInsertedBy(function.getInsertedBy());
				functions.setInsertedDate(function.getInsertedDate());
				functions.setModifiedBy(function.getModifiedBy());
				functions.setModifiedDate(function.getModifiedDate());
				if (null != role.getIsChecked() && role.getIsChecked() && null != function.getIsChecked()
						&& function.getIsChecked() && null == function.getfId()) {
					functions = dao.save(functions);

				}

				List<DashboardSubmenuSubmenu> cmsJobs = new ArrayList<>();

				for (CmsJobsBean jobs : function.getCmsMJobsMappingList()) {
					CmsJobs jobs_ = new CmsJobs();
					jobs_.setJobId(jobs.getJobId());
					jobs_.setJobName(jobs.getJobName());
					jobs_.setJobUrl(jobs.getJobUrl());
					jobs_.setfId(functions.getfId());
					jobs_.setInsertedBy(role.getUser());
					if (null != jobs.getIsChecked())
						jobs_.setIsChecked((jobs.getIsChecked()== true) ? '0' : '1');
					else
						jobs_.setIsChecked('1');
					jobs_.setjId(jobs.getjId());
					jobs_.setInsertedBy(jobs.getInsertedBy());
					jobs_.setInsertedDate(jobs.getInsertedDate());
					jobs_.setModifiedBy(jobs.getModifiedBy());
					jobs_.setModifiedDate(jobs.getModifiedDate());

					try {
						CmsJobs j = dao.get(jobs_);
						if (j == null)
							throw new NullPointerException();
						if (!jobs.getIsChecked() && null != j) {
							dao.delete(j);
						}
					} catch (Exception e) {
						if (null != role.getIsChecked() && role.getIsChecked() && null != function.getIsChecked()
								&& function.getIsChecked() && null != jobs.getIsChecked() && jobs.getIsChecked()
								&& null == jobs.getjId()) {

							jobs_ = dao.save(jobs_);

						}
					}
					DashboardSubmenuSubmenu subsubMenu = job(jobs_);
					cmsJobs.add(subsubMenu);

				}

				try {
					CmsFunctions f = dao.get(functions);
					if (f == null)
						throw new NullPointerException();
					if (!function.getIsChecked() && null != f) {
						dao.delete(f);
					}
				} catch (Exception e) {

				}
				DashboardSubMenu subMenu = function(functions);
				subMenu.setCmsJobsList(cmsJobs);
				cmsmfuctions.add(subMenu);

			}
			try {
				CmsModules m = dao.get(modules);
				if (m == null)
					throw new NullPointerException();
				if (!role.getIsChecked() && null != m) {
					dao.delete(m);
				}
			} catch (Exception e) {

			}
			DashboardMenu menu = roles(modules);
			menu.setCmsFunctionsList(cmsmfuctions);
			modulesName.add(menu);

		}
		return modulesName;
	}

	private DashboardMenu roles(CmsModules modules) {
		DashboardMenu dashbord = new DashboardMenu();
		dashbord.setmId(modules.getmId());
		dashbord.setModuleId(modules.getModuleId());
		dashbord.setModuleName(modules.getModuleName());
		dashbord.setClientId(modules.getClientId());
		dashbord.setClientUser(modules.getClientUser());
		dashbord.setInsertedBy(modules.getInsertedBy());
		dashbord.setInsertedDate(modules.getInsertedDate());
		dashbord.setModifiedBy(modules.getModifiedBy());
		dashbord.setModifiedDate(modules.getModifiedDate());
		dashbord.setStatus(modules.getStatus());
		dashbord.setIsChecked((modules.getIsChecked() == IsChecked.TRUE) ? true : false);
		return dashbord;
	}

	private DashboardSubMenu function(CmsFunctions func) {

		DashboardSubMenu cmsMFunctions = new DashboardSubMenu();
		cmsMFunctions.setFunctionId(func.getFunctionId());
		cmsMFunctions.setFunctionName(func.getFunctionName());
		cmsMFunctions.setfId(func.getfId());
		cmsMFunctions.setInsertedBy(func.getInsertedBy());
		cmsMFunctions.setInsertedDate(func.getInsertedDate());
		cmsMFunctions.setmId(func.getmId());
		cmsMFunctions.setModifiedBy(func.getModifiedBy());
		cmsMFunctions.setModifiedDate(func.getModifiedDate());
		cmsMFunctions.setStatus(func.getStatus());
		cmsMFunctions.setIsChecked((func.getIsChecked() == IsChecked.TRUE) ? true : false);
		return cmsMFunctions;
	}

	private DashboardSubmenuSubmenu job(CmsJobs job) {
		DashboardSubmenuSubmenu cmsjob = new DashboardSubmenuSubmenu();
		cmsjob.setJobUrl(job.getJobUrl());
		cmsjob.setfId(job.getfId());
		cmsjob.setInsertedBy(job.getInsertedBy());
		cmsjob.setInsertedDate(job.getInsertedDate());
		cmsjob.setjId(job.getjId());
		cmsjob.setJobId(job.getJobId());
		cmsjob.setJobName(job.getJobName());
		cmsjob.setModifiedBy(job.getModifiedBy());
		cmsjob.setModifiedDate(job.getModifiedDate());
		cmsjob.setIsChecked((job.getIsChecked() == IsChecked.TRUE) ? true : false);
		return cmsjob;
	}

	@Override
	public List<CmsModules> getMenu(String username) {
		// TODO Auto-generated method stub
		return dao.getMenu(username);
	}

	@Override
	public CmsModules delete(CmsModules modules) {
		// TODO Auto-generated method stub
		return dao.delete(modules);
	}

	@Override
	public CmsFunctions delete(CmsFunctions functions) {
		// TODO Auto-generated method stub
		return dao.delete(functions);
	}

	@Override
	public CmsJobs delete(CmsJobs jobs) {
		// TODO Auto-generated method stub
		return dao.delete(jobs);
	}

	@Override
	public CmsModules get(CmsModules modules) {
		// TODO Auto-generated method stub
		return dao.get(modules);
	}

	@Override
	public CmsFunctions get(CmsFunctions functions) {
		// TODO Auto-generated method stub
		return dao.get(functions);
	}

	@Override
	public CmsJobs get(CmsJobs jobs) {
		// TODO Auto-generated method stub
		return dao.get(jobs);
	}

}
