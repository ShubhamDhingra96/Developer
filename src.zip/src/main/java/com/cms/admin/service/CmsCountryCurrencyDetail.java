package com.cms.admin.service;

import java.util.List;

import com.cms.admin.entity.CmsCountryCurrency;

public interface CmsCountryCurrencyDetail {
	
	public List<CmsCountryCurrency> getAll();

}
