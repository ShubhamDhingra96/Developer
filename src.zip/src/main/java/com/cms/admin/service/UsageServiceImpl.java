package com.cms.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.CmsCountryGroupRequest;
import com.cms.admin.bean.CmsDeliveryChannelRequest;
import com.cms.admin.dao.UsageDao;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsCountryGroup;
import com.cms.admin.entity.CmsDeliveryChannel;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMerchantDetails;

@Service
@Transactional
public class UsageServiceImpl implements UsageService {

	@Autowired
	private UsageDao dao;

	@Override
	public CmsCountryGroup save(CmsCountryGroupRequest cmsCountryGroup) {
		CmsCountryGroup group = new CmsCountryGroup();
		group.setGroupCode(cmsCountryGroup.getGroupCode());
		String list="";
		for(String desc:cmsCountryGroup.getGroupCompanyList()) {
			list+=desc+",";
		}		
		group.setGroupCompanyList(list.substring(1, list.length()-1));
		group.setGroupDescription(cmsCountryGroup.getGroupDescription());
		group.setGroupId(0);
		group.setGroupName(cmsCountryGroup.getGroupName());
		group.setInsertedBy(cmsCountryGroup.getInsertedBy());
		group.setInsertedDate(cmsCountryGroup.getInsertedDate());
		dao.save(group);
		return group;
	}

	@Override
	public CmsCountryGroup update(CmsCountryGroup cmsCountryGroup) {
		// TODO Auto-generated method stub
		return dao.update(cmsCountryGroup);
	}

	@Override
	public CmsCountryGroup getCountryGroup(Integer groupId) {
		// TODO Auto-generated method stub
		return dao.getCountryGroup(groupId);
	}

	@Override
	public CmsDeliveryChannelGroup save(CmsDeliveryChannelGroup cmsDeliveryChannelGroup) {
		// TODO Auto-generated method stub
		return dao.save(cmsDeliveryChannelGroup);
	}

	@Override
	public CmsDeliveryChannelGroup update(CmsDeliveryChannelGroup cmsDeliveryChannelGroup) {
		// TODO Auto-generated method stub
		return dao.update(cmsDeliveryChannelGroup);
	}

	@Override
	public CmsDeliveryChannelGroup getDeliveryChannelGroup(Integer groupId) {
		// TODO Auto-generated method stub
		return dao.getDeliveryChannelGroup(groupId);
	}

	@Override
	public CmsDeliveryChannelGroup save(CmsDeliveryChannelRequest[] cmsDeliveryChannelRequest) {
		// TODO Auto-generated method stub
		for(CmsDeliveryChannelRequest request:cmsDeliveryChannelRequest) {
			CmsDeliveryChannelGroup grp  = new  CmsDeliveryChannelGroup();
			grp.setDeliveryChannel(request.getGroupDeliveryChannel());
			grp.setGroupDescription(request.getGroupDescription());
			grp.setGroupCode(request.getGroupCode());
			grp.setGroupName(request.getGroupName());
			grp.setTransactionChannel(request.getGroupDescription());
			grp.setInsertedBy(request.getInsertedBy());
			grp.setTransactionChannel(request.getGroupTransactionChannel());
			dao.save(grp);
		}
		return null;
	}

	@Override
	public List<CmsCountryGroup> getAllCountryGroup() {
		// TODO Auto-generated method stub
		return dao.getAllCountryGroup();
	}

	@Override
	public List<CmsDeliveryChannelGroup> getAllDeliveryChannelGroup() {
		// TODO Auto-generated method stub
		return dao.getAllDeliveryChannelGroup();
	}

	@Override
	public List<CmsDeliveryChannel> getAll() {
		
		return dao.getAll();
	}

	@Override
	public CmsCountryGroup getCountryGroup(String username, String groupCode) {
		// TODO Auto-generated method stub
		return dao.getCountryGroup(username, groupCode);
	}

	@Override
	public CmsDeliveryChannelGroup getDeliveryChannelGroup(String username, String groupCode) {
		// TODO Auto-generated method stub
		return dao.getDeliveryChannelGroup(username, groupCode);
	}

	@Override
	public List<CmsCountryGroup> getCountryGroup(String username) {
		// TODO Auto-generated method stub
		return dao.getCountryGroup(username);
	}

	@Override
	public List<CmsDeliveryChannelGroup> getDeliveryChannelGroup(String username) {
		// TODO Auto-generated method stub
		return dao.getDeliveryChannelGroup(username);
	}

	@Override
	public List<CmsAcquiringNetworkGroup> getAcquiredNetworkGroup(String username) {
		// TODO Auto-generated method stub
		return dao.getAcquiringNetworkGroup(username);
	}

	@Override
	public List<CmsCardUsage> viewCardUsageSetting(String username) {
		// TODO Auto-generated method stub
		return dao.viewCardUsageSetting(username);
	}

	@Override
	public List<CmsMerchantDetails> viewMerchantCategory(String username) {
		// TODO Auto-generated method stub
		return dao.viewMerchantDetails(username);
	}

	@Override
	public List<CmsMLimitManagement> viewLimitManagementDetails(String username) {
		// TODO Auto-generated method stub
		return dao.viewLimitManagement(username);
	}

	@Override
	public List<CmsFeeManagement> viewFeeManagementDetails(String username) {
		// TODO Auto-generated method stub
		return dao.viewFeeManagement(username);
	}

}
