package com.cms.admin.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.dao.BinGroupDao;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsBinGroup;
import com.cms.admin.entity.CmsPlasticProductSetup;

@Service
@Transactional
public class BinGroupServiceImpl implements BinGroupService {

	@Autowired
	BinGroupDao binGroupDao;

	@Override
	public GenericResponse getBinGroupList(BinGroupSetupBin bean) throws Exception {
		GenericResponse response = new GenericResponse();
		List<CmsBinRequest> listData = new ArrayList<CmsBinRequest>();
		response.setList(listData);

		return response;
	}

	@Override
	public GenericResponse getCmsBinDetails(String binNumber) throws Exception {
		GenericResponse response = new GenericResponse();

		try {
			List<CmsBinRequest> listData = new ArrayList<CmsBinRequest>();
			CmsBin cmBinList = binGroupDao.getCmsBinDetails(binNumber);
			if (cmBinList != null) {
				CmsBinRequest cmsBinRequest = new CmsBinRequest();
				cmsBinRequest.setCmsBinDiscription(cmBinList.getBinDiscription());
				cmsBinRequest.setCmsBinCurrency(cmBinList.getBinCurrency());
				cmsBinRequest.setCmsSettlementCurrency(cmBinList.getSettlementCurrency());
				cmsBinRequest.setCmsBinrangeFrom(cmBinList.getBinNumber());
				cmsBinRequest.setCmsBinrangeTo(cmBinList.getBinNumber());
				response.setData(cmsBinRequest);
			} else {
				response.setMessage("Bin list is Null");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;

	}

	@Override
	public GenericResponse getPlasticCodelist() throws Exception {
		GenericResponse response = new GenericResponse();
		try {
			List<CmsBinRequest> listData = new ArrayList<CmsBinRequest>();
			List<CmsPlasticProductSetup> cmBinList = binGroupDao.getPlasticCodelist();
			System.out.println("cmBinList.." + cmBinList);
			for (CmsPlasticProductSetup cmsPlasticProductSetup : cmBinList) {
				CmsBinRequest cmsBinRequest = new CmsBinRequest();
				cmsBinRequest.setPlasticCode(cmsPlasticProductSetup.getPlasticCode()
						+ "-".concat(cmsPlasticProductSetup.getPlasticDescription()));
				listData.add(cmsBinRequest);
			}
			response.setList(listData);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return response;
	}

	@Override
	public GenericResponse getBinGroupSetUpDetails() throws Exception {
		GenericResponse response = new GenericResponse();
		List<BinGroupSetupBin> listData = new ArrayList<BinGroupSetupBin>();
		List<CmsBinGroup> cmBinList = binGroupDao.getBinGroupSetUpDetails();
		for (CmsBinGroup cmsPlasticProductSetup : cmBinList) {

			System.out.println("cmsPlasticProductSetup transaction currency...."
					+ cmsPlasticProductSetup.getTransactionSettlementCurrency());
			BinGroupSetupBin cmsBinRequest = new BinGroupSetupBin();
			
			cmsBinRequest.setGroupCode(cmsPlasticProductSetup.getBinGroupCode());
			cmsBinRequest.setBinGroupName(cmsPlasticProductSetup.getBinGroupName());
			cmsBinRequest.setBinGroupDescription(cmsPlasticProductSetup.getBinGroupDesc());
			cmsBinRequest.setBinSettlement(cmsPlasticProductSetup.getTransactionSettlementCurrency());
			listData.add(cmsBinRequest);
		}
		response.setList(listData);
		return response;
	}

	@Override
	public GenericResponse addBinGroupData(BinGroupSetupBin bean) throws Exception {
		
		GenericResponse response = new GenericResponse();
		String settlrCurrency = "";
		String plasticCode = "";
		CmsBinGroup binGroup = new CmsBinGroup();
		CmsBin mbin = new CmsBin();
		mbin.setBinNumber(bean.getBinRangeFrom());
		try {
			if (bean.getBinGroupid() == null || bean.getBinGroupid() == 0) {
				
				binGroup.setBinGroupCode(bean.getGroupCode());
				binGroup.setBinGroupDesc(bean.getBinDesc());
				binGroup.setBinGroupName(bean.getBinGroupName());
				binGroup.setBinId(Long.valueOf(bean.getBin()));
				// binGroup.setBinId(bean.get);
				for (String str : bean.getTransactionSettlementCurrency()) {
					settlrCurrency = settlrCurrency + str + ",";

				}

				binGroup.setTransactionSettlementCurrency(settlrCurrency.substring(0, settlrCurrency.length() - 1));
				binGroup.setBinDesc(bean.getBinDesc());
				binGroup.setBinCurrency(bean.getBinCurrency());
				binGroup.setBinSettlementCurrency(bean.getBinSettlement());
				binGroup.setBinSettlementType(bean.getBinSettlementType());
				binGroup.setBinRnangeFrom(bean.getBinRangeFrom());
				binGroup.setBinRangeTo(bean.getBinRangeTo());
				binGroup.setTotalNumber(bean.getTotalNumberOfCards());
				binGroup.setInsertedBy(bean.getInsertedBy());
				binGroup.setInsertedDate(bean.getInsertedDate());
				binGroup.setModifiedBy(bean.getModifiedBy());
				binGroup.setModifiedDate(bean.getModifiedDate());
				binGroup.setClientID(bean.getInsertedBy());
				for (String str : bean.getPlasticCode()) {
					plasticCode = plasticCode + str + ",";

				}
				binGroup.setPlasticCode(plasticCode.substring(0, plasticCode.length() - 1));

				Integer i = binGroupDao.addBinGroup(binGroup);
				
				response.setMessage("Submitted Successfully.");
				
			} else {
				

				binGroup.setBinGroupId(bean.getBinGroupid());
				binGroup.setBinGroupCode(bean.getGroupCode());
				binGroup.setBinGroupDesc(bean.getBinDesc());
				binGroup.setBinGroupName(bean.getBinGroupName());
				for (String str : bean.getTransactionSettlementCurrency()) {
					settlrCurrency = settlrCurrency + str + ",";

				}

				binGroup.setTransactionSettlementCurrency(settlrCurrency.substring(0, settlrCurrency.length() - 1));
				binGroup.setBinDesc(bean.getBinDesc());
				binGroup.setBinCurrency(bean.getBinCurrency());
				binGroup.setBinSettlementCurrency(bean.getBinSettlement());
				binGroup.setBinSettlementType(bean.getBinSettlementType());
				binGroup.setBinRnangeFrom(bean.getBinRangeFrom());
				binGroup.setBinRangeTo(bean.getBinRangeFrom());
				binGroup.setTotalNumber(bean.getTotalNumberOfCards());
				binGroup.setModifiedBy(bean.getModifiedBy());
				binGroup.setModifiedDate(bean.getModifiedDate());
				for (String str : bean.getPlasticCode()) {
					plasticCode = plasticCode + str + ",";

				}
				binGroup.setPlasticCode(plasticCode.substring(0, plasticCode.length() - 1));

				Integer i = binGroupDao.addBinGroup(binGroup);
				response.setMessage("Updated Successfully.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.setMessage("Error occured while saving Bin group.");
		}
		return response;
	}

	@Override
	public GenericResponse getCmsBinGroupDetails(String groupCode) throws Exception {
		GenericResponse response = new GenericResponse();
		try {
			List<BinGroupSetupBin> listData = new ArrayList<BinGroupSetupBin>();
			CmsBinGroup cmBinList = binGroupDao.getCmsBinGroupDetails(groupCode);
			System.out.println("cmBinList bin id.." + cmBinList.getBinId());

			BinGroupSetupBin cmsBinRequest = new BinGroupSetupBin();
			cmsBinRequest.setBinGroupid(cmBinList.getBinGroupId());
			cmsBinRequest.setBinGroupDescription(cmBinList.getBinGroupDesc());
			cmsBinRequest.setBinGroupName(cmBinList.getBinGroupName());
			// cmsBinRequest.setSelectBin(String.valueOf(cmBinList.getBinId().getBinId()));
			cmsBinRequest.setSelectBin(String.valueOf(cmBinList.getBinId()));
			cmsBinRequest.setBinDesc(cmBinList.getBinDesc());
			cmsBinRequest.setBinCurrency(cmBinList.getBinCurrency());
			cmsBinRequest.setBinSettlement(cmBinList.getBinSettlementCurrency());
			cmsBinRequest.setBinSettlementType(cmBinList.getBinSettlementType());
			cmsBinRequest.setBinRangeFrom(cmBinList.getBinRnangeFrom());
			cmsBinRequest.setBinRangeTo(cmBinList.getBinRangeTo());
			cmsBinRequest.setTransactionSettlementCurrency(cmBinList.getTransactionSettlementCurrency().split("\\,"));
			cmsBinRequest.setPlasticCode(cmBinList.getPlasticCode().split("\\,"));
			cmsBinRequest.setTotalNumberOfCards(cmBinList.getTotalNumber());

			response.setData(cmsBinRequest);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public CmsBinGroup getCmsBinGroupDetails(String user, String groupCode) throws Exception {
		// TODO Auto-generated method stub
		return binGroupDao.getCmsBinGroupDetails(user, groupCode);
	}

	@Override
	public GenericResponse getBinGroupByClientId(String clientId) throws Exception {
		
		GenericResponse response = new GenericResponse();
		List<BinGroupSetupBin> listData = new ArrayList<BinGroupSetupBin>();
		List<CmsBinGroup> binGroupList = binGroupDao.getBinGroupClientId(clientId);

		if (!binGroupList.isEmpty() && binGroupList.size() > 0) {
			for (CmsBinGroup cmsBin : binGroupList) {

				BinGroupSetupBin groupSetupBin = new BinGroupSetupBin();
				groupSetupBin.setBinGroupid(cmsBin.getBinGroupId());
				groupSetupBin.setBinGroupDescription(cmsBin.getBinGroupDesc());
				groupSetupBin.setBinGroupName(cmsBin.getBinGroupName());
				groupSetupBin.setSelectBin(String.valueOf(cmsBin.getBinId()));
				groupSetupBin.setBinDesc(cmsBin.getBinDesc());
				groupSetupBin.setBinCurrency(cmsBin.getBinCurrency());
				groupSetupBin.setBinSettlement(cmsBin.getBinSettlementCurrency());
				groupSetupBin.setBinSettlementType(cmsBin.getBinSettlementType());
				groupSetupBin.setBinRangeFrom(cmsBin.getBinRnangeFrom());
				groupSetupBin.setBinRangeTo(cmsBin.getBinRangeTo());
				groupSetupBin.setTransactionSettlementCurrency(cmsBin.getTransactionSettlementCurrency().split("\\,"));
				groupSetupBin.setPlasticCode(cmsBin.getPlasticCode().split("\\,"));
				groupSetupBin.setTotalNumberOfCards(cmsBin.getTotalNumber());

                listData.add(groupSetupBin);
			}
		}
		response.setList(listData);
		return response;
	}

	@Override
	public List<CmsBinGroup> getAll(String user) {
		
		return binGroupDao.getAll(user);
	}

}
