package com.cms.admin.service;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.dao.LoggingDao;
import com.cms.admin.entity.LogCmsException;


@Service
@Transactional
public class LoggingServiceImpl implements LoggingService {

	private static Logger logger = LoggerFactory.getLogger(LoggingServiceImpl.class);

	@Autowired
	private LoggingDao loggingDao;

	@Override
	@Async
	public void saveExceptionLog(String errorCode, String rootCause, String errorMessage, String userId,
			String tTransactionId, String exceptionRequest, String exceptionResponse) {
		logger.info("saveExceptionLog Methode Start ");
		try {
			LogCmsException cmsException = new LogCmsException();
			cmsException.setErrorCode(errorCode == null ? null : errorCode);
			cmsException.setRootCause(rootCause == null ? null : rootCause);
			cmsException.setErrorMessage(errorMessage == null ? null : errorMessage);
			cmsException.setUserId(userId == null ? null : userId);
			cmsException.setTTransactionId(tTransactionId == null ? null : tTransactionId);
			cmsException.setExceptionRequest(exceptionRequest == null ? null : exceptionRequest);
			cmsException.setExceptionResponse(exceptionResponse == null ? null : exceptionResponse);
			cmsException.setInsertedDate(Calendar.getInstance().getTime());
			Integer expId = loggingDao.saveExceptionLog(cmsException);
			logger.info("saveExceptionLog Methode End : Exception Id :" + expId);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception In saveExceptionLog methode ::" + e);
		}
	}

	@Override
	public String stackTraceToString(Throwable e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();

	}

}
