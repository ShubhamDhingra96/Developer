package com.cms.admin.service;

import java.util.List;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.FeeManagement;
import com.cms.admin.entity.CmsFeeManagement;

public interface FeeManagementSevice {
	
	public String saveFeeDetails(FeeManagement[] feemanagement);
 	
	public List<FeeManagement> getFeeDetails();
	
	public FeeManagement updateFeeDetails(FeeManagement feemanagement); 
	
	public FeeManagement getFeeDetailsByCode(String feeCode);
	
	public CmsFeeManagement getFeeDetails(String user,String feeCode);
	
	public GenericResponse geTransactionType();

}
