package com.cms.admin.service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.bean.CustomerRegistration;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;

public interface CmsCustomerRegistrationService {
	
	public GenericResponse saveCustomerRegister(CustomerRegistration customerRegistration); 

	public CmsClientLogin save(CmsClientLogin client);
}
