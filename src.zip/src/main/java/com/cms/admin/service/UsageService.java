package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsCountryGroupRequest;
import com.cms.admin.bean.CmsDeliveryChannelRequest;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsCountryGroup;
import com.cms.admin.entity.CmsDeliveryChannel;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMerchantDetails;

public interface UsageService {

	public CmsCountryGroup save(CmsCountryGroupRequest cmsCountryGroup);

	public CmsCountryGroup update(CmsCountryGroup cmsCountryGroup);

	public CmsCountryGroup getCountryGroup(Integer groupId);

	public CmsCountryGroup getCountryGroup(String username, String groupCode);

	public List<CmsCountryGroup> getAllCountryGroup();

	public CmsDeliveryChannelGroup save(CmsDeliveryChannelGroup cmsDeliveryChannelGroup);

	public CmsDeliveryChannelGroup update(CmsDeliveryChannelGroup cmsDeliveryChannelGroup);

	public CmsDeliveryChannelGroup getDeliveryChannelGroup(Integer groupId);

	public CmsDeliveryChannelGroup getDeliveryChannelGroup(String username, String groupCode);

	public CmsDeliveryChannelGroup save(CmsDeliveryChannelRequest[] cmsDeliveryChannelRequest);

	public List<CmsDeliveryChannelGroup> getAllDeliveryChannelGroup();

	public List<CmsDeliveryChannel> getAll();

	public List<CmsCountryGroup> getCountryGroup(String username);

	public List<CmsDeliveryChannelGroup> getDeliveryChannelGroup(String username);
	
	public List<CmsAcquiringNetworkGroup> getAcquiredNetworkGroup(String username);

	public List<CmsCardUsage> viewCardUsageSetting(String username);

	public List<CmsMerchantDetails> viewMerchantCategory(String username);

	public List<CmsMLimitManagement> viewLimitManagementDetails(String username);

	public List<CmsFeeManagement> viewFeeManagementDetails(String username);


}
