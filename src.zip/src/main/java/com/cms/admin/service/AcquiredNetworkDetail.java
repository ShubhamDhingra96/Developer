package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsAcquiredNetworkRequest;
import com.cms.admin.entity.CmsAcquiredNetworkId;
import com.cms.admin.entity.CmsAcquiringNetworkGroup;
import com.cms.admin.entity.CmsNetworkType;

public interface AcquiredNetworkDetail {

	public CmsAcquiredNetworkRequest[] save(CmsAcquiredNetworkRequest[] cmsAcquiredNetworkRequest);

	public CmsAcquiredNetworkRequest update(CmsAcquiredNetworkRequest cmsAcquiredNetworkRequest);

	public CmsAcquiredNetworkRequest delete(CmsAcquiredNetworkRequest cmsAcquiredNetworkRequest);

	public List<CmsAcquiringNetworkGroup> getAllCmsAcquiredNetwork();
	
	public CmsAcquiringNetworkGroup checkAllCmsAcquiredNetwork(String user, String groupCode);

	public List<CmsNetworkType> getAll();

	public List<CmsAcquiredNetworkId> getAllDetail();

	

}
