package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsClientRegisterRequest;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsContactPersonDetail;

public interface CmsClientService {

	public CmsClient save(CmsClient cmsClient);

	public CmsClient update(CmsClient cmsClient);

	public CmsClient get(CmsClient cmsClient);

	public CmsClient get(String clientId);

	public List<CmsClient> getAllClients();

	public CmsClient setClient(CmsClientRegisterRequest request);

	public CmsContactPersonDetail save(CmsContactPersonDetail[] cmsCompanyPersonDetail);

	public CmsContactPersonDetail update(CmsContactPersonDetail cmsCompanyPersonDetail);

	public CmsContactPersonDetail update(CmsContactPersonDetail[] cmsCompanyPersonDetail);

	public CmsContactPersonDetail get(CmsContactPersonDetail cmsCompanyPersonDetail);

	public CmsContactPersonDetail get(Long personID);

	public CmsClient getClientDetailsbyClientId(String clientId);
	
	public Boolean hasCompany(String company);
	
	public List<CmsClient> getAllCorporates(); 
}
