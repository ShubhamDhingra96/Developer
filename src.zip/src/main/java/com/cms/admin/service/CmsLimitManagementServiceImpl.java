package com.cms.admin.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsLimitManagement;
import com.cms.admin.dao.CmsLimitManagementDao;
import com.cms.admin.entity.CmsCurrency;
import com.cms.admin.entity.CmsMLimitManagement;
import com.cms.admin.entity.CmsMTransaction;



@Transactional
@Service
public class CmsLimitManagementServiceImpl implements CmsLimitManagementService{
	
	@Autowired
	CmsLimitManagementDao cmsLimitManagementDao;

	@Override
	/*
	 * save limit management details
	 * Limit Type:- 0-Default, 1- Specific
	 */
	public String saveLimitDetails(CmsLimitManagement limitManagement) {
		try {
			CmsMLimitManagement management = new CmsMLimitManagement();
			management.setLimitCode(limitManagement.getLimitCode());
			management.setLimitName(limitManagement.getLimitName());
			management.setCountryCode(limitManagement.getCountryCode());
			management.setAcquiringNetwork(limitManagement.getAcquiringNetwork());
			management.setDeliveryChannels(limitManagement.getDeliveryChannels());
			management.setTransaction(limitManagement.getTransaction());
			management.setFrequency(limitManagement.getFrequency());
			management.setLevelCheck(limitManagement.getLevelCheck());
			management.setMaxCount(limitManagement.getMaxCount());
			management.setCurrency(limitManagement.getCurrency());			
			management.setMinAmount(limitManagement.getMinAmount());
			management.setMaxAmount(limitManagement.getMaxAmount());		
			
			management.setCreatedby(limitManagement.getCreatedby());
			management.setCreatedon(limitManagement.getCreatedon());
			management.setLimitType(Short.parseShort(limitManagement.getLimitType()));
			CmsMLimitManagement mLimitManagement = cmsLimitManagementDao.saveLimitManagementDetails(management);
			return mLimitManagement.getLimitCode();
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}

	@Override
	public List<CmsLimitManagement> getLimitDetails() {
		try {
			List<CmsMLimitManagement> list = cmsLimitManagementDao.getLimitDetails();
			List<CmsLimitManagement> details = new ArrayList<CmsLimitManagement>();
			for (CmsMLimitManagement limitManagement : list) {
				CmsLimitManagement management = new CmsLimitManagement();				
				management.setLimitCode(limitManagement.getLimitCode());
				management.setLimitName(limitManagement.getLimitName());
				management.setCountryCode(limitManagement.getCountryCode());
				management.setAcquiringNetwork(limitManagement.getAcquiringNetwork());
				management.setDeliveryChannels(limitManagement.getDeliveryChannels());
				management.setTransaction(limitManagement.getTransaction());
				management.setFrequency(limitManagement.getFrequency());
				management.setLevelCheck(limitManagement.getLevelCheck());
				management.setMaxCount(limitManagement.getMaxCount());
				management.setCurrency(limitManagement.getCurrency());			
				management.setMinAmount(limitManagement.getMinAmount());
				management.setMaxAmount(limitManagement.getMaxAmount());				
				management.setCreatedby(limitManagement.getCreatedby());
				management.setCreatedon(limitManagement.getCreatedon());
				management.setLimitType(limitManagement.getLimitType()+"");				
				details.add(management);
			}
			return details;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public CmsLimitManagement updateLimitDetails(CmsLimitManagement limitManagement) {
		try {
			CmsMLimitManagement management = cmsLimitManagementDao.getLmitDetailByCode(limitManagement.getLimitCode());

			management.setLimitCode(limitManagement.getLimitCode());
			management.setLimitName(limitManagement.getLimitName());
			management.setCountryCode(limitManagement.getCountryCode());
			management.setAcquiringNetwork(limitManagement.getAcquiringNetwork());
			management.setDeliveryChannels(limitManagement.getDeliveryChannels());
			management.setTransaction(limitManagement.getTransaction());
			management.setFrequency(limitManagement.getFrequency());
			management.setLevelCheck(limitManagement.getLevelCheck());
			management.setMaxCount(limitManagement.getMaxCount());
			management.setCurrency(limitManagement.getCurrency());			
			management.setMinAmount(limitManagement.getMinAmount());
			management.setMaxAmount(limitManagement.getMaxAmount());				
			management.setLimitType(Short.parseShort(limitManagement.getLimitType()));
			management.setModifiedby("ADMIN");
			management.setModifiedon(Calendar.getInstance().getTime());
			boolean update = cmsLimitManagementDao.updateLimitDetails(management);
			return limitManagement;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public CmsLimitManagement getLmitDetailByCode(String limitCode) {
		
		try {
			CmsMLimitManagement limitManagement = cmsLimitManagementDao.getLmitDetailByCode(limitCode);
			CmsLimitManagement management = new CmsLimitManagement();			
			
			management.setLimitCode(limitManagement.getLimitCode());
			management.setLimitName(limitManagement.getLimitName());
			management.setCountryCode(limitManagement.getCountryCode());
			management.setAcquiringNetwork(limitManagement.getAcquiringNetwork());
			management.setDeliveryChannels(limitManagement.getDeliveryChannels());
			management.setTransaction(limitManagement.getTransaction());
			management.setFrequency(limitManagement.getFrequency());
			management.setLevelCheck(limitManagement.getLevelCheck());
			management.setMaxCount(limitManagement.getMaxCount());
			management.setCurrency(limitManagement.getCurrency());			
			management.setMinAmount(limitManagement.getMinAmount());
			management.setMaxAmount(limitManagement.getMaxAmount());				
			management.setCreatedby(limitManagement.getCreatedby());
			management.setCreatedon(limitManagement.getCreatedon());			
			management.setModifiedby(limitManagement.getModifiedby());
			management.setModifiedon(limitManagement.getModifiedon());					
			management.setLimitType(limitManagement.getLimitType()+"");	
			
			return management;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@Override
	public GenericResponse geTransactionType() {
		GenericResponse response = new GenericResponse();
		List<CmsLimitManagement> limitManagements=new ArrayList<>();
		List<CmsMTransaction> transactions=cmsLimitManagementDao.getTransactionType();
		for(CmsMTransaction mTransaction : transactions)
		{
			CmsLimitManagement management = new CmsLimitManagement();				
			management.setTransaction(mTransaction.getTxnDescription());
			limitManagements.add(management);
		}
		response.setList(limitManagements);
		return response;
	}

	@Override
	public CmsMLimitManagement getLmitDetailByCode(String createdby, String limitCode) {
		// TODO Auto-generated method stub
		return cmsLimitManagementDao.getLmitDetailByCode(createdby, limitCode);
	}


}
