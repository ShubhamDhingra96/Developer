package com.cms.admin.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.bean.CmsClientRegisterRequest;
import com.cms.admin.dao.CmsClientDao;
import com.cms.admin.dao.CmsClientLoginDao;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsContactPersonDetail;
import com.cms.admin.utility.RandomNumberGenerator;

@Service
@Transactional
public class CmcClientServiceImpl implements CmsClientService {

	@Autowired
	private CmsClientDao clientDao;

	@Autowired
	private CmsClientLoginDao clientLoginDao;

	@Override
	public CmsClient save(CmsClient cmsClient) {
		return clientDao.save(cmsClient);
	}

	@Override
	public CmsClient update(CmsClient cmsClient) {
		return clientDao.update(cmsClient);
	}

	@Override
	public CmsClient get(CmsClient cmsClient) {
		return clientDao.get(cmsClient);
	}

	@Override
	public CmsClient get(String clientId) {
		return clientDao.get(clientId);
	}

	@Override
	public CmsClient setClient(CmsClientRegisterRequest request) {
		CmsClientLogin clientlogin = clientLoginDao.get(request.getClientID());
		CmsClient client = new CmsClient();
		try {

			client.setCmsCompanyAddress1(request.getCmsCompanyAddress1());
			client.setCmsCompanyAddress2(request.getCmsCompanyAddress2());
			client.setCmsCompanyCity(request.getCmsCompanyCity());
			client.setCmsCompanyCountry(request.getCmsCompanyCountry());			
			client.setCmsCompanyName(request.getCmsCompanyName().toUpperCase());			
			client.setCmsCompanystate(request.getCmsCompanyState());			
			client.setInsertedBy(clientlogin);
			client.setInsertedDate(getDate("yyyy-MM-dd"));
			client.setModifiedBy(clientlogin);
			client.setModifiedDate(getDate("yyyy-MM-dd"));
			client.setCmsCompanyStatus("-1");
			client.setCmsCompanyPinCode(request.getCmsCompanyPincode());			
			client.setCmsClientId(request.getCmsCompanyName().trim().replaceAll(" ", "").trim().substring(0, 4).toUpperCase()+RandomNumberGenerator.generateNumber());
			client.setUserCreated("N");
			if(request.getCorporateType()!=null) 
			client.setCorporateType(request.getCorporateType());
			else
				client.setCorporateType("N");

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return client;
	}

	private Date getDate(String pattern) throws ParseException {
		return new SimpleDateFormat(pattern).parse(new SimpleDateFormat(pattern).format(new Date()));
	}

	@Override
	public CmsContactPersonDetail save(CmsContactPersonDetail[] cmsCompanyPersonDetail) {
		// TODO Auto-generated method stub
		return clientDao.save(cmsCompanyPersonDetail);
	}

	@Override
	public CmsContactPersonDetail update(CmsContactPersonDetail cmsCompanyPersonDetail) {
		// TODO Auto-generated method stub
		return clientDao.update(cmsCompanyPersonDetail);
	}

	@Override
	public CmsContactPersonDetail update(CmsContactPersonDetail[] cmsCompanyPersonDetail) {
		// TODO Auto-generated method stub
		return clientDao.update(cmsCompanyPersonDetail);
	}

	@Override
	public CmsContactPersonDetail get(CmsContactPersonDetail cmsCompanyPersonDetail) {
		// TODO Auto-generated method stub
		return clientDao.get(cmsCompanyPersonDetail);
	}

	@Override
	public CmsContactPersonDetail get(Long personID) {
		// TODO Auto-generated method stub
		return clientDao.get(personID);
	}

	@Override
	public CmsClient getClientDetailsbyClientId(String clientId) {
		// TODO Auto-generated method stub
		return clientDao.getClientDetailsbyClientId(clientId);
	}

	@Override
	public List<CmsClient> getAllClients() {
	List<CmsClient> clients = new ArrayList<>();
	for(CmsClient client :  clientDao.getAllClients()) {
//		client.setInsertedBy(null);
//		client.setModifiedBy(null);
		clients.add(client);
	}
		return clients;
	}

	@Override
	public Boolean hasCompany(String company) {
		// TODO Auto-generated method stub
		return clientDao.hasCompany(company);
	}
	
	@Override
	public List<CmsClient> getAllCorporates() {
	List<CmsClient> clients = new ArrayList<>();
	for(CmsClient client :  clientDao.getAllCorporates()) {
		clients.add(client);
	}
		return clients;
	}

}
