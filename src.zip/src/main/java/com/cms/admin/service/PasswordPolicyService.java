package com.cms.admin.service;

import com.cms.admin.bean.CMS_Message;

public interface PasswordPolicyService {
	
	public CMS_Message checkPasswordPolicy(String username, Integer code);

}
