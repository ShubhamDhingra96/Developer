package com.cms.admin.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsLimitManagement;
import com.cms.admin.bean.TransactionGroup;
import com.cms.admin.dao.TransactionGroupDao;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsMTransaction;
import com.cms.admin.entity.CmsTransactionGrouping;

@Transactional
@Service
public class TransactionGroupServiceImpl implements TransactionGroupService {

	@Autowired
	TransactionGroupDao transactionGroupDao;
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
	
   
	@Override
	public GenericResponse geTransactionType() {
		GenericResponse response = new GenericResponse();
		List<TransactionGroup> transactionGroups=new ArrayList<>();
		List<CmsMTransaction> transactions=transactionGroupDao.getTransactionType();
		for(CmsMTransaction mTransaction : transactions)
		{
			TransactionGroup transactionGroup = new TransactionGroup();				
			transactionGroup.setTransactions(mTransaction.getTxnDescription());
			transactionGroups.add(transactionGroup);
		}
		response.setList(transactionGroups);
		return response;
	}

	@Override
	public String saveTransactionGrouping(TransactionGroup transactionGroup) {
		// TODO Auto-generated method stub
		 String insertedDate = dateFormat.format(new Date());  
		 System.out.println("created by..."+transactionGroup.getInsertedBy());
		CmsTransactionGrouping cmsTransactionGrouping = new CmsTransactionGrouping();
		
		cmsTransactionGrouping.setGroupTxnCode(transactionGroup.getGroupTransactionCode());
		cmsTransactionGrouping.setGroupTxnName(transactionGroup.getGroupTransactionName());
		cmsTransactionGrouping.setGroupTransactions(transactionGroup.getTransactions());
		cmsTransactionGrouping.setInsertedDate(insertedDate);
		cmsTransactionGrouping.setInsertedBy(transactionGroup.getInsertedBy());
		cmsTransactionGrouping.setStatus("Active");
		CmsTransactionGrouping transactionGrouping=transactionGroupDao.saveTransactionGrouping(cmsTransactionGrouping);
		return transactionGrouping.getGroupTxnCode();
	}

	@Override
	public GenericResponse getTransactionGroupDetails() {
		// TODO Auto-generated method stub
		GenericResponse response = new GenericResponse();
		List<TransactionGroup> transactionGroups=new ArrayList<>();
		List<CmsTransactionGrouping> transactions=transactionGroupDao.getTransactionGroupDetails();
		for(CmsTransactionGrouping mTransaction : transactions)
		{
			TransactionGroup transactionGroup = new TransactionGroup();	
			transactionGroup.setGroupTransactionCode(mTransaction.getGroupTxnCode());
			transactionGroup.setTransactions(mTransaction.getGroupTransactions());
			transactionGroup.setGroupTransactionName(mTransaction.getGroupTxnName());
			transactionGroup.setStatus(mTransaction.getStatus());
			transactionGroups.add(transactionGroup);
		}
		response.setList(transactionGroups);
		return response;
	}

	@Override
	public CmsTransactionGrouping getTransactionCode(String user, String groupCode) throws Exception {
		// TODO Auto-generated method stub
		return transactionGroupDao.getTransactionCode(user, groupCode);
	}

	@Override
	public GenericResponse getTransactionCodeByClientId(String clientId) throws Exception {
		// TODO Auto-generated method stub
		GenericResponse response = new GenericResponse();

		List<TransactionGroup> listData = new ArrayList<TransactionGroup>();
		List<CmsTransactionGrouping> productList = transactionGroupDao.getTransactionCodeByClientId(clientId);

		if (!productList.isEmpty() && productList.size() > 0) {
			for (CmsTransactionGrouping mTransaction : productList) {

				TransactionGroup transactionGroup = new TransactionGroup();
				transactionGroup.setGroupTransactionCode(mTransaction.getGroupTxnCode());
				transactionGroup.setTransactions(mTransaction.getGroupTransactions());
				transactionGroup.setGroupTransactionName(mTransaction.getGroupTxnName());
				transactionGroup.setStatus(mTransaction.getStatus());

				listData.add(transactionGroup);
			}
		}
		response.setList(listData);
		return response;
	}

}
