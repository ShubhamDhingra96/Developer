package com.cms.admin.service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsBinRequest;
import com.cms.admin.bean.CmsMBin;
import com.cms.admin.entity.CmsBin;

public interface BinSetupService {

	//public GenericResponse addBinData(CmsBinRequest bean)throws Exception; 
	public GenericResponse addBinData(CmsMBin cmsMbin);
	public GenericResponse getBinDataList(CmsBinRequest bean)throws Exception; 
	public CmsBin getBin(String user,String groupCode)throws Exception; 
	public GenericResponse getBinCurrency()throws Exception;
	public GenericResponse getBinsetupByClientId(String clientId) throws Exception;
	
}
