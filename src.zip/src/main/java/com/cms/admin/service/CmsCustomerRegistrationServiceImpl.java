package com.cms.admin.service;

import java.text.SimpleDateFormat;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CustomerRegistration;
import com.cms.admin.bean.IdentificationType;
import com.cms.admin.dao.CmsClientLoginDao;
import com.cms.admin.dao.CmsCustomerRegistrationDao;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMCustomer;
import com.cms.admin.entity.CmsMIdentificationType;
import com.cms.admin.utility.Utility;

@Service
@Transactional
public class CmsCustomerRegistrationServiceImpl implements CmsCustomerRegistrationService {

	@Autowired
	CmsCustomerRegistrationDao customerRegistrationdao;
	
	@Autowired
	private CmsClientLoginDao clientLoginDao;
	
	@Autowired
	Utility utility;

	@Override
	public GenericResponse saveCustomerRegister(CustomerRegistration customerRegistration) {

		System.out.println("pannumber..."+customerRegistration.getPanNumber());
		String fname=customerRegistration.getFirstName().substring(0, customerRegistration.getFirstName().length()-1);
		String lname=customerRegistration.getLastName().substring(0, customerRegistration.getLastName().length()-1);
		String customerId=fname.concat(lname).concat(utility.customerId());
		System.out.println("Customer id..."+customerId);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
		
		GenericResponse response = new GenericResponse();
		
		CmsMCustomer cmsMCustomer = new CmsMCustomer();
		cmsMCustomer.setCustomerId(customerId);
		cmsMCustomer.setFirstName(customerRegistration.getFirstName());
		cmsMCustomer.setMiddleName(customerRegistration.getMiddleName());
		cmsMCustomer.setLastName(customerRegistration.getLastName());
		cmsMCustomer.setDateOfBirth(customerRegistration.getDateOfBirth());
		cmsMCustomer.setMotherName(customerRegistration.getMotherName());
		cmsMCustomer.setGender(customerRegistration.getGender());
		cmsMCustomer.setNationality(customerRegistration.getNationality());
		cmsMCustomer.setMaritalStatus(customerRegistration.getMaritalStatus());
		cmsMCustomer.setResidentalAddress1(customerRegistration.getResidenceAddress1());
		cmsMCustomer.setResidentalAddress2(customerRegistration.getResidenceAddress2());
		cmsMCustomer.setResidentalAddress3(customerRegistration.getResidenceAddress3());
		cmsMCustomer.setResidentalAddress4(customerRegistration.getResidenceAddress4());
		cmsMCustomer.setCity(customerRegistration.getCity());
		cmsMCustomer.setState(customerRegistration.getState());
		cmsMCustomer.setCountry(customerRegistration.getCountry());
		cmsMCustomer.setPinCode(customerRegistration.getPinCode());
		cmsMCustomer.setPhoneNumber(customerRegistration.getPhoneNumber());
		cmsMCustomer.setOfficialAddress1(customerRegistration.getOfficeAddress1());
		cmsMCustomer.setOfficialAddress2(customerRegistration.getOfficeAddress2());
		cmsMCustomer.setOfficialAddress3(customerRegistration.getOfficeAddress3());
		cmsMCustomer.setOfficialAddress4(customerRegistration.getOfficeAddress4());
		cmsMCustomer.setOfficialCity(customerRegistration.getOfficeCity());
		cmsMCustomer.setOfficialState(customerRegistration.getOfficeState());
		cmsMCustomer.setOfficialCountry(customerRegistration.getOfficeCountry());
		cmsMCustomer.setOfficialPincode(customerRegistration.getOfficePinCode());
		cmsMCustomer.setOfficialPhoneNumber(customerRegistration.getOfficePhoneNumber());
		cmsMCustomer.setOfficialExtensionNumber(customerRegistration.getOfficeExtensionNumber());
		cmsMCustomer.setMobileNumber(customerRegistration.getMobileNumber());
		cmsMCustomer.setMailTo(customerRegistration.getMailTo());
		cmsMCustomer.setEmailAddress(customerRegistration.getEmailAddress());
		cmsMCustomer.setAlternativeEmailAddress(customerRegistration.getAlternativeEmailAddress());
		cmsMCustomer.setApplicationDate(customerRegistration.getApplicationDate());
		cmsMCustomer.setPassportNumber(customerRegistration.getPassportNumber());
		cmsMCustomer.setPassportIssueDate(customerRegistration.getPassportIssueDate());
		cmsMCustomer.setPassportExpiryDate(customerRegistration.getPassportExpiryDate());
		cmsMCustomer.setPanOrForm(customerRegistration.getPanOrForm());
		cmsMCustomer.setCmsTxnrefNumber(utility.txnRefGenerator());
		cmsMCustomer.setCmsProxyNumber(utility.proxyNumberGenerator());
		if(customerRegistration.getPanNumber()!=null) {
		cmsMCustomer.setPanNumber(customerRegistration.getPanNumber());
		}
		Integer id = customerRegistrationdao.saveCustomerRegister(cmsMCustomer);
		
		
		IdentificationType[] identificationTypes=customerRegistration.getIdentificationTable();
		for(IdentificationType identificationType:identificationTypes)
		{
			CmsMIdentificationType cmsMIdentificationType=new CmsMIdentificationType();
			CmsMCustomer cmsCustomer = new CmsMCustomer();
			cmsCustomer.setId(id);
			String expiryDate= formatter.format(identificationType.getExpiryDate());  
			System.out.println("Identification details..."+identificationType.getDocumentName()+" "+identificationType.getIdNumber()+" "+identificationType.getExpiryDate());
			cmsMIdentificationType.setDocumentType(identificationType.getDocumentName());
			cmsMIdentificationType.setIdNumber(identificationType.getIdNumber());
			cmsMIdentificationType.setExpiryDate(expiryDate);
			cmsMIdentificationType.setCustId(cmsCustomer);
			Integer identifiction = customerRegistrationdao.saveIdentificationType(cmsMIdentificationType);
			System.out.println("Identification value..."+identifiction);
		}
		
		if (id != null) {
			response.setMessage("Customer registration done successfully.");
		} else {
			response.setMessage("Something went wrong");
		}
		return response;
	}

	@Override
	public CmsClientLogin save(CmsClientLogin client) {
		client=clientLoginDao.save(client);
		return client;
	}
	
}
