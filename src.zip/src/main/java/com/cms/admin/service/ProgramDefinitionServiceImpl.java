package com.cms.admin.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.bean.ProgrammeDefinitionBean;
import com.cms.admin.dao.PlasticProductDao;
import com.cms.admin.dao.ProgramDefinitionDao;
import com.cms.admin.entity.CmsPlasticProductSetup;
import com.cms.admin.entity.CmsProgrammeDefinition;

@Service
@Transactional
public class ProgramDefinitionServiceImpl implements ProgrameDefinitionService{

	@Autowired
	ProgramDefinitionDao programDao;

	
	@Override
	public ProgrammeDefinitionBean saveProductDefinition(ProgrammeDefinitionBean programDefinition) {
		try {
			CmsProgrammeDefinition programentity = new CmsProgrammeDefinition();
			programentity.setProgramCode(programDefinition.getProgrammecode());
			programentity.setProgramDescription(programDefinition.getProgrammedescription());
			programentity.setApplicationType(programDefinition.getApplicationType());
			programentity.setAuthrizationRule(programDefinition.getAuthorizationrule());
			programentity.setInsertedBy(programDefinition.getInsertedBy());
			programentity.setModifiedBy(programDefinition.getModifiedBy());
			programentity.setProgramDefinitionid(0);
			programentity.setMultiprodAccount(programDefinition.getMultipleProductAccount());
			programentity.setInsertedDate(programDefinition.getInsertedDate());
			programentity.setModifiedDate(programDefinition.getModifiedDate());
			programentity.setMultiprodAccount(programDefinition.getMultipleProductAccount());
			programentity.setShortDescription(programDefinition.getShortdescription());

			CmsProgrammeDefinition newprogramDef =  programDao.saveProgramDefinitionDetails(programentity);
			return programDefinition;

		} catch (Exception exception) {

			exception.printStackTrace();
		}
		return null;
	

}


	@Override
	public List<ProgrammeDefinitionBean> getProgramDefinitionDetails() {
		try {
			List<CmsProgrammeDefinition> programentitylist =  programDao.getProgramDefinitionDetails();
			List<ProgrammeDefinitionBean> beanlist=new ArrayList<ProgrammeDefinitionBean>();
			for(CmsProgrammeDefinition programlist: programentitylist) {
				ProgrammeDefinitionBean definitionbean=new ProgrammeDefinitionBean();
				definitionbean.setApplicationType(programlist.getApplicationType());
				definitionbean.setAuthorizationrule(programlist.getAuthrizationRule());
				definitionbean.setInsertedBy(programlist.getInsertedBy());
				definitionbean.setInsertedDate(programlist.getInsertedDate());
				definitionbean.setModifiedBy(programlist.getModifiedBy());
				definitionbean.setModifiedDate(programlist.getModifiedDate());
				definitionbean.setMultipleProductAccount(programlist.getMultiprodAccount());
				definitionbean.setProgrammecode(programlist.getProgramCode());
				definitionbean.setProgrammedescription(programlist.getProgramDescription());
				definitionbean.setShortdescription(programlist.getShortDescription());
				beanlist.add(definitionbean);
			}
			return beanlist;
		}catch(Exception exception) {
			
			exception.printStackTrace();
			
		}
		return null;
	}


	@Override
	public ProgrammeDefinitionBean updateProgramDefinitionBean(ProgrammeDefinitionBean programDefinitionbean) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public ProgrammeDefinitionBean isExistProgramCode(String programcode) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public CmsProgrammeDefinition getCardUsageDetailsByCode(String username, String programcode) {
		return  programDao.getProgramDefinitionByCode(username, programcode);
		
	}


	@Override
	public List<CmsProgrammeDefinition> getAll(String username) {
		
		return programDao.getAll(username);
	}
}