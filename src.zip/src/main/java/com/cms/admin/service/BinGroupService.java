package com.cms.admin.service;

import java.util.List;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.BinGroupSetupBin;
import com.cms.admin.entity.CmsBinGroup;

public interface BinGroupService {

	public GenericResponse addBinGroupData(BinGroupSetupBin bean) throws Exception;

	public GenericResponse getBinGroupList(BinGroupSetupBin bean) throws Exception;

	public GenericResponse getCmsBinDetails(String binNumber) throws Exception;

	public GenericResponse getPlasticCodelist() throws Exception;

	public GenericResponse getBinGroupSetUpDetails() throws Exception;

	public GenericResponse getCmsBinGroupDetails(String groupCode) throws Exception;

	public CmsBinGroup getCmsBinGroupDetails(String user,String groupCode)throws Exception; 
	
	public GenericResponse getBinGroupByClientId(String clientId) throws Exception;
	
	public List<CmsBinGroup> getAll(String user);
}
