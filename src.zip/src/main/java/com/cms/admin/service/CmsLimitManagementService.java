package com.cms.admin.service;

import java.util.List;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsLimitManagement;
import com.cms.admin.entity.CmsMLimitManagement;

public interface CmsLimitManagementService {
	
	public String saveLimitDetails(CmsLimitManagement limitManagement);
	
	public List<CmsLimitManagement> getLimitDetails();
	
	public CmsLimitManagement updateLimitDetails(CmsLimitManagement limitManagement);
	
	public CmsLimitManagement getLmitDetailByCode(String limitCode);
	
	public GenericResponse geTransactionType();
	
	public CmsMLimitManagement getLmitDetailByCode(String createdby,String limitCode);

}
