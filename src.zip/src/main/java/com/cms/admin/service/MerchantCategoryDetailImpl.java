package com.cms.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.bean.CmsMerchantGroupRequest;
import com.cms.admin.dao.MerchantDao;
import com.cms.admin.entity.CmsMccGroupCode;
import com.cms.admin.entity.CmsMerchantDetails;
import com.cms.admin.entity.CmsMerchantMccGroup;

@Service
@Transactional
public class MerchantCategoryDetailImpl implements MerchantCategoryDetail {

	@Autowired
	MerchantDao merchantDao;

	@Override
	public CmsMerchantGroupRequest[] save(CmsMerchantGroupRequest[] cmsMerchantDetails) {
		for (CmsMerchantGroupRequest request : cmsMerchantDetails) {
			CmsMerchantDetails detail = new CmsMerchantDetails();
			detail.setGroupId(0);
			detail.setInsertedBy(request.getInsertedBy());
			detail.setInsertedDate(request.getInsertedDate());
			detail.setMerchantGroupCode(request.getMerchantGroupCode());
			detail.setMerchantGroupDescription(request.getMerchantGroupDescription());
			detail.setMerchantGroupName(request.getMerchantGroupName());
			detail.setMerchantMCCCode(request.getMerchantMCCCode());
			detail.setMerchantMCCGroup(request.getMerchantMCCGroup());
			detail.setMerchantNetworkType(request.getMerchantNetworkType());
			detail.setModifiedBy(request.getModifiedBy());
			detail.setModifiedDate(request.getModifiedDate());
			merchantDao.saveDetails(detail);
		}
		return cmsMerchantDetails;
	}

	@Override
	public CmsMerchantDetails update(CmsMerchantDetails cmsMerchantDetails) {

		return merchantDao.updateDetails(cmsMerchantDetails);
	}

	@Override
	public CmsMerchantDetails delete(CmsMerchantDetails cmsMerchantDetails) {
		return merchantDao.deleteDetails(cmsMerchantDetails);
	}

	@Override
	public List<CmsMerchantMccGroup> getAll() {
		
		return merchantDao.getAll();
	}

	@Override
	public List<CmsMccGroupCode> getAllDetail() {
		
		return merchantDao.getAllDetail();
	}

	@Override
	public CmsMerchantDetails getMerchant(String username, String groupCode) {
		// TODO Auto-generated method stub
		return merchantDao.getMerchant(username, groupCode);
	}

}
