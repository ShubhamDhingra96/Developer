package com.cms.admin.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cms.admin.bean.CMS_Message;
import com.cms.admin.constant.Constants;
import com.cms.admin.dao.CmsClientLoginDao;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMClientLoginHistory;
import com.cms.admin.utility.Password_Generator;

@Service
@Transactional
public class PasswordPolicyServiceImpl implements PasswordPolicyService {

	@Autowired
	private CmsClientLoginDao clientLoginDao;

	/**
	 * CMS Password Policy 1.Check user login attempts / user account lock check
	 * 2.User first time login 3.User password expired
	 */
	@Override
	public CMS_Message checkPasswordPolicy(String username, Integer code) {
		System.out.println("Authentication Code :: " + code);
		CmsClientLogin clientLogin = clientLoginDao.get(username);
		CMS_Message error = new CMS_Message();

		/**
		 * If Valid User is present
		 */
		if (code == 200 && clientLogin != null) {
			/**
			 * Check the User login attempt
			 */
			if (clientLogin.getLoginAttempts() > Constants.LOGIN_ATTEMPTS) {
				System.out.println("In login || Your Account has been locked || Login By : " + username);
				clientLogin.setAccountLockFlag(Constants.USER_ACCOUNT_LOCK);
				clientLoginDao.update(clientLogin);
				error = new CMS_Message(Constants.ACCOUNT_LOCK, 500, null, null, null);
			} else {
				/**
				 * Find the date Difference (Current Date - Modified Date)
				 */
				Date today = new Date();
				long dateDiff = ((today.getTime() - clientLogin.getModifiedDate().getTime()) / (24 * 60 * 60 * 1000));

				/**
				 * First time user login check
				 */
				if (clientLogin.getPasswordStatus().equals(Constants.FIRST_TIME_LOGIN)) {
					error = new CMS_Message(Constants.F_CHANGE_PASSWORD, 500, null, null, null);
				}
				/**
				 * To check password expiry of user
				 */
				else if (dateDiff > Constants.PWD_EXPIRY_PERIOD_IN_DAYS) {
					error = new CMS_Message(Constants.E_CHANGE_PASSWORD, 500, null, null, null);
				}
			}
		} else {
			if (clientLogin != null) {
				clientLogin.setLoginAttempts(clientLogin.getLoginAttempts() + 1);
				if (clientLogin.getLoginAttempts() + 1 > Constants.LOGIN_ATTEMPTS) {
					clientLogin.setAccountLockFlag(Constants.USER_ACCOUNT_LOCK);
				}
				clientLoginDao.update(clientLogin);
				error = new CMS_Message(Constants.INVALID, 500, null, null, null);
				System.out.println("Invalid Username and Password.");
			} else {
				System.out.println("User doesn't exits.");
				error = new CMS_Message(Constants.NOT_EXISTS, 500, null, null, null);
			}

		}

		return error;
	}

	public CMS_Message changePassword(String username, String newPassword, String oldPassword, String confirmPassword) {
		CMS_Message result = new CMS_Message();
		boolean value = false;

		if (oldPassword.trim().equals("") && newPassword.trim().equals("") && confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide old password, new password and confirm password.", 500, null, null,
					null);
			return result;
		} else if (oldPassword.trim().equals("") && !newPassword.trim().equals("")
				&& !confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide old password", 500, null, null, null);
			return result;
		} else if (!oldPassword.trim().equals("") && newPassword.trim().equals("")
				&& !confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide new password.", 500, null, null, null);
			return result;
		} else if (!oldPassword.trim().equals("") && !newPassword.trim().equals("")
				&& confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide confirm password", 500, null, null, null);
			return result;
		} else if (!oldPassword.trim().equals("") && newPassword.trim().equals("")
				&& confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide new password and confirm password.", 500, null, null, null);
			return result;
		} else if (oldPassword.trim().equals("") && !newPassword.trim().equals("")
				&& confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide old password and confirm password.", 500, null, null, null);
			return result;
		} else if (oldPassword.trim().equals("") && newPassword.trim().equals("")
				&& !confirmPassword.trim().equals("")) {
			result = new CMS_Message("Please provide old password and new password.", 500, null, null, null);
			return result;
		} else if (oldPassword.equals(newPassword)) {
			result = new CMS_Message("Old Password and New Password can not be same.", 500, null, null, null);
			return result;
		} else if (!newPassword.equals(confirmPassword)) {
			result = new CMS_Message("New Password and confirm Password must be same.", 500, null, null, null);
			return result;
		} else if (!Password_Generator.validatePwd(newPassword)) {
			result = new CMS_Message(
					"Password with 8 characters contains 1 Uppercase, 1 Lowercase, 1 Number and 1 Special Characters.",
					500, null, null, null);
			return result;
		} else {
			/**
			 * 
			 */
			value = true;
			CmsClientLogin clientLogin = clientLoginDao.get(username);

			if (clientLogin != null) {
				Set<CmsMClientLoginHistory> clientLoginHistories = clientLogin.getPasswordHistories();

				List list = new ArrayList(clientLoginHistories);


				Collections.sort(list,(CmsMClientLoginHistory p1, CmsMClientLoginHistory p2) -> p2.getLoginId() - p1.getLoginId());

				if (!list.isEmpty()) {
					Iterator i1 = list.iterator();
					int count = 1;
					while (i1.hasNext()) {
						if (count > Constants.PASSWORD_CHECK)
							break;
						CmsMClientLoginHistory clientLoginHistory = (CmsMClientLoginHistory) i1.next();
						if (clientLoginHistory.getPassword().equals(newPassword)) {
							result = new CMS_Message("New Password is Invalid.", 500, null, null, null);
							return result;
						}
						count++;
					}
				}
				
				clientLogin.setPassword("");
				clientLogin.setPasswordModifiedDate(Calendar.getInstance().getTime());
				clientLogin.setAccountLockFlag(Constants.USER_ACCOUNT_UNLOCK);
				clientLogin.setLoginAttempts(0);
				clientLogin.setModifiedDate(Calendar.getInstance().getTime());
				clientLogin.setModifiedBy(Constants.CONST_USER);
				clientLoginDao.update(clientLogin);
				result = new CMS_Message("New Password is Invalid.", 500, null, null, null);
				return result;
			}
			result = new CMS_Message("User not present in CMS.", 500, null, null, null);
			return result;

		}

	}

}
