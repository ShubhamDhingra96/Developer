package com.cms.admin.service;

import java.util.List;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.TransactionGroup;
import com.cms.admin.entity.CmsBin;
import com.cms.admin.entity.CmsTransactionGrouping;

public interface TransactionGroupService {

	public GenericResponse geTransactionType();
	
	public String saveTransactionGrouping(TransactionGroup transactionGroup);
	
	public GenericResponse getTransactionGroupDetails();
	
	public CmsTransactionGrouping getTransactionCode(String user,String groupCode)throws Exception; 
	
	public GenericResponse getTransactionCodeByClientId(String clientId) throws Exception;
}
