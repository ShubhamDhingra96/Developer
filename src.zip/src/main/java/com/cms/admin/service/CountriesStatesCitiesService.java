package com.cms.admin.service;

import java.util.List;

import com.cms.admin.entity.CmsCities;
import com.cms.admin.entity.CmsCountries;
import com.cms.admin.entity.CmsCountry;
import com.cms.admin.entity.CmsStates;

public interface CountriesStatesCitiesService {

	public CmsCountries getCountries(Number countryid);

	public List<CmsCountries> getCountries();

	public CmsStates getStates(Long stateId);

	public CmsCities getCities(Long cityid);

	public List<CmsStates> getStatesByCountryid(Long countryid);

	public List<CmsCities> getCitiesByStateid(Long stateid);
	
	public List<CmsCountry> getCountry();

}
