package com.cms.admin.service;

import java.text.ParseException;
import java.util.List;

import com.cms.admin.bean.CmsClientLoginRequest;
import com.cms.admin.bean.CmsClientRegisterRequest;
import com.cms.admin.entity.CmsClient;
import com.cms.admin.entity.CmsClientLogin;
import com.cms.admin.entity.CmsMFunctions;
import com.cms.admin.entity.CmsMJobs;
import com.cms.admin.entity.CmsMJobsMapping;
import com.cms.admin.entity.CmsMModules;


public interface CmsClientLoginService {

	public CmsClientLogin save(CmsClient client) throws ParseException;
	
	public CmsClientLogin save(CmsClientLogin client);
	
	public List<CmsClientLogin> getAllSuperAdminUser();

	public CmsClientLogin update(CmsClientLogin cmsClientLogin);

	public CmsClientLogin get(CmsClientLogin cmsClientLogin);

	public CmsClientLogin get(String username);
	
	public List<CmsClientLogin> getAll();
	
	
	public CmsClientLoginRequest setLoginUser(CmsClientLogin loginUser);
	
	public CmsClientLogin getClientDetailsByUsername(String username);

	public CmsClientLogin getClientDetailsByTokenKey(String tokenKey);
	

	public List<CmsMModules> getModules();
	
	public List<CmsMFunctions> getModuleFunctions(String moduleId);
	
	public List<CmsMJobsMapping> getJobMappingDetails(String functionId);
	
	public List<CmsMJobs> getJobsName(List<CmsMJobs> jobId);
	
}
