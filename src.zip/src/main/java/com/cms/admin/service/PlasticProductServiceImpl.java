package com.cms.admin.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.dao.PlasticProductDao;
import com.cms.admin.entity.CmsPlasticProductSetup;

@Service("plasticService")
@Transactional
public class PlasticProductServiceImpl implements PlasticProductService {

	@Autowired
	PlasticProductDao plasticDao;

	@Override
	public GenericResponse getPlasticProductList(PlasticProductSetupBean bean) throws Exception {
		GenericResponse response = new GenericResponse();
		
		List<PlasticProductSetupBean> listData = new ArrayList<PlasticProductSetupBean>();
		List<CmsPlasticProductSetup> productList = plasticDao.getPlasticProductList();
		
		if (!productList.isEmpty() && productList.size() > 0) {
			for (CmsPlasticProductSetup cmsPlasticProductSetup : productList) {
				
				PlasticProductSetupBean finalResult = new PlasticProductSetupBean();
					finalResult.setPlasticId(cmsPlasticProductSetup.getPlasticSetupId() + "");
					finalResult.setPlasticCode(cmsPlasticProductSetup.getPlasticCode() + "");
					finalResult.setPlasticDescription(cmsPlasticProductSetup.getPlasticDescription());
					finalResult.setServiceCode(cmsPlasticProductSetup.getServiceCode());
					
					finalResult.setClientId(cmsPlasticProductSetup.getClientID());
					
				listData.add(finalResult);
			}
		}
		response.setList(listData);
		return response;
	}

	@Override
	public PlasticProductSetupBean savePlasticSetUp(PlasticProductSetupBean plasticSetup) {
		try {
			CmsPlasticProductSetup setupentity = new CmsPlasticProductSetup();
			setupentity.setClientID(plasticSetup.getClientId());
			setupentity.setInsertedDate(plasticSetup.getInsertedDate());
			setupentity.setModifiedDate(plasticSetup.getModifiedDate());
			setupentity.setPlasticCode(plasticSetup.getPlasticCode());
			setupentity.setPlasticDescription(plasticSetup.getPlasticDescription());
			setupentity.setServiceCode(plasticSetup.getServiceCode());
			setupentity.setPlasticSetupId(0);

			CmsPlasticProductSetup newcmscardusage =  plasticDao.savePlasticProductSetupDetails(setupentity);
			return plasticSetup;

		} catch (Exception exception) {

			exception.printStackTrace();
		}
		return null;
	}

	@Override
	public GenericResponse getSpecificPlasticCodeList(String clientId) throws Exception {
		GenericResponse response = new GenericResponse();

		List<PlasticProductSetupBean> listData = new ArrayList<PlasticProductSetupBean>();
		List<CmsPlasticProductSetup> productList = plasticDao.getSpecificPlasticProductList(clientId);

		if (!productList.isEmpty() && productList.size() > 0) {
			for (CmsPlasticProductSetup cmsPlasticProductSetup : productList) {

				PlasticProductSetupBean finalResult = new PlasticProductSetupBean();
				finalResult.setPlasticId(cmsPlasticProductSetup.getPlasticSetupId() + "");
				finalResult.setPlasticCode(cmsPlasticProductSetup.getPlasticCode() + "");
				finalResult.setPlasticDescription(cmsPlasticProductSetup.getPlasticDescription());
				finalResult.setServiceCode(cmsPlasticProductSetup.getServiceCode());

				finalResult.setClientId(cmsPlasticProductSetup.getClientID());

				listData.add(finalResult);
			}
		}
		response.setList(listData);
		return response;
	}

	@Override
	public CmsPlasticProductSetup getSpecificPlasticProductList(String clientId, String groupCode) throws Exception {
		// TODO Auto-generated method stub
		return plasticDao.getSpecificPlasticProductList(clientId, groupCode);
	}

}
