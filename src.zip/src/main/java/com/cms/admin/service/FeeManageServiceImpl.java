package com.cms.admin.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.admin.api.GenericResponse;
import com.cms.admin.bean.CmsDeliveryChannelRequest;
import com.cms.admin.bean.FeeManagement;
import com.cms.admin.dao.FeeManagementDao;
import com.cms.admin.entity.CmsDeliveryChannelGroup;
import com.cms.admin.entity.CmsFeeManagement;
import com.cms.admin.entity.CmsMGroupTransaction;

@Service
public class FeeManageServiceImpl implements FeeManagementSevice {

	@Autowired
	FeeManagementDao feemanagementdao;

	@Override
	public String saveFeeDetails(FeeManagement[] feemanagement) {
		
		for(FeeManagement request:feemanagement) {
		CmsFeeManagement management = new CmsFeeManagement();
		management.setFeeCode(request.getFeeCode());
		management.setFeeDescription(request.getFeeDescription());
		management.setTransaction(request.getTransaction());
		management.setFrequency(request.getFrequency());
		management.setPerFlat(request.getPerFlat());
		management.setPercentage(request.getPercentage());
		management.setFlat(request.getFlat());
		management.setLimit(request.getLimit());
		management.setMaxLimit(request.getMaxLimit());
		management.setMinLimit(request.getMinLimit());
		management.setChargeFeeTo(request.getChargeFeeTo());
		management.setGroupTransactions(request.getGroupTransactions());
		management.setCriteria(request.getCriteria());
		management.setCriteriaFrom(request.getCriteriaFrom());
		management.setCriteriaTo(request.getCriteriaTo());
		management.setCountryCode(request.getCountryCode());
		management.setAcquiringNetwork(request.getAcquiringNetwork());
		management.setAcquiringNetworkName(request.getAcquiringNetworkName());
		management.setDeliveryChannels(request.getDeliveryChannels());
		management.setDeliveryChannelName(request.getDeliveryChannelName());
		management.setMerchantIdGroup(request.getMerchantIdGroup());
		management.setMerchantIdGroupName(request.getMerchantIdGroupName());
		management.setSeperateLine(request.getSeperateLine());
		management.setRule(request.getRule());
		management.setCreatedBy(request.getCreatedBy());
		management.setCreatedOn(Calendar.getInstance().getTime());
		management.setFeeType(Short.parseShort(request.getFeeType()));
		feemanagementdao.saveFeeDetails(management);			
		}
		return null;
	}
	
	@Override
	public List<FeeManagement> getFeeDetails() {
		try {
			List<CmsFeeManagement> list = feemanagementdao.getFeeDetails();
			List<FeeManagement> details = new ArrayList<FeeManagement>();
			for (CmsFeeManagement feemanagement : list) {
				FeeManagement management = new FeeManagement();
				management.setFeeCode(feemanagement.getFeeCode());
				management.setFeeDescription(feemanagement.getFeeDescription());
				management.setTransaction(feemanagement.getTransaction());
				management.setFrequency(feemanagement.getFrequency());
				management.setPerFlat(feemanagement.getPerFlat());
				management.setPercentage(feemanagement.getPercentage());
				management.setFlat(feemanagement.getFlat());
				management.setLimit(feemanagement.getLimit());
				management.setMaxLimit(feemanagement.getMaxLimit());
				management.setMinLimit(feemanagement.getMinLimit());
				management.setChargeFeeTo(feemanagement.getChargeFeeTo());
				management.setGroupTransactions(feemanagement.getGroupTransactions());
				management.setCriteria(feemanagement.getCriteria());
				management.setCriteriaFrom(feemanagement.getCriteriaFrom());
				management.setCriteriaTo(feemanagement.getCriteriaTo());
				management.setCountryCode(feemanagement.getCountryCode());
				management.setAcquiringNetwork(feemanagement.getAcquiringNetwork());
				management.setAcquiringNetworkName(feemanagement.getAcquiringNetworkName());
				management.setDeliveryChannels(feemanagement.getDeliveryChannels());
				management.setDeliveryChannelName(feemanagement.getDeliveryChannelName());
				management.setMerchantIdGroup(feemanagement.getMerchantIdGroup());
				management.setMerchantIdGroupName(feemanagement.getMerchantIdGroupName());
				management.setSeperateLine(feemanagement.getSeperateLine());
				management.setRule(feemanagement.getRule());

				management.setCreatedBy(feemanagement.getCreatedBy());
				management.setCreatedOn(feemanagement.getCreatedOn());
				management.setFeeType(feemanagement.getFeeType() + "");
				details.add(management);
			}
			return details;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Override
	public FeeManagement updateFeeDetails(FeeManagement feemanagement) {
		try {
			CmsFeeManagement management = feemanagementdao.getFeeDetailsByCode(feemanagement.getFeeCode());

			management.setFeeCode(feemanagement.getFeeCode());
			management.setFeeDescription(feemanagement.getFeeDescription());
			management.setTransaction(feemanagement.getTransaction());
			management.setFrequency(feemanagement.getFrequency());
			management.setPerFlat(feemanagement.getPerFlat());
			management.setPercentage(feemanagement.getPercentage());
			management.setFlat(feemanagement.getFlat());
			management.setLimit(feemanagement.getLimit());
			management.setMaxLimit(feemanagement.getMaxLimit());
			management.setMinLimit(feemanagement.getMinLimit());
			management.setChargeFeeTo(feemanagement.getChargeFeeTo());
			management.setGroupTransactions(feemanagement.getGroupTransactions());
			management.setCriteria(feemanagement.getCriteria());
			management.setCriteriaFrom(feemanagement.getCriteriaFrom());
			management.setCriteriaTo(feemanagement.getCriteriaTo());
			management.setCountryCode(feemanagement.getCountryCode());
			management.setAcquiringNetwork(feemanagement.getAcquiringNetwork());
			management.setAcquiringNetworkName(feemanagement.getAcquiringNetworkName());
			management.setDeliveryChannels(feemanagement.getDeliveryChannels());
			management.setDeliveryChannelName(feemanagement.getDeliveryChannelName());
			management.setMerchantIdGroup(feemanagement.getMerchantIdGroup());
			management.setMerchantIdGroupName(feemanagement.getMerchantIdGroupName());
			management.setSeperateLine(feemanagement.getSeperateLine());
			management.setRule(feemanagement.getRule());

			management.setModifiedBy("admin");
			management.setModifiedOn(Calendar.getInstance().getTime());
			management.setFeeType(Short.parseShort(feemanagement.getFeeType()));
			boolean updatefee = feemanagementdao.updateFeeDetails(management);
			return feemanagement;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public FeeManagement getFeeDetailsByCode(String feeCode) {
		try {
			System.out.println("in service fee code is" + feeCode);
			CmsFeeManagement cmsmanagement = feemanagementdao.getFeeDetailsByCode(feeCode);

			FeeManagement management = new FeeManagement();
			management.setFeeCode(cmsmanagement.getFeeCode());
			management.setFeeDescription(cmsmanagement.getFeeDescription());
			management.setTransaction(cmsmanagement.getTransaction());
			management.setFrequency(cmsmanagement.getFrequency());
			management.setPerFlat(cmsmanagement.getPerFlat());
			management.setPercentage(cmsmanagement.getPercentage());
			management.setFlat(cmsmanagement.getFlat());
			management.setLimit(cmsmanagement.getLimit());
			management.setMaxLimit(cmsmanagement.getMaxLimit());
			management.setMinLimit(cmsmanagement.getMinLimit());
			management.setChargeFeeTo(cmsmanagement.getChargeFeeTo());
			management.setGroupTransactions(cmsmanagement.getGroupTransactions());
			management.setCriteria(cmsmanagement.getCriteria());
			management.setCriteriaFrom(cmsmanagement.getCriteriaFrom());
			management.setCriteriaTo(cmsmanagement.getCriteriaTo());
			management.setCountryCode(cmsmanagement.getCountryCode());
			management.setAcquiringNetwork(cmsmanagement.getAcquiringNetwork());
			management.setAcquiringNetworkName(cmsmanagement.getAcquiringNetworkName());
			management.setDeliveryChannels(cmsmanagement.getDeliveryChannels());
			management.setDeliveryChannelName(cmsmanagement.getDeliveryChannelName());
			management.setMerchantIdGroup(cmsmanagement.getMerchantIdGroup());
			management.setMerchantIdGroupName(cmsmanagement.getMerchantIdGroupName());
			management.setSeperateLine(cmsmanagement.getSeperateLine());
			management.setRule(cmsmanagement.getRule());
			management.setFeeType(cmsmanagement.getFeeType() + "");

			return management;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public GenericResponse geTransactionType() {
		GenericResponse response = new GenericResponse();
		List<FeeManagement> feeManagements = new ArrayList<>();
		List<CmsMGroupTransaction> transactions = feemanagementdao.getTransactionType();
		for (CmsMGroupTransaction mTransaction : transactions) {
			FeeManagement management = new FeeManagement();
			management.setGroupTransactions(mTransaction.getGroupDescription());
			feeManagements.add(management);
		}
		response.setList(feeManagements);
		return response;
	}

	@Override
	public CmsFeeManagement getFeeDetails(String user, String feeCode) {
		return feemanagementdao.getFeeDetails(user, feeCode);
	}
}