package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsProductDefinationRequest;
import com.cms.admin.entity.ProductTypeDefinition;

public interface ProductDefinationGroup {
	
	public ProductTypeDefinition saveDetail(CmsProductDefinationRequest productTypeDefinition);
	
	public List<ProductTypeDefinition> getAll(String username);

}
