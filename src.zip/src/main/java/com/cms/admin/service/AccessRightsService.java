package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.DashboardMenu;
import com.cms.admin.bean.RolesBean;
import com.cms.admin.entity.CmsFunctions;
import com.cms.admin.entity.CmsJobs;
import com.cms.admin.entity.CmsModules;

public interface AccessRightsService {
	
	public List<DashboardMenu> saveAccessRights(RolesBean bean);
	
	public CmsModules delete(CmsModules modules);

	public CmsFunctions delete(CmsFunctions functions);

	public CmsJobs delete(CmsJobs jobs);
	
	public CmsModules get(CmsModules modules);

	public CmsFunctions get(CmsFunctions functions);

	public CmsJobs get(CmsJobs jobs);
	
	public List<CmsModules> getMenu(String username);

}
