package com.cms.admin.service;

import java.util.List;

import com.cms.admin.bean.CmsCardUsageBean;
import com.cms.admin.bean.PlasticProductSetupBean;
import com.cms.admin.bean.ProgrammeDefinitionBean;
import com.cms.admin.entity.CmsCardUsage;
import com.cms.admin.entity.CmsProgrammeDefinition;

public interface ProgrameDefinitionService {
	
	public ProgrammeDefinitionBean saveProductDefinition(ProgrammeDefinitionBean programDefinition);
	
	public List<ProgrammeDefinitionBean> getProgramDefinitionDetails();

	public ProgrammeDefinitionBean updateProgramDefinitionBean(ProgrammeDefinitionBean programDefinitionbean);
	
	public ProgrammeDefinitionBean isExistProgramCode(String programcode); 
	
	public CmsProgrammeDefinition getCardUsageDetailsByCode(String username,String programcode); 
	
	public List<CmsProgrammeDefinition> getAll(String username);
	
}
