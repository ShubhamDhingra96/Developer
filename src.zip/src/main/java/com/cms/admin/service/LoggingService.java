package com.cms.admin.service;

public interface LoggingService {
	
	public void saveExceptionLog(String errorCode, String rootCause, String errorMessage, String userId, String tTransactionId, String exceptionRequest, String exceptionResponse);
	
	public String stackTraceToString(Throwable e);

}
