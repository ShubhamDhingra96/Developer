package com.cms.admin.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AccountNotActivated {	
	
	private static Map<String, String > errors = new HashMap<String, String>();
	

	public static ResponseEntity<Object> setResponse() {
		errors.put("Error", "Please change password.");
		return new ResponseEntity<Object>(errors, HttpStatus.FORBIDDEN);
	}

}
