/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cms.email.prop;

/**
 *
 * @author Administrator
 */
public class MasterFilePath {

    private static String masterfilepath = null;

    /**
     * @return the masterfilepath
     */
    public static String getMasterfilepath() {
        return masterfilepath;
    }

    /**
     * @param aMasterfilepath the masterfilepath to set
     */
    public static void setMasterfilepath(String aMasterfilepath) {
        masterfilepath = aMasterfilepath;
    }

}
